import argparse
import socket


def _argparse():
    parser = argparse.ArgumentParser(description="This is a UDP client for the 'Guess the Number' game.")
    parser.add_argument('--ip', action='store', required=True, dest='ip', help='The IP of the server to connect to')
    parser.add_argument('--port', action='store', type=int, required=True, dest='port',
                        help='The port of the server to connect to')
    return parser.parse_args()


def client_program(ip , port):

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    client.connect((ip, port))
    print(f"Connected to server at {ip}:{port}")

    name = input("Enter your name: ")
    client.send(name.encode('utf-8'))
    print("Waiting for other players...")

    while True:
        message = client.recv(1024).decode('utf-8')
        print(message)

        if "Your turn to guess" in message:
            guess = input("Enter your guess: ")
            client.send(guess.encode('utf-8'))
        elif "Game over" in message:
            print("Game over. Exiting client.")
            break

    client.close()
def main():
    arg = _argparse()
    client_program(arg.ip, arg.port)
if __name__ == "__main__":
    main()