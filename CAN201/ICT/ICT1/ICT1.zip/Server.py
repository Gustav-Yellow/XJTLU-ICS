import argparse
import socket
import threading
import random

clients = []
names = []
target_number = random.randint(1, 100)  # 随机生成目标数字
game_over = False  # 标志游戏是否结束


def _argparse():
    parser = argparse.ArgumentParser(description="This is a UDP client for the 'Guess the Number' game.")
    parser.add_argument('--ip', action='store', required=True, dest='ip', help='The IP of the server to connect to')
    parser.add_argument('--port', action='store', type=int, required=True, dest='port', help='The port of the server to connect to')
    return parser.parse_args()

def handle_client(client_socket, client_address):
    global game_over
    name = client_socket.recv(1024).decode('utf-8')
    names.append(name)
    print(f"Received name: {name}")
    if len(names) == 2:
        broadcast("Game started!\n")
        print('All clients are ready. Starting the game.')
        print(f"Random number generated: {target_number}")
        start_game()

def start_game():
    for i in range(len(clients)):
        prompt_client(i)

def prompt_client(index):
    global game_over
    if game_over:
        return
    client = clients[index]
    name = names[index]
    client.send(b"Your turn to guess: ")
    guess = int(client.recv(1024).decode('utf-8'))
    print(f"Prompting {name} to guess.")
    if guess < target_number:
        response = f"Your guess is too low!\nWaiting for your turn...\n{name} guessed {guess}. The guess is too low."
        print(f"Received guess {guess} from {name}. Too low.")
    elif guess > target_number:
        response = f"Your guess is too high!\nWaiting for your turn...\n{name} guessed {guess}. The guess is too high."
        print(f"Received guess {guess} from {name}. Too high.")
    else:
        response = f"Congratulations {name}! You guessed the number!\n"
        print(f"Received guess {guess} from {name}. {name} wins!")
        game_over = True
        broadcast(response + "Game over.\n")
        return
    broadcast(response)
    if not game_over:
        next_index = (index + 1) % len(clients)
        prompt_client(next_index)

def broadcast(message):
    for client in clients:
        client.send(message.encode('utf-8'))

def server_program(ip, port):
    global game_over
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((ip, port))
    server.listen(2)
    print(f"Server started on {ip}:{port}")
    while len(clients) < 2:
        client_socket, client_address = server.accept()
        print(f"Client connected: {client_address}")
        clients.append(client_socket)
        threading.Thread(target=handle_client, args=(client_socket, client_address)).start()
    while True:
        if game_over:
            print("Game over. Shutting down server.")
            break
    server.close()

def main():
    args = _argparse()
    print('Server IP:', args.ip)
    print('Server Port:', args.port)
    server_program(args.ip, args.port)

if __name__ == "__main__":
    main()