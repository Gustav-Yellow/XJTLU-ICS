```
 ________  ________  _________   _______  ________    _______  ________ ________  ________     
|\   ____\|\   __  \|\___   ___\/  ___  \|\   __  \  /  ___  \|\   ____\\_____  \|\_____  \    
\ \  \___|\ \  \|\  \|___ \  \_/__/|_/  /\ \  \|\  \/__/|_/  /\ \  \___\|____|\ /\|____|\ /_   
 \ \  \    \ \   ____\   \ \  \|__|//  / /\ \  \\\  \__|//  / /\ \  \  ___   \|\  \    \|\  \  
  \ \  \____\ \  \___|    \ \  \   /  /_/__\ \  \\\  \  /  /_/__\ \  \|\  \ __\_\  \  __\_\  \ 
   \ \_______\ \__\        \ \__\ |\________\ \_______\|\________\ \_______\\_______\|\_______\
    \|_______|\|__|         \|__|  \|_______|\|_______| \|_______|\|_______\|_______|\|_______|
```
# Meeting Booking Project

## 项目概述

本项目是一个会议室预定系统，提供用户注册、登录、房间预定等功能。此系统使用Spring Boot框架进行开发，前端页面与后端API结合，支持用户管理和房间预定功能。

## 环境要求

- Java版本：= JDK 17
- MySQL版本：8.0+

## 配置说明

### Spring Profile机制

本项目使用Spring Profile机制来管理不同环境的配置。在`application.yml`文件中，`spring.profiles.active`用于指定当前激活的配置文件。

默认情况下，本项目使用开发环境配置。如果你希望更改为其他环境（例如生产环境、测试环境），只需修改`application.yml`中的`active`参数即可。例如：

```yaml
spring:
  application:
    name: meeting_booking
  profiles:
    active: dev   # 将"dev"替换为你所需的环境名称
```
## 环境变量设置
在运行本项目之前，确保配置以下三个环境变量：

DB_PASSWORD：数据库密码

DB_URL：数据库连接URL

DB_USERNAME：数据库用户名

### 示例：

```bash
DB_PASSWORD=123465
DB_URL=jdbc:mysql://localhost:3306/meeting_booking
DB_USERNAME=root
MAIL_HOST=smtp.163.com;
MAIL_PASSWORD=VBNXTLAZGZEUFQSN;
MAIL_USERNAME=gustavhuang@163.com
OSS_AK=m2YH8tar1Dhx_BWaQbQnP7upSS3rCn8lDww8DZqV;
OSS_SK=UlOVsryaT79owqVKgVYe8kiZSR6uOF-f5JKrIjla
OSS_BUCKET=cpt202-meetingbooking;
OSS_DOMAIN=sulthbbxs.hd-bkt.clouddn.com;
```
在运行本项目时，这些环境变量将被用于数据库连接以及邮箱发信的配置。