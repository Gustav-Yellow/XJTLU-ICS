<template>
  <div class="avatar-upload-field" :style="customStyles">
    <label :for="id" :style="{ textAlign: align }" class="input-label">
      {{ label }}
    </label>
    <div
      class="avatar-container"
      :style="{ width: size + 'px', height: size + 'px' }"
      @click="triggerFileInput"
    >
      <div class="avatar-image" :style="avatarStyle"></div>
      <input
        type="file"
        ref="fileInput"
        accept="image/*"
        style="display: none;"
        @change="handleImageChange"
        :disabled="disabled"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: 'AvatarUploadField',
  model: { prop: 'value', event: 'input' },
  props: {
    value: { type: String, default: '' },    // 传入/输出的图片地址
    defaultUrl: {
      type: String,
      default: 'http://sulthbbxs.hd-bkt.clouddn.com/avatars/default.jpg'
    },
    id: String,
    label: String,
    align: { type: String, default: 'left' },
    size: { type: Number, default: 30 },
    labelColor: { type: String, default: '#252837' },
    inputBgColor: { type: String, default: '#ffffff' },
    inputTextColor: { type: String, default: '#000000' },
    disabled: { type: Boolean, default: false },
    disabledTextColor: { type: String, default: '#666666' },
    disabledBgColor: { type: String, default: '#e0e0e0' }
  },
  computed: {
    // 计算当前显示的头像 URL，优先使用外部绑定的 value，否则回退默认图片
    avatarUrl: {
      get() {
        return this.value || this.defaultUrl;
      },
      set(newUrl) {
        this.$emit('input', newUrl);
      }
    },
    // 面板自定义 CSS 变量
    customStyles() {
      return {
        '--label-color': this.labelColor,
        '--input-bg-color': this.inputBgColor,
        '--input-text-color': this.inputTextColor,
        '--disabled-text-color': this.disabledTextColor,
        '--disabled-bg-color': this.disabledBgColor
      };
    },
    // 将 avatarUrl 应用到背景样式
    avatarStyle() {
      return {
        backgroundImage: `url(${this.avatarUrl})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        borderRadius: '50%',
        border: '2px solid #ccc',
        width: `${this.size}px`,  
        height: `${this.size}px`
      };
    }
  },
  methods: {
    triggerFileInput() {
      if (!this.disabled) {
        this.$refs.fileInput.click();
      }
    },
    handleImageChange(event) {
      const file = event.target.files[0];
      if (file) {
        // 使用 URL.createObjectURL 快速生成本地 blob 地址
        const blobUrl = URL.createObjectURL(file);
        // 更新绑定值，触发 v-model 更新
        this.avatarUrl = blobUrl;
        // 向外部抛出新选中的 File 对象
        this.$emit('file-selected', file);
      }
    }
  }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

.avatar-upload-field {
  margin-bottom: 20px;
  width: 100%;
}

.input-label {
  display: block;
  font-size: 16px;
  color: var(--label-color, #252837);
  margin-bottom: 5px;
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 600;
}

.avatar-container {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  cursor: pointer;
}

.avatar-image {
  border-radius: 50%;
  width: 100%;
  height: 100%;
  background-color: #e0e0e0;
}

input[type="file"]:disabled {
  cursor: not-allowed;
}

.avatar-upload-field input:focus {
  outline: none;
}
</style>