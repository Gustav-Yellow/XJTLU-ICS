<template>
    <button
      :class="['custom-button', type, { loading: isLoading }]"
      :disabled="isLoading"
      :style="customButtonStyle"
      @click="$emit('click')"
    >
      <span class="button-label" v-if="!isLoading">{{ label }}</span>
      <span class="loading-spinner" v-if="isLoading"></span>
    </button>
  </template>
  
  <script>
  export default {
    name: 'Button',
    props: {
      label: {
        type: String,
        required: true,
      },
      type: {
        type: String,
        default: 'primary', // primary 或 secondary
      },
      loading: {
        type: Boolean,
        default: false,
      },
      // primary 状态相关颜色
      primaryBgColor: {
        type: String,
        default: '#1a252f',
      },
      primaryHoverBgColor: {
        type: String,
        default: '#2c3e50',
      },
      primaryActiveBgColor: {
        type: String,
        default: '#131317',
      },
      primaryTextColor: {
        type: String,
        default: 'white',
      },
      // secondary 状态相关颜色
      secondaryBgColor: {
        type: String,
        default: 'none',
      },
      secondaryHoverColor: {
        type: String,
        default: '#6b749a',
      },
      secondaryTextColor: {
        type: String,
        default: '#6877b2',
      },
    },
    computed: {
      isLoading() {
        return this.loading;
      },
      customButtonStyle() {
        return {
          '--primary-bg': this.primaryBgColor,
          '--primary-hover-bg': this.primaryHoverBgColor,
          '--primary-active-bg': this.primaryActiveBgColor,
          '--primary-text': this.primaryTextColor,
          '--secondary-bg': this.secondaryBgColor,
          '--secondary-hover': this.secondaryHoverColor,
          '--secondary-text': this.secondaryTextColor,
        };
      },
    },
  };
  </script>
  
  <style scoped>
  @import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');
  
  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
  
  @keyframes morphLoad {
    0% {
      width: 100%;
      border-radius: 4px;
    }
    50% {
      width: 60px;
      border-radius: 20px;
    }
    100% {
      width: 40px;
      border-radius: 50%;
    }
  }
  
  /* 按钮基础样式 */
  .custom-button {
    position: relative;
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    margin-top: 15px;
    cursor: pointer;
    font-family: 'Rethink Sans', sans-serif;
    font-weight: 600;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
  }
  
  /* Primary 状态，使用 CSS 变量 */
  .primary {
    background-color: var(--primary-bg, #1a252f);
    color: var(--primary-text, white);
  }
  .primary:hover:not(.loading):not(:disabled) {
    background-color: var(--primary-hover-bg, #2c3e50);
  }
  .primary:active:not(.loading):not(:disabled) {
    background-color: var(--primary-active-bg, #131317);
  }
  
  /* Secondary 状态 */
  .secondary {
    margin-top: 5px;
    background: var(--secondary-bg, none);
    color: var(--secondary-text, #6877b2);
  }
  .secondary:hover:not(.loading):not(:disabled) {
    color: var(--secondary-hover, #6b749a);
  }
  
  /* Loading 状态 */
  .custom-button.loading {
    width: 40px;
    height: 40px;
    margin: 15px auto 0; /* 居中且保持上边距 */
    border-radius: 50%;
    background: transparent;
    border: 2px dashed var(--primary-bg, #1a252f);
    padding: 0;
    cursor: not-allowed;
    animation: morphLoad 0.4s ease-out forwards, spin 2.5s linear infinite;
  }
  
  .button-label {
    transition: opacity 0.2s ease;
  }
  
  .custom-button.loading .button-label {
    opacity: 0;
  }
  
  .loading-spinner {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
  }
  
  .custom-button:disabled {
    opacity: 0.6;
  }
  </style>
  