<template>
  <div class="data-table-container">
    <!-- Filter Section -->
    <FilterPanel
      v-if="showFilter"
      :config="filterConfig"
      :sidePadding="'15px'"
      @search="$emit('filter-search', $event)"
      @cancel="$emit('filter-cancel')"
    />

    <!-- Table Section -->
    <div class="table-wrapper" :style="tableStyles">
      <table class="custom-table">
        <thead :style="headerStyles">
          <tr>
            <th
              v-for="(header, index) in headers"
              :key="index"
              @click="handleHeaderClick(header)"
              :class="getHeaderClass(header)"
            >
              {{ header.label }}
              <span v-if="sortedColumn === header.key && sortDirection" class="sort-arrow">
                {{ sortDirection === 'asc' ? '▲' : '▼' }}
              </span>
            </th>
            <!-- 操作列表头不显示文字 -->
            <th v-if="allowActions" class="actions-header">
              <div class="extra-icon-button">
                <IconButton
                  v-if="showExtraIconButton"
                  v-bind="extraIconButtonProps"
                  @click="handleExtraIconClick"
                />
              </div>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="(row, rowIndex) in paginatedData"
            :key="rowIndex"
            @click="handleRowClick(row)"
          >
            <td v-for="(header, colIndex) in headers" :key="colIndex">
              <!-- 绘制带格式内容 -->
              <template v-if="row[header.key] && row[header.key].type === 'formatted'">
                <div
                  v-for="(item, itemIndex) in row[header.key].items"
                  :key="itemIndex"
                  :class="item.className"
                  :style="item.style"
                >
                  {{ item.text }}
                </div>
              </template>
              <template v-else>
                {{ row[header.key] }}
              </template>
            </td>
            <!-- 操作列 -->
            <td v-if="allowActions && actionVisible(row)" class="actions-cell">
              <slot name="actions" :row="row" :rowIndex="rowIndex">
                <button
                  class="action-button delete"
                  @click.stop="removeItem(rowIndex + (currentPage - 1) * pageSize)"
                >
                  Delete
                </button>
              </slot>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- 分页区域 -->
    <div class="pagination-controls">
      <!-- 左侧：每页显示行数 -->
      <div class="page-size-selector">
        <label for="page-size">Rows per page:</label>
        <select id="page-size" v-model="pageSize" @change="resetPagination">
          <option v-for="size in pageSizeOptions" :key="size" :value="size">{{ size }}</option>
        </select>
      </div>

      <!-- 中间：页面导航按钮 -->
      <div class="pagination-buttons" v-if="totalPages > 1">
        <button @click="goToPage(currentPage - 1)" :disabled="currentPage === 1" class="page-nav prev">
          &laquo;
        </button>

        <div class="page-numbers">
          <button
            v-for="page in displayedPageNumbers"
            :key="page"
            @click="goToPage(page)"
            :class="{ active: currentPage === page }"
            class="page-number"
          >
            {{ page }}
          </button>
        </div>

        <div class="page-jump" v-if="totalPages > 5">
          <input
            type="number"
            v-model.number="jumpToPage"
            min="1"
            :max="totalPages"
            @keyup.enter="goToPage(jumpToPage)"
          />
          <button @click="goToPage(jumpToPage)" class="jump-button">Go</button>
        </div>

        <button @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages" class="page-nav next">
          &raquo;
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import IconButton from './IconButton.vue';
import FilterPanel from './FilterPanel.vue';

export default {
  name: 'DataTable',
  components: {
    IconButton,
    FilterPanel,
  },
  props: {
    headers: {
      type: Array,
      required: true,
    },
    data: {
      type: Array,
      default: () => [],
    },
    headerBgColor: {
      type: String,
      default: '#1a252f',
    },
    headerBgOpacity: {
      type: Number,
      default: 1,
      validator: (v) => v >= 0 && v <= 1,
    },
    bodyBgColor: {
      type: String,
      default: '#2A2A2F',
    },
    bodyBgOpacity: {
      type: Number,
      default: 0.8,
      validator: (v) => v >= 0 && v <= 1,
    },
    pageSizeOptions: {
      type: Array,
      default: () => [5, 10, 20, 50],
    },
    defaultPageSize: {
      type: Number,
      default: 10,
    },
    allowActions: {
      type: Boolean,
      default: true,
    },
    showExtraIconButton: {
      type: Boolean,
      default: false,
    },
    extraIconButtonProps: {
      type: Object,
      default: () => ({}),
    },
    showFilter: {
      type: Boolean,
      default: false,
    },
    filterConfig: {
      type: Array,
      default: () => [],
    },
    actionVisible: {
      type: Function,
      default: () => true,          // 默认全部显示
    },
  },
  data() {
    return {
      // 分页
      currentPage: 1,
      pageSize: this.defaultPageSize,
      jumpToPage: 1,
      // 排序
      sortedColumn: null,
      sortDirection: null, // 'asc' | 'desc' | null
      // 过滤
      filters: [], // 外部传入的过滤条件数组
    };
  },
  computed: {
    headerStyles() {
      return { backgroundColor: this.hexToRgba(this.headerBgColor, this.headerBgOpacity) };
    },
    tableStyles() {
      return { backgroundColor: this.hexToRgba(this.bodyBgColor, this.bodyBgOpacity) };
    },

    /**
     * 先对原始数据进行过滤，再排序
     */
    processedData() {
      let baseData = this.filters.length ? this.applyFilters(this.data) : this.data;

      if (!this.sortedColumn || !this.sortDirection) return baseData;

      const direction = this.sortDirection === 'asc' ? 1 : -1;
      return [...baseData].sort((a, b) => {
        const valA = this.getSortValue(a[this.sortedColumn]);
        const valB = this.getSortValue(b[this.sortedColumn]);
        if (typeof valA === 'number' && typeof valB === 'number') {
          return (valA - valB) * direction;
        }
        return String(valA).localeCompare(String(valB), undefined, {
          numeric: true,
          sensitivity: 'base',
        }) * direction;
      });
    },

    paginatedData() {
      const start = (this.currentPage - 1) * this.pageSize;
      return this.processedData.slice(start, start + this.pageSize);
    },
    totalPages() {
      return Math.ceil(this.processedData.length / this.pageSize) || 1;
    },
    displayedPageNumbers() {
      const totalToShow = 5;
      if (this.totalPages <= totalToShow) return [...Array(this.totalPages)].map((_, i) => i + 1);

      let start = Math.max(1, this.currentPage - 2);
      let end = start + totalToShow - 1;
      if (end > this.totalPages) {
        end = this.totalPages;
        start = Math.max(1, end - totalToShow + 1);
      }
      return [...Array(end - start + 1)].map((_, i) => start + i);
    },
  },
  methods: {
    /** 颜色 HEX → RGBA */
    hexToRgba(hex, opacity) {
      hex = hex.replace('#', '');
      const r = parseInt(hex.substring(0, 2), 16);
      const g = parseInt(hex.substring(2, 4), 16);
      const b = parseInt(hex.substring(4, 6), 16);
      return `rgba(${r}, ${g}, ${b}, ${opacity})`;
    },

    /** 排序 */
    handleHeaderClick(header) {
      if (header.key === this.sortedColumn) {
        if (this.sortDirection === 'asc') this.sortDirection = 'desc';
        else if (this.sortDirection === 'desc') {
          this.sortedColumn = null;
          this.sortDirection = null;
        } else this.sortDirection = 'asc';
      } else {
        this.sortedColumn = header.key;
        this.sortDirection = 'asc';
      }
      this.resetPagination();
    },
    getHeaderClass(header) {
      return {
        sortable: true,
        active: header.key === this.sortedColumn,
        asc: header.key === this.sortedColumn && this.sortDirection === 'asc',
        desc: header.key === this.sortedColumn && this.sortDirection === 'desc',
      };
    },
    getSortValue(cell) {
      if (cell && typeof cell === 'object' && cell.type === 'formatted') {
        return cell.items.map((i) => i.text).join(' ');
      }
      return cell || '';
    },

    /**
     * ================= 过滤逻辑 =================
     * 外部调用: this.$refs.table.filterData([ ...conditions ])
     * 条件示例：
     *   { key: 'name', type: 'contains', value: 'abc' }
     *   { key: 'status', type: 'equals', value: 'active' }
     *   { key: 'age', type: 'between', min: 18, max: 30 }
     */
    filterData(conditions = []) {
      this.filters = Array.isArray(conditions) ? conditions : [];
      this.resetPagination();
    },
    clearFilters() {
      this.filterData([]);
    },
    applyFilters(dataArr) {
      return dataArr.filter(row =>
        this.filters.every(cond => {
          const value = row[cond.key];
          if (cond.type === 'contains') {
            return String(value)
              .toLowerCase()
              .includes(String(cond.value).toLowerCase());
          }
          if (cond.type === 'equals') {
            return value === cond.value;
          }
          if (cond.type === 'between') {
            const numVal = typeof value === 'number' ? value : parseFloat(value);
            if (isNaN(numVal)) return false;
            // 双端都有值
            if (cond.min != null && cond.max != null) {
              return numVal >= cond.min && numVal <= cond.max;
            }
            // 只有最小值
            if (cond.min != null) {
              return numVal >= cond.min;
            }
            // 只有最大值
            if (cond.max != null) {
              return numVal <= cond.max;
            }
            // 都未设置
            return true;
          }
          return true; // 未知类型，直接通过
        })
      );
    },

    /** 分页操作 */
    goToPage(page) {
      if (page >= 1 && page <= this.totalPages) {
        this.currentPage = page;
        this.jumpToPage = page;
      }
    },
    resetPagination() {
      this.currentPage = 1;
      this.jumpToPage = 1;
    },

    /** 数据增删 **/
    removeItem(index) {
      const updated = [...this.data];
      updated.splice(index, 1);
      this.$emit('update:data', updated);
      if (this.paginatedData.length === 0 && this.currentPage > 1) this.currentPage--;
    },
    addItem(item) {
      this.$emit('update:data', [...this.data, item]);
    },

    /** 事件透传 */
    handleRowClick(row) {
      this.$emit('row-click', row);
    },
    handleExtraIconClick() {
      this.$emit('extra-icon-click');
    },
  },
};
</script>

<style scoped>
.data-table-container {
  font-family: 'Rethink Sans', sans-serif;
  width: 100%;
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 20px;
}
.table-wrapper {
  width: 100%;
  overflow-x: auto;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}
.custom-table {
  width: 100%;
  border-collapse: collapse;
  color: #fff;
  text-align: center;
}
/* 排序指示样式 */
th.sortable { cursor: pointer; user-select: none; }
th.active.asc { background-color: rgba(255, 255, 255, 0.08); }
th.active.desc { background-color: rgba(255, 255, 255, 0.14); }
.sort-arrow { margin-left: 4px; font-size: 12px; }

.actions-header { text-align: right; }
.custom-table th {
  padding: 15px; font-weight: 600; white-space: nowrap; font-size: 14px; letter-spacing: 0.5px; text-transform: uppercase;
}
.custom-table td {
  padding: 12px 15px; border-top: 1px solid rgba(255, 255, 255, 0.1); font-size: 14px;
}
.custom-table tbody tr:hover { background-color: rgba(255, 255, 255, 0.05); }

.actions-cell { text-align: right; white-space: nowrap; vertical-align: middle; }
.action-button { padding: 6px 12px; border-radius: 4px; border: none; cursor: pointer; font-size: 12px; transition: 0.2s; background: transparent; color: #fff; }
.action-button.delete { color: #ff6b6b; border: 1px solid #ff6b6b; }
.action-button.delete:hover { background: rgba(255, 107, 107, 0.1); }

.pagination-controls {
  display: flex; justify-content: space-between; align-items: center; margin-top: 15px; padding: 10px; background-color: rgba(30, 30, 32, 0.5); border-radius: 8px;
}
.page-size-selector { display: flex; align-items: center; color: #fff; }
.page-size-selector label { margin-right: 10px; font-size: 14px; }
.page-size-selector select {
  background: #2A2A2F; color: #fff; border: 1px solid #444; padding: 5px 10px; border-radius: 4px; cursor: pointer;
}
.pagination-buttons { display: flex; align-items: right; }
.page-nav, .page-number {
  width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; margin: 0 2px; background: #2A2A2F; border: none; color: #fff; font-size: 14px; border-radius: 4px; cursor: pointer; transition: 0.2s;
}
.page-nav:disabled { opacity: 0.5; cursor: not-allowed; }
.page-number.active { background: #1a252f; font-weight: bold; }
.page-number:hover:not(.active), .page-nav:hover:not(:disabled) { background: #3A3A3F; }
.page-numbers { display: flex; margin: 0 10px; }
.page-jump { display: flex; align-items: center; margin-left: 10px; }
.page-jump input {
  width: 50px; height: 32px; background: #2A2A2F; border: 1px solid #444; border-radius: 4px; text-align: center; color: #fff; margin-right: 5px;
}
.jump-button { height: 32px; padding: 0 10px; background: #1a252f; border: none; color: #fff; border-radius: 4px; cursor: pointer; transition: 0.2s; }
.jump-button:hover { background: #2c3e50; }
.extra-icon-button { display: flex; justify-content: flex-end; }
</style>
