<template>
  <div class="filter-item">
    <label>{{ label }}</label>

    <div class="range-row">
      <input
        type="datetime-local"
        v-model="min"
        :placeholder="placeholderMin"
        @blur="check"
      />
      <span class="dash">—</span>
      <input
        type="datetime-local"
        v-model="max"
        :placeholder="placeholderMax"
        @blur="check"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: 'DateRangeFilter',

  /* 维持与 RangeFilter 相同的 v-model 契约 */
  props: {
    /** v-model 对象 {min, max}，值为 ISO 字符串或空串 */
    value:      { type: Object, default: () => ({}) },
    label:      String,
    placeholderMin: String,
    placeholderMax: String,
    /** 默认值同样是 ISO 字符串，例如 '2025-04-28T09:00' */
    defaultMin: String,
    defaultMax: String,
    /** ({min, max}) => boolean */
    validateFn: {
      type: Function,
      default: ({ min, max }) =>
        (!min || !max) || new Date(min) <= new Date(max)
    }
  },

  data () {
    return {
      min: this.value.min || (this.defaultMin || ''),
      max: this.value.max || (this.defaultMax || '')
    };
  },

  watch: {
    value: {
      deep: true,
      handler (v) {
        if (v.min !== this.min) this.min = v.min;
        if (v.max !== this.max) this.max = v.max;
      }
    },
    min: 'emit',
    max: 'emit'
  },

  methods: {
    emit () {
      this.$emit('input', { min: this.min, max: this.max });
    },
    check () {
      if (!this.validateFn({ min: this.min, max: this.max })) {
        this.min = this.defaultMin || '';
        this.max = this.defaultMax || '';
      }
    }
  }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

input[type="datetime-local"] {
  /* 去掉默认外观 */
  -webkit-appearance: none;
  appearance: none;
}

/* 隐藏日期时间输入框自带的“骨架”文字 */
input[type="datetime-local"]::-webkit-datetime-edit,
input[type="datetime-local"]::-webkit-datetime-edit-text,
input[type="datetime-local"]::-webkit-datetime-edit-year-field,
input[type="datetime-local"]::-webkit-datetime-edit-month-field,
input[type="datetime-local"]::-webkit-datetime-edit-day-field,
input[type="datetime-local"]::-webkit-datetime-edit-hour-field,
input[type="datetime-local"]::-webkit-datetime-edit-minute-field {
  color: #9a9a9a;
}

/* 如需保留分隔符，可调整此处颜色 */
input[type="datetime-local"]::-webkit-datetime-edit-text {
  color: #9a9a9a;
}

.filter-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
  width: 100%;
}

label {
  color: #fff;
  font-size: 14px;
}

/* 通用输入框样式 + 固定高度，与 TextFilter 保持一致 */
.filter-item input {
  background: transparent;
  border: 1px solid #444;
  border-radius: 4px;
  padding: 6px 8px;
  color: #fff;
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 400;
  line-height: 1em;
  height: calc(1em + 6px);
}

.range-row {
  display: flex;
  gap: 4px;
  width: 100%;
}

.range-row input {
  flex: 1 1 0;
  min-width: 180px;
}

input::placeholder {
  color: #9a9a9a;
}

.dash {
  color: #fff;
  white-space: nowrap;
}
</style>
