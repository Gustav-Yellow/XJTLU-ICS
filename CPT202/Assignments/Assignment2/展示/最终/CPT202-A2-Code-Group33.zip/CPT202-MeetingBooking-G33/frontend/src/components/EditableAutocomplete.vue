<!-- EditableAutocomplete.vue  (Vue 2 component) -->
<template>
    <div class="editable-select-container">
      <!-- 顶部显示行 -->
      <div
        class="display-row"
        :class="{ editing: isEditing }"
        @click="toggleEdit"
      >
        <div class="label-content" @click.stop>
          <span class="label-prefix" :style="{ color: prefixColor }">
            {{ prefix }}:
          </span>
  
          <!-- 非编辑状态：普通文本 -->
          <span
            v-if="!isEditing"
            class="label-value"
            :style="{ backgroundColor: valueBgColor, color: valueColor }"
            @click.stop="toggleEdit"
          >
            {{ modelValue }}
          </span>
  
          <!-- 编辑状态：可输入文本 -->
          <input
            v-else
            ref="inputRef"
            class="label-value input-field"
            v-model="inputText"
            :style="{ backgroundColor: editingValueBgColor, color: valueColor }"
            @input="onInput"
          />
        </div>
  
        <!-- 铅笔按钮 -->
        <button
          v-if="showEditButton"
          class="edit-button"
          @click.stop="toggleEdit"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="white"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
            class="lucide lucide-pencil-icon lucide-pencil"
          >
            <path
              d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"
            />
            <path d="m15 5 4 4" />
          </svg>
        </button>
      </div>
  
      <!-- 下拉选项（根据输入实时过滤）-->
      <div
        v-if="isEditing && filteredOptions.length"
        ref="dropdownRef"
        class="dropdown-container"
        :style="{
          backgroundColor: dropdownBgColor,
          maxHeight: dropdownMaxHeight,
          left: dropdownLeft + 'px'
        }"
      >
        <ul class="dropdown-list">
          <li
            v-for="option in filteredOptions"
            :key="option.id"
            class="dropdown-item"
            :style="{
              color: dropdownItemTextColor,
              backgroundColor: dropdownItemBgColor,
              height: itemHeight + 'px',
              lineHeight: itemHeight + 'px'
            }"
            @click="selectOption(option)"
          >
            {{ option.label }}
          </li>
        </ul>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "EditableAutocomplete",
    props: {
      prefix: { type: String, default: "Label" },
      dropdownLeft: { type: [Number, String], default: 60 },
      modelValue: { type: String, required: true },
      options: { type: Array, default: () => [] },
      showEditButton: { type: Boolean, default: true },
      prefixColor: { type: String, default: "#666" },
      valueColor: { type: String, default: "#000" },
      valueBgColor: { type: String, default: "transparent" },
      editingValueBgColor: {
        type: String,
        default: "rgba(0, 0, 0, 0.1)"
      },
      dropdownBgColor: { type: String, default: "#ffffff" },
      dropdownItemTextColor: { type: String, default: "#000000" },
      dropdownItemBgColor: { type: String, default: "transparent" },
      maxVisibleItems: { type: Number, default: 5 },
      itemHeight: { type: Number, default: 30 }
    },
    emits: ["update:modelValue"],
    data() {
      return {
        isEditing: false,
        inputText: ""
      };
    },
    computed: {
      dropdownMaxHeight() {
        return this.maxVisibleItems * this.itemHeight + "px";
      },
      filteredOptions() {
        const kw = this.inputText.trim().toLowerCase();
        return kw
          ? this.options.filter(o =>
              o.label.toLowerCase().includes(kw)
            )
          : this.options;
      }
    },
    watch: {
      modelValue: {
        immediate: true,
        handler(val) {
          this.inputText = val;
        }
      }
    },
    methods: {
      toggleEdit() {
        this.isEditing = !this.isEditing;

        if (this.isEditing) {
        this.$nextTick(() => {
            // $refs 里要么是原生 <input>，要么是子组件实例
            const ref = this.$refs.inputRef;
            const dom = ref && (ref.$el || ref);   // 取到真实 DOM

            if (dom && typeof dom.select === 'function') {
            dom.select();                       // 选中全部文本
            }
        });
      }
    },
      onInput() {
        this.$emit("update:modelValue", this.inputText);
      },
      selectOption(option) {
        this.inputText = option.label;
        this.$emit("update:modelValue", option.label);
        this.isEditing = false;
      },
      handleGlobalClick(event) {
        // 正在编辑 & 点击位置不在本组件内 -> 退出编辑模式
        if (this.isEditing && !this.$el.contains(event.target)) {
        this.isEditing = false;
        }
    }
    },
    mounted() {
      document.addEventListener("click", this.handleGlobalClick, true);
    },
    beforeDestroy() {
      document.removeEventListener("click", this.handleGlobalClick, true);
    }
  };
  </script>
  
  <style scoped>

  .label-value.input-field {
    border: none;
    outline: none;
    width: 100%;
    font: inherit;
  }
  .editable-select-container {
    display: flex;
    align-items: center;
    padding: 6px 8px;
    border-radius: 4px;
    transition: background-color 0.2s ease;
    position: relative;
  }
  
  .display-row {
    display: flex;
    align-items: center;
    cursor: pointer;
    width: 100%;
    border-radius: 4px;
    transition: background-color 0.2s ease;
  }
  
  .display-row.editing {
    background-color: rgba(0, 0, 0, 0.05);
  }
  
  .label-content {
    flex: 1;
    display: flex;
    align-items: center;
  }
  
  .label-prefix {
    font-weight: 500;
    margin-right: 8px;
  }
  
  .label-value {
    cursor: pointer;
    padding: 2px 4px;
    border-radius: 3px;
    transition: background-color 0.2s ease;
  }
  
  .label-value:hover {
    background-color: rgba(0, 0, 0, 0.05);
  }
  
  .edit-button {
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    width: 24px;
    height: 24px;
    padding: 2px;
    margin-left: 8px;
    border-radius: 4px;
    color: #666;
    cursor: pointer;
    opacity: 0.6;
    transition: all 0.2s ease;
  }
  .edit-button:hover {
    opacity: 1;
    background-color: rgba(0, 0, 0, 0.05);
  }
  .editable-select-container:hover .edit-button {
    opacity: 0.8;
  }
  
  .dropdown-container {
    position: absolute;
    top: 100%;
    width: 50%;
    z-index: 10;
    overflow-y: auto;
    border: 1px solid #ccc;
    border-radius: 4px;
    margin-top: 2px;
  }
  
  .dropdown-list {
    list-style: none;
    margin: 0;
    padding: 0;
  }
  
  .dropdown-item {
    padding: 0 8px;
    cursor: pointer;
    transition: background-color 0.2s ease;
    white-space: nowrap;
  }
  .dropdown-item:hover {
    background-color: rgba(0, 0, 0, 0.1);
  }
  </style>
  