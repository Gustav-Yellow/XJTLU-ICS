<template>
  <div class="editable-label-container">
    <div class="label-content">
      <span class="label-prefix" :style="{ color: prefixColor }">{{ prefix }}:</span>
      <span
        v-if="!isEditing"
        class="label-value"
        :style="{ color: valueColor }"
        @click="startEdit"
      >{{ modelValue }}</span>
      <input
        v-else
        ref="editInput"
        type="text"
        class="label-input"
        :type="inputHtmlType"
        :value="modelValue"
        :style="{ color: valueColor }"
        @input="handleInput"
        @blur="finishEdit"
        @keyup.enter="finishEdit"
        @keyup.esc="cancelEdit"
      />
    </div>
    
    <button
      v-if="showEditButton"
      class="edit-button"
      @click="startEdit"
    >
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
           viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"
           stroke-linecap="round" stroke-linejoin="round"
           class="lucide lucide-pencil-icon lucide-pencil">
        <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z" />
        <path d="m15 5 4 4" />
      </svg>
    </button>
  </div>
</template>

<script>
export default {
  name: 'EditableLabel',
  props: {
    prefix: {
      type: String,
      default: 'Label'
    },
    allowedType: {
      type: String,
      default: 'text',
      validator: v => ['text', 'number'].includes(v)
    },
    modelValue: {
      type: [String, Number],
      required: true
    },
    showEditButton: {
      type: Boolean,
      default: false 
    },
    prefixColor: {
      type: String,
      default: '#666'
    },
    valueColor: {
      type: String,
      default: '#000'
    }
  },
  emits: ['update:modelValue'],
  data() {
    return {
      isEditing: false,
      previousValue: ''
    };
  },
  computed: {
    inputHtmlType() {
      return this.allowedType === 'number' ? 'number' : 'text';
    }
  },
  methods: {
    startEdit() {
      if (!this.showEditButton) return;
      this.previousValue = this.modelValue;
      this.isEditing = true;
      this.$nextTick(() => {
        this.$refs.editInput.focus();
        this.$refs.editInput.select();
      });
    },
    handleInput(e) {
      let val = e.target.value;
      if (this.allowedType === 'number') {
        // 空字符串或非法数字时不更新；也可根据需求允许 NaN ⇒ ''
        if (val === '') {
          this.$emit('update:modelValue', '');
          return;
        }
        const n = Number(val);
        if (!isNaN(n)) this.$emit('update:modelValue', n);
      } else {
        this.$emit('update:modelValue', val);
      }
    },
    finishEdit() {
      this.isEditing = false;
    },
    cancelEdit() {
      this.$emit('update:modelValue', this.previousValue);
      this.isEditing = false;
    },
    
  }
};
</script>

<style scoped>
.editable-label-container {
  display: flex;
  align-items: center;
  padding: 6px 8px;
  border-radius: 4px;
  transition: background-color 0.2s ease;
}

.label-content {
  flex: 1;
  display: flex;
  align-items: center;
}

.label-prefix {
  font-weight: 500;
  margin-right: 8px;
}

.label-value {
  cursor: pointer;
  padding: 2px 4px;
  border-radius: 3px;
  transition: background-color 0.2s ease;
  white-space: pre-wrap;
}

.label-value:hover {
  background-color: rgba(0, 0, 0, 0.05);
}

.label-input {
  background-color: rgba(0, 0, 0, 0.05);
  border: 1px solid #ccc;
  border-radius: 3px;
  padding: 2px 4px;
  width: 100%;
  outline: none;
  font-family: inherit;
  font-size: inherit;
  white-space: pre-wrap;
}

.edit-button {
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  width: 24px;
  height: 24px;
  padding: 2px;
  margin-left: 8px;
  border-radius: 4px;
  color: #666;
  cursor: pointer;
  opacity: 0.6;
  transition: all 0.2s ease;
}

.edit-button:hover {
  opacity: 1;
  background-color: rgba(0, 0, 0, 0.05);
}

.editable-label-container:hover .edit-button {
  opacity: 0.8;
}
</style>