<template>
    <div class="editable-select-container">
      <!-- 显示区域 -->
      <div class="display-row" :class="{ editing: isEditing }" @click="toggleEdit">
        <div class="label-content">
          <span class="label-prefix" :style="{ color: prefixColor }">{{ prefix }}:</span>
          <span 
            ref="valueRef"
            class="label-value" 
            :style="{
              backgroundColor: isEditing ? editingValueBgColor : valueBgColor,
              color: valueColor
            }"
          >{{ currentOptionLabel }}</span>
        </div>
        
        <button v-if="showEditButton" class="edit-button" @click.stop="toggleEdit">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
               viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"
               stroke-linecap="round" stroke-linejoin="round"
               class="lucide lucide-pencil-icon lucide-pencil">
            <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/>
            <path d="m15 5 4 4"/>
          </svg>
        </button>
      </div>
      <!-- 下拉框，动态计算位置 -->
      <div 
        v-if="isEditing" 
        ref="dropdownRef"
        class="dropdown-container" 
        :style="{ 
          backgroundColor: dropdownBgColor, 
          maxHeight: dropdownMaxHeight,
          left: dropdownLeft + 'px'
        }"
      >
        <ul class="dropdown-list">
          <li v-for="(option, index) in options" :key="option.id"
              class="dropdown-item"
              :style="{
                color: dropdownItemTextColor,
                backgroundColor: dropdownItemBgColor,
                height: itemHeight + 'px',
                lineHeight: itemHeight + 'px'
              }"
              @click="selectOption(option)"
          >
            {{ option.label }}
          </li>
        </ul>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'EditableSelect',
    props: {
      prefix: {
        type: String,
        default: 'Label'
      },
      dropdownLeft: {
        type: [Number, String],
        default: 60
      },
      modelValue: {
        type: [String, Number],
        required: true
      },
      // 选项数组，格式为 [{ id, label }, ...]
      options: {
        type: Array,
        default: () => []
      },
      showEditButton: {
        type: Boolean,
        default: true
      },
      prefixColor: {
        type: String,
        default: '#666'
      },
      valueColor: {
        type: String,
        default: '#000'
      },
      valueBgColor: {
        type: String,
        default: 'transparent'
      },
      editingValueBgColor: {
        type: String,
        default: 'rgba(0, 0, 0, 0.1)'
      },
      dropdownBgColor: {
        type: String,
        default: '#ffffff'
      },
      dropdownItemTextColor: {
        type: String,
        default: '#000000'
      },
      dropdownItemBgColor: {
        type: String,
        default: 'transparent'
      },
      maxVisibleItems: {
        type: Number,
        default: 5
      },
      itemHeight: {
        type: Number,
        default: 30
      }
    },
    emits: ['update:modelValue'],
    data() {
      return {
        isEditing: false,
        clickOutsideHandler: null
      };
    },
    computed: {
      currentOptionLabel() {
        const found = this.options.find(option => option.id === this.modelValue);
        return found ? found.label : '';
      },
      dropdownMaxHeight() {
        return this.maxVisibleItems * this.itemHeight + 'px';
      }
    },
    methods: {
      toggleEdit() {
        this.isEditing = !this.isEditing;
      },
      selectOption(option) {
        this.$emit('update:modelValue', option.id);
        this.isEditing = false;
        document.removeEventListener('click', this.clickOutsideHandler);
      },
      handleGlobalClick(event) {
        // 如果正在编辑，且点击目标不在 dropdown 容器内，则退出编辑状态
        if (this.isEditing && this.$refs.dropdownRef && !this.$refs.dropdownRef.contains(event.target)) {
            this.isEditing = false;
        }
      }
    },
    mounted() {
        document.addEventListener('click', this.handleGlobalClick, true);
    },
    beforeUnmount() {
        document.removeEventListener('click', this.handleGlobalClick, true);
    }
  };
  </script>
  
  <style scoped>
  .editable-select-container {
    display: flex;
    align-items: center;
    padding: 6px 8px;
    border-radius: 4px;
    transition: background-color 0.2s ease;
    position: relative;
  }
  
  .display-row {
    display: flex;
    align-items: center;
    cursor: pointer;
    width: 100%;
    border-radius: 4px;
    transition: background-color 0.2s ease;
  }
  
  .display-row.editing {
    background-color: rgba(0, 0, 0, 0.05);
  }
  
  .label-content {
    flex: 1;
    display: flex;
    align-items: center;
  }
  
  .label-prefix {
    font-weight: 500;
    margin-right: 8px;
  }
  
  .label-value {
    cursor: pointer;
    padding: 2px 4px;
    border-radius: 3px;
    transition: background-color 0.2s ease;
  }
  
  .label-value:hover {
    background-color: rgba(0, 0, 0, 0.05);
  }
  
  .edit-button {
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    width: 24px;
    height: 24px;
    padding: 2px;
    margin-left: 8px;
    border-radius: 4px;
    color: #666;
    cursor: pointer;
    opacity: 0.6;
    transition: all 0.2s ease;
  }
  
  .edit-button:hover {
    opacity: 1;
    background-color: rgba(0, 0, 0, 0.05);
  }
  
  .editable-select-container:hover .edit-button {
    opacity: 0.8;
  }
  
  .dropdown-container {
    position: absolute;
    top: 100%;
    width: 50%;
    z-index: 10;
    overflow-y: auto;
    border: 1px solid #ccc;
    border-radius: 4px;
    margin-top: 2px;
  }
  
  .dropdown-list {
    list-style: none;
    margin: 0;
    padding: 0;
  }
  
  .dropdown-item {
    padding: 0 8px;
    cursor: pointer;
    transition: background-color 0.2s ease;
    white-space: nowrap;
  }
  
  .dropdown-item:hover {
    background-color: rgba(0, 0, 0, 0.1);
  }
  </style>