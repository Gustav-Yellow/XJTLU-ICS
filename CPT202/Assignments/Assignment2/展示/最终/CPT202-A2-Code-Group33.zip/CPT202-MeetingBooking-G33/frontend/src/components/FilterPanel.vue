<template>
    <div class="filter-wrapper" :style="panelStyles">
      <!-- 折叠头：文字在左，图标在右 -->
      <div class="filter-header">
        <div class="header-text">Filters</div>
        <span
            class="toggle-icon"
            :class="{ open }"
            @click="toggle"
            v-html="arrowSvg"
        />
      </div>
  
      <!-- 折叠体 -->
      <transition name="collapse">
        <div v-show="open" class="filter-body">
          <!-- 子组件网格 -->
          <div class="grid">
            <component
              v-for="(cfg,i) in config"
              :key="i"
              :is="componentMap[cfg.type]"
              v-bind="cfg.props"
              v-model="filters[cfg.field]"
              :class="{ 'wide-filter': cfg.type === 'daterange' }"
            />
          </div>
  
          <!-- 底部按钮 -->
          <div class="button-row">
            <IconButton
              textContent="Search"
              :backgroundColor="'#1a252f'"
              :imageContent="searchSvg"
              @click.stop="emitSearch"
              :size="16"
            />
            <IconButton
              textContent="Cancel"
              :backgroundColor="'#2A2A2F'"
              :imageContent="cancelSvg"
              @click.stop="reset"
              :size="16"
            />
          </div>
        </div>
      </transition>
    </div>
  </template>
  
  <script>
  import IconButton from './IconButton.vue';
  import TextFilter from './TextFilter.vue';
  import SelectFilter from './SelectFilter.vue';
  import RangeFilter from './RangeFilter.vue';
  import DateRangeFilter from './DateRangeFilter.vue';
  
  const arrowSvg =
  `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 6 15 12 9 18"/></svg>`;
  
  const searchSvg =
  ``;
  
  const cancelSvg =
  ``;
  
  export default {
    name: 'FilterPanel',
    components: { IconButton, TextFilter, SelectFilter, RangeFilter, DateRangeFilter },
    props: {
      config:      { type: Array, required: true },
      sidePadding: { type: String, default: '15px' }
    },
    data() {
      const filters = {};
      this.config.forEach(c => {
        filters[c.field] = c.type === 'range'
          ? { min: c.props.defaultMin, max: c.props.defaultMax }
          : c.props.defaultValue;
      });
      return {
        open: false,
        filters,
        componentMap: { 
          text: TextFilter, 
          select: SelectFilter, 
          range: RangeFilter, 
          daterange: DateRangeFilter },
        arrowSvg,
        searchSvg,
        cancelSvg
      };
    },
    computed: {
      panelStyles() {
        return {
          padding: `0 ${this.sidePadding}`,
          fontFamily: "'Rethink Sans', sans-serif",
          color: '#fff'
        };
      }
    },
    methods: {
      toggle() { this.open = !this.open; },
      emitSearch() { this.$emit('search', { ...this.filters }); },
      reset () {
        this.config.forEach(c => {
          if (['range', 'daterange'].includes(c.type)) {
            this.filters[c.field] = {
              min: c.props.defaultMin,
              max: c.props.defaultMax
            };
          } else {
            this.filters[c.field] = c.props.defaultValue;
          }
        });
        this.$emit('cancel');
      }
    }
  };
  </script>
  
  <style scoped>
  @import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');
  
  .filter-header {
    display: flex;
    align-items: center;
    justify-content: flex-start; 
    gap: 8px;      
  }
  
  .header-text {
    font-weight: 600;
  }
  
  .toggle-icon {
    cursor: pointer;
    transition: transform 0.2s ease;
    display: inline-flex;
  }
  
  .toggle-icon.open {
    transform: rotate(90deg);
  }
  
  .button-row {
    margin-top: 16px;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
  }
  .grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 16px;
  }
  /* DateRangeFilter 占两列 */
  .wide-filter{
    grid-column:span 2
  }
  .collapse-enter-active,
  .collapse-leave-active {
    transition: max-height .2s ease;
  }
  .collapse-enter,
  .collapse-leave-to {
    max-height: 0;
    overflow: hidden;
  }
  .collapse-enter-to,
  .collapse-leave {
    max-height: 999px;
  }
  .filter-body {
    margin-top: 12px;
  }
  </style>
  