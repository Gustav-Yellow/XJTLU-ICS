<template>
  <div class="button-wrapper">
    <button class="custom-button" :style="buttonStyle" @click.stop="$emit('click', $event)">
      <div class="icon" :style="iconStyle" v-if="imageContent">
        <template v-if="isSvg">
          <span class="svg-icon" v-html="coloredSvg"></span>
        </template>
        <template v-else>
          <img :src="imageContent" :alt="textContent" :style="{ width: sizePx, height: sizePx }" />
        </template>
      </div>
      <span class="btn-text" :style="{ fontSize: sizePx, color: textColor }">
        {{ textContent }}
      </span>
    </button>
  </div>
</template>

<script>
export default {
  name: 'IconButton',
  props: {
    backgroundColor: {
      type: String,
      default: '#3498db'
    },
    borderEnabled: {
      type: Boolean,
      default: false
    },
    borderColor: {
      type: String,
      default: '#000000'
    },
    imageColor: {
      type: String,
      default: '#ffffff'
    },
    imageContent: {
      type: String,
      default: ''
    },
    textColor: {
      type: String,
      default: '#ffffff'
    },
    textContent: {
      type: String,
      default: 'Button'
    },
    size: {
      type: Number,
      default: 24 // 单位 px
    },
    /** 新增：固定宽度，支持 Number （视为 px）或完整字符串（如 '5em', '100px'） */
    fixedWidth: {
      type: [Number, String],
      default: null
    }
  },
  computed: {
    sizePx() {
      return this.size + 'px';
    },
    buttonStyle() {
      const style = {
        backgroundColor: this.backgroundColor,
        border: this.borderEnabled ? `1px solid ${this.borderColor}` : 'none',
        borderRadius: '8px',
        padding: `8px 12px`,
        display: 'inline-flex',
        alignItems: 'flex-end',
        gap: '8px',
        cursor: 'pointer',
        position: 'relative'
      };

      // 如果固定宽度有值，就加上 width
      if (this.fixedWidth != null && this.fixedWidth !== '') {
        style.width =
          typeof this.fixedWidth === 'number'
            ? `${this.fixedWidth}px`
            : this.fixedWidth;
      }

      return style;
    },
    isSvg() {
      return this.imageContent.trim().startsWith('<svg');
    },
    coloredSvg() {
      return this.imageContent.replace(/fill="(.*?)"/g, `fill="${this.imageColor}"`);
    },
    iconStyle() {
      return {
        width: this.sizePx,
        height: this.sizePx,
        display: 'flex',
        alignItems: 'flex-end', // 确保图标底部对齐
        justifyContent: 'center'
      };
    }
  }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

.button-wrapper {
  display: inline-block;
  position: relative;
}

.custom-button {
  outline: none;
  background: none;
  border: none;
  display: inline-flex;
  align-items: flex-end;
  justify-content: center;
}

.custom-button:hover {
  opacity: 0.9;
}

.svg-icon {
  width: 100%;
  height: 100%;
  display: inline-block;
  line-height: 0;
}

.btn-text {
  display: inline-block;
  line-height: 1;
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 400;
}
</style>
