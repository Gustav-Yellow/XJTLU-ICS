<template>
  <!-- 将自定义样式对象绑定到根 div 上 -->
  <div class="input-field" :style="customStyles">
    <label :for="id" :style="{ textAlign: align }" class="input-label">{{ label }}</label>
    <input
      :id="id"
      :type="type"
      :placeholder="placeholder"
      :value="value"
      :disabled="disabled"
      @input="$emit('input', $event.target.value)"
    />
  </div>
</template>

<script>
export default {
  name: 'InputField',
  props: {
    id: String,
    label: String,
    type: {
      type: String,
      default: 'text',
    },
    placeholder: String,
    value: String,
    align: {
      type: String,
      default: 'left',
    },
    // 自定义颜色
    labelColor: {
      type: String,
      default: '#252837',
    },
    inputBgColor: {
      type: String,
      default: '#ffffff',
    },
    inputTextColor: {
      type: String,
      default: '#000000',
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    // 新增：禁用状态的字体颜色和背景颜色
    disabledTextColor: {
      type: String,
      default: '#666666', // 深灰色
    },
    disabledBgColor: {
      type: String,
      default: '#e0e0e0', // 浅灰色
    },
  },
  computed: {
    customStyles() {
      return {
        '--label-color': this.labelColor,
        '--input-bg-color': this.inputBgColor,
        '--input-text-color': this.inputTextColor,
        '--disabled-text-color': this.disabledTextColor,
        '--disabled-bg-color': this.disabledBgColor,
      };
    },
  },
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

.input-field {
  margin-bottom: 20px;
  width: 100%;
}

.input-label {
  display: block;
  font-size: 16px;
  color: var(--label-color, #252837);
  margin-bottom: 5px;
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 600;
}

input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 400;
  box-sizing: border-box;
  background-color: var(--input-bg-color, #ffffff);
  color: var(--input-text-color, #000000);
}

/* 禁用状态的样式 */
input:disabled {
  background-color: var(--disabled-bg-color, #e0e0e0);
  color: var(--disabled-text-color, #666666);
  cursor: not-allowed;
}

input::placeholder {
  font-size: 16px;
  color: #CAC3C3;
}

input:focus {
  outline: none;
  border-color: #007bff;
}
</style>