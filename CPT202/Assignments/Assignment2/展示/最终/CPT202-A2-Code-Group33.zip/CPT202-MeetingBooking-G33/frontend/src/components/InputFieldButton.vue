<template>
  <div class="custom-input-button" :style="customStyles">
    <label v-if="label" :for="id" :style="{ textAlign: align }" class="input-label">
      {{ label }}
    </label>
    <div class="input-button-container">
      <input
        :id="id"
        :type="type"
        :placeholder="placeholder"
        :value="internalValue"
        @input="updateValue($event)"
        class="input-field"
      />
      <div class="vertical-divider"></div>
      <button class="action-button" type="button" @click="handleClick" :disabled="disabled">
        {{ buttonText }}
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'InputFieldButton',
  props: {
    id: String,
    label: String,
    type: {
      type: String,
      default: 'text',
    },
    placeholder: String,
    value: String,
    align: {
      type: String,
      default: 'left',
    },
    buttonText: {
      type: String,
      default: 'Button',
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    // 新增用于自定义颜色的 Props：
    labelColor: {
      type: String,
      default: '#252837',
    },
    inputBgColor: {
      type: String,
      default: '#ffffff',
    },
    inputTextColor: {
      type: String,
      default: '#000000',
    },
    buttonBgColor: {
      type: String,
      default: '#1a252f',
    },
    buttonTextColor: {
      type: String,
      default: 'white',
    },
  },
  data() {
    return {
      internalValue: this.value || ''
    }
  },
  watch: {
    value(newVal) {
      // 只有当外部value与内部value不同时才更新
      if (newVal !== this.internalValue) {
        this.internalValue = newVal;
      }
    }
  },
  computed: {
    customStyles() {
      return {
        '--label-color': this.labelColor,
        '--input-bg-color': this.inputBgColor,
        '--input-text-color': this.inputTextColor,
        '--button-bg-color': this.buttonBgColor,
        '--button-text-color': this.buttonTextColor,
      };
    },
  },
  methods: {
    updateValue(event) {
      const newValue = event.target.value;
      this.internalValue = newValue;
      this.$emit('input', newValue);
      this.$emit('update:value', newValue);
    },
    handleClick() {
      this.$emit('click', this.internalValue);
    },
  },
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

.custom-input-button {
  margin-bottom: 20px;
  width: 100%;
}

.input-label {
  display: block;
  font-size: 16px;
  color: var(--label-color, #252837);
  margin-bottom: 5px;
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 600;
}

.input-button-container {
  display: flex;
  align-items: center;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: #fff;
  width: 100%;
  box-sizing: border-box;
}

.input-field {
  flex: 1;
  border: none;
  outline: none;
  padding: 10px;
  font-size: 16px;
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 400;
  box-sizing: border-box;
  background-color: var(--input-bg-color, #ffffff);
  color: var(--input-text-color, #000000);
}

.input-field::placeholder {
  font-size: 16px;
  color: #CAC3C3;
}

.vertical-divider {
  width: 1px;
  height: 36px;
  background-color: #ccc;
  margin: 0;
}

.action-button {
  border: none;
  background: none;
  font-size: 16px;
  font-family: 'Rethink Sans', sans-serif;
  background-color: var(--button-bg-color, #1a252f);
  color: var(--button-text-color, white);
  font-weight: 600;
  cursor: pointer;
  padding: 10px 12px;
  border-radius: 0 4px 4px 0;
  transition: all 0.2s ease;
}

.action-button:disabled {
  background-color: #cccccc;
  color: #666666;
  cursor: not-allowed;
}

.action-button:hover:not(:disabled) {
  background-color: #2c3e50;
}

.action-button:active:not(:disabled) {
  background-color: #131317;
}
</style>
