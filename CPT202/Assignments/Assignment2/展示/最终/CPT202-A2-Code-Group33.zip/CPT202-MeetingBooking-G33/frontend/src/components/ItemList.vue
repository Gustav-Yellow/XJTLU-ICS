<template>
    <div class="item-list-container">
      <div class="list-header">
        <span class="list-title" :style="{ color: titleColor, fontSize: textSize + 'px' }">{{ title }}:</span>
      </div>
      <div 
        class="items-container" 
        :style="{ 
          borderColor: containerBorderColor,
          backgroundColor: containerBgColor,
          height: containerHeight + 'px',
          width: containerWidth + 'px',
          borderRadius: textSize * 0.8 + 'px',
        }"
      >
        <div 
          class="items-scrollable-area"
          :style="{
            '--scrollbar-color': scrollbarColor,
            '--scrollbar-hover-color': scrollbarHoverColor
          }"
        >
          <div 
            v-for="(item, index) in modelValue" 
            :key="'item-' + index"
            class="item-card"
            :style="{
              backgroundColor: itemBgColor,
              borderRadius: textSize * 0.6 + 'px',
              margin: `${textSize * 0.5}px ${textSize * 0.5}px`,
              padding: `${textSize * 0.5}px`
            }"
          >
            <div 
              v-for="(rendererConfig, key) in renderers" 
              v-if="shouldRenderField(item, key, rendererConfig)"
              :key="`item-${index}-${key}`"
              class="item-field"
              :style="{
                fontSize: textSize + 'px',
                marginBottom: textSize * 0.3 + 'px'
              }"
              @click.stop="onItemCardClick(item, index)"
            >
              <component 
                :is="rendererConfig.component" 
                v-bind="mapItemToProps(item, key, rendererConfig.propMapping)"
                :text-size="textSize"
                :text-color="itemTextColor"
                @update:modelValue="updateItemValue(index, key, $event)"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>

  import EditableLabel from '@/components/EditableLabel.vue';
  import IconButton from '@/components/IconButton.vue';

  export default {
    name: 'ItemList',
    props: {
      title: {
        type: String,
        default: 'Items'
      },
      modelValue: {  // Use modelValue for v-model
        type: Array,
        default: () => [
          { name: 'Item 1', text: 'Description for item 1' },
          { name: 'Item 2', text: 'Description for item 2' },
          { name: 'Item 3', text: 'Description for item 3' }
        ]
      },
      renderers: {
        type: Object,
        default: () => ({
          name: {
            component: 'default-renderer',
            propMapping: {
              key: 'label',
              value: 'modelValue'
            }
          },
          text: {
            component: 'default-renderer',
            propMapping: {
              key: 'label',
              value: 'modelValue'
            }
          }
        })
      },
      titleColor: {
        type: String,
        default: '#FFFFFF'
      },
      containerBorderColor: {
        type: String,
        default: '#CCCCCC'
      },
      containerBgColor: {
        type: String,
        default: 'transparent'
      },
      itemBgColor: {
        type: String,
        default: 'rgba(200, 200, 200, 0.3)'
      },
      itemTextColor: {
        type: String,
        default: '#FFFFFF'
      },
      scrollbarColor: {
        type: String,
        default: 'rgba(200, 200, 200, 0.3)'
      },
      scrollbarHoverColor: {
        type: String,
        default: 'rgba(200, 200, 200, 0.6)'
      },
      textSize: {
        type: Number,
        default: 16
      },
      containerWidth: {
        type: Number,
        default: 300
      },
      containerHeight: {
        type: Number,
        default: 400
      }
    },
    methods: {
      shouldRenderField(item, key, rendererConfig) {
        if (rendererConfig.visibleIf) {
          if (typeof rendererConfig.visibleIf === 'function') {
            return rendererConfig.visibleIf(item);
          }
          return rendererConfig.visibleIf;
        }
        return true;
      },
      mapItemToProps(item, key, propMapping) {
        const result = {};
  
        if (propMapping.key) {
          result[propMapping.key] = key;
        }
  
        if (propMapping.value) {
          result[propMapping.value] = item[key];
        }
  
        if (propMapping.staticProps) {
          const staticProps = {};
          for (const [propName, propValue] of Object.entries(propMapping.staticProps)) {
            if (typeof propValue === 'function') {
              staticProps[propName] = propValue(item);
            } else {
              staticProps[propName] = propValue;
            }
          }
          Object.assign(result, staticProps);
        }
  
        return result;
      },
      updateItemValue(index, key, newValue) {
        const updatedItems = [...this.modelValue];
        updatedItems[index] = {
          ...updatedItems[index],
          [key]: newValue
        };
        this.$emit('update:modelValue', updatedItems);  // Emit changes to parent
      },
      onItemCardClick(item, index) {
        // 收集真正被渲染出来的字段-renderer 配置
        const activeRenderers = Object.fromEntries(
          Object.entries(this.renderers).filter(([key, cfg]) =>
            this.shouldRenderField(item, key, cfg)
          )
        );

        this.$emit('card-click', {
          item,
          index,
          renderers: activeRenderers
        });
      },
    },
    components: {
      EditableLabel,
      IconButton,
      'default-renderer': {
        props: {
          label: {
            type: String,
            default: 'Label'
          },
          modelValue: {
            type: String,
            default: ''
          },
          textSize: {
            type: Number,
            default: 16
          },
          textColor: {
            type: String,
            default: '#FFFFFF'
          }
        },
        template: `
          <div class="default-field">
            <strong :style="{ fontSize: textSize + 'px', color: textColor }">{{ label }}:</strong> 
            <span :style="{ fontSize: textSize + 'px', color: textColor }">{{ modelValue }}</span>
          </div>
        `
      }
    }
  }
  </script>

<style scoped>
.item-list-container {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 6px 8px; /* 添加与 EditableLabel 相同的内边距 */
}

.list-header {
  display: flex;
  align-items: center;
  margin-bottom: 8px;
}

.list-title {
  font-weight: 500;
}

.items-container {
  border: 1px solid;
  overflow: hidden;
  width: 100%;
  position: relative;
}

.items-scrollable-area {
  height: 100%;
  overflow-y: auto;
  width: 100%;
  padding: 4px;
  box-sizing: border-box;
}

.items-scrollable-area::-webkit-scrollbar {
  width: 8px;
}

.items-scrollable-area::-webkit-scrollbar-track {
  background: transparent;
}

.items-scrollable-area::-webkit-scrollbar-thumb {
  background-color: var(--scrollbar-color);
  border-radius: 4px;
}

.items-scrollable-area::-webkit-scrollbar-thumb:hover {
  background-color: var(--scrollbar-hover-color);
}

.item-card {
  display: flex;
  flex-direction: column;
  transition: opacity .2s ease;
}

.item-card:hover {
  opacity: 0.8;
}

.item-field {
  width: 100%;
}

.default-field {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.item-card {
  position: relative;          /* 让绝对定位基于卡片 */
  transition: opacity .2s ease;
}

.action-buttons-container {
  position: absolute;
  top: 8px;
  right: 4px;
  display: flex;
  flex-direction: column; 
  gap: 8px;
}
</style>
