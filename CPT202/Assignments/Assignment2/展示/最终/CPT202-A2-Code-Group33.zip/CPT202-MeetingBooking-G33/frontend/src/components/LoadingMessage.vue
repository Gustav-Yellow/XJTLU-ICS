<template>
    <div class="loading-overlay">
      <div class="loading-text">{{ message }}</div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'LoadingMessage',
    props: {
      /** 要显示的文字 */
      message: {
        type: String,
        default: 'Redirecting...'
      }
    }
  };
  </script>
  
  <style scoped>
  .loading-overlay {
    position: fixed;
    top: 20%;               /* 屏幕高度的 20% 处 */
    left: 50%;
    transform: translateX(-50%);
    z-index: 1000;
  }
  
  .loading-text {
    color: #ffffff; 
    font-size: 48px;
    font-family: 'Rethink Sans', sans-serif;
    background: rgba(0, 0, 0, 0); 
    padding: 8px 16px;
    border-radius: 4px;
  }
  </style>
  