<template>
  <div v-if="visible" class="modal-overlay" @click.self="close">
    <div class="modal-panel" :style="panelStyles">
      <!-- 右上角关闭按钮 -->
      <button class="modal-close" @click="close">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x-icon lucide-x">
          <path d="M18 6 6 18"/>
          <path d="m6 6 12 12"/>
        </svg>
      </button>
      <!-- 弹窗内容区域，使用 slot 插槽方便传入任意内容 -->
      <div class="modal-content">
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Modal",
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    width: {
      type: String,
      default: "500px"
    },
    height: {
      type: String,
      default: "300px"
    },
    panelBgColor: {
      type: String,
      default: "#ffffff"
    },
    autoSize: {
      type: Boolean,
      default: false
    },
    autoWidth: {
      type: Boolean,
      default: false
    },
    autoHeight: {
      type: Boolean,
      default: false
    },
  },
  computed: {
    panelStyles() {
      if (this.autoSize) {
        return {
          backgroundColor: this.panelBgColor,
          minWidth: "300px",
          minHeight: "150px"
        };
      } else if (this.autoWidth) {
        return {
          minWidth: "300px",
          witdh:"auto",
          height: this.height,
          backgroundColor: this.panelBgColor
        };
      } else if (this.autoHeight) {
        return {
          minHeight: "150px",
          height: "auto",
          width: this.width,
          backgroundColor: this.panelBgColor
        };
      } else {
        return {
          width: this.width,
          height: this.height,
          backgroundColor: this.panelBgColor
        };
      }
    }
  },
  methods: {
    close() {
      this.$emit("close");
    }
  }
};
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5); /* 半透明黑色遮罩 */
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-panel {
  position: relative;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  overflow: visible;
}

.modal-close {
  position: absolute;
  top: 10px;
  right: 10px;
  background: transparent;
  border: none;
  cursor: pointer;
}

.modal-content {
  width: 100%;
  height: 100%;
  padding: 20px;
  box-sizing: border-box;
}
</style>
