<template>
    <div class="photo-editor">
      <div class="image-wrapper">
        <img :src="src" alt="photo" class="photo" />
        <div v-if="editable" class="edit-icon" @click="triggerFileInput">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
               viewBox="0 0 24 24" fill="none" stroke="currentColor"
               stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
               class="lucide lucide-pen-icon lucide-pen">
            <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174
                     a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622
                     l4.353-1.32a2 2 0 0 0 .83-.497z"/>
          </svg>
        </div>
        <input type="file" accept="image/*" ref="fileInput"
               @change="onFileChange" style="display: none;" />
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'PhotoEditor',
    model: {
      prop: 'value',
      event: 'input'
    },
    props: {
      value: {
        type: String,
        default: ''
      },
      editable: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        src: this.value
      };
    },
    watch: {
      value(newVal) {
        this.src = newVal;
      }
    },
    methods: {
      triggerFileInput() {
        this.$refs.fileInput.click();
      },
      onFileChange(e) {
        const file = e.target.files[0];
        if (!file) return;
        const url = URL.createObjectURL(file);
        this.src = url;
        this.$emit('input', this.src);
        this.$emit('upload', file);
        e.target.value = '';
      }
    }
  };
  </script>
  
  <style scoped>
  .image-wrapper {
    position: relative;
    margin: 16px;
  }
  .photo {
    width: 100%;
    border-radius: 12px;
    display: block;
    object-fit: cover;
  }
  .edit-icon {
    position: absolute;
    bottom: 8px;
    right: 8px;
    width: 32px;
    height: 32px;
    background: #333;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
  }
  .edit-icon svg {
    width: 16px;
    height: 16px;
    color: #fff;
  }
  </style>
  