<template>
    <div class="filter-item">
      <label>{{ label }}</label>
      <div class="range-row">
        <input
          type="number"
          v-model.number="min"
          :placeholder="placeholderMin"
          @blur="check"
        />
        <span class="dash">—</span>
        <input
          type="number"
          v-model.number="max"
          :placeholder="placeholderMax"
          @blur="check"
        />
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'RangeFilter',
    props: {
      /** v-model 对象 {min, max} */
      value:      { type: Object, default: () => ({}) },
      label:      String,
      placeholderMin: String,
      placeholderMax: String,
      defaultMin: Number,
      defaultMax: Number,
      validateFn: { type: Function, default: () => true }
    },
    data () {
      return {
        min: this.value.min !== undefined ? this.value.min : this.defaultMin,
        max: this.value.max !== undefined ? this.value.max : this.defaultMax
      };
    },
    watch: {
      /* 父值变化时同步 */
      value: {
        deep: true,
        handler(v) {
          if (v.min !== this.min) this.min = v.min;
          if (v.max !== this.max) this.max = v.max;
        }
      },
      /* 本地变化时 emit */
      min: 'emit',
      max: 'emit'
    },
    methods: {
      emit() { this.$emit('input', { min: this.min, max: this.max }); },
      check() {
        if (!this.validateFn({ min: this.min, max: this.max })) {
          this.min = this.defaultMin;
          this.max = this.defaultMax;
        }
      }
    }
  };
  </script>
  
  <style scoped>
    @import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

    .filter-item { 
    display: flex; 
    flex-direction: column; 
    gap: 4px;
    width: 100%;            /* 确保 filter-item 占满 panel 分配的空间 */
    }

    label { 
    color: #fff; 
    font-size: 14px; 
    }

    .range-row {
    display: flex;           /* 改成 flex 布局更直观 */
    gap: 4px; 
    width: 100%;             /* 占满父容器宽度 */
    }

    .range-row input {
    flex: 1 1 0;             /* 等比拉伸／收缩 */
    min-width: 0;            /* 允许缩到比内容更窄 */
    width: 100%;             /* 保证在 flex 下生效 */
    box-sizing: border-box;  /* 内外距都算在宽度里 */
    background: transparent; 
    border: 1px solid #444; 
    border-radius: 4px;
    padding: 6px 8px; 
    color: #fff;
    font-family: 'Rethink Sans', sans-serif; 
    font-weight: 400;
    }

    input::placeholder { 
    color: #9a9a9a; 
    }

    .dash { 
    color: #fff; 
    white-space: nowrap;     /* 确保中划线不换行 */
    }
    </style>
  