<template>
  <div class="filter-item">
    <label>{{ label }}</label>
    <select v-model="localVal" @change="emit">
      <option v-for="opt in options" :key="opt.id" :value="opt.id">
        {{ opt.label }}
      </option>
    </select>
  </div>
</template>

<script>
export default {
  name: 'SelectFilter',
  props: {
    value:        [String, Number],
    label:        String,
    options:      { type: Array, default: () => [] },
    defaultValue: [String, Number]
  },
  data () {
    return { localVal: this.value !== undefined ? this.value : this.defaultValue };
  },
  watch: {
    value (v) { this.localVal = v; }
  },
  methods: {
    emit () { this.$emit('input', this.localVal); }
  }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

.filter-item { 
  display: flex; 
  flex-direction: column; 
  gap: 4px; 
  width: 100%;
}
label { 
  color: #fff; 
  font-size: 14px; 
}
select {
  background: transparent; 
  border: 1px solid #444; 
  border-radius: 4px;
  padding: 6px 8px; 
  color: #fff;
  font-family: 'Rethink Sans', sans-serif; 
  font-weight: 400;
  width: 100%;
  box-sizing: border-box;
}
/* 下拉选项文字颜色 */
select option {
  color: #333;
}
</style>
