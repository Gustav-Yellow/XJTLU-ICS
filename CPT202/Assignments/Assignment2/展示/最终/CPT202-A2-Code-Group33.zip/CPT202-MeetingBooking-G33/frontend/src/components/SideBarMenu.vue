<template>
  <div class="sidebar-menu">
    <!-- 顶部菜单 -->
    <div
      class="menu-item"
      v-for="(item, index) in filteredMenuItems"
      :key="item.name"
      @click="navigate(item.path)"
      ref="menuItems"
      :data-path="item.path"
    >
      <span :class="{ active: activeRoute === item.path }">
        {{ item.label }}
      </span>
    </div>

    <!-- 菜单指示条 -->
    <div class="indicator" :style="indicatorStyle"></div>

    <!-- 底部用户信息 -->
    <div class="user-info" @click="navigate('/profile')">
      <img :src="avatarPath" alt="avatar" class="avatar" />
      <span class="username">{{ username }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SidebarMenu',

  props: {
    /* From parent */
    pageLoaded: { type: Boolean, required: true }
  },

  data() {
    return {
      menuItems: [
        { name: 'rooms',            label: 'Rooms',           path: '/rooms' },
        { name: 'my_bookings',      label: 'My Bookings',     path: '/my_bookings' },
        { name: 'users',            label: 'Users',           path: '/users',            adminOnly: true },
        { name: 'bookings_review',  label: 'Booking Review',  path: '/bookings_review',  adminOnly: true },
        { name: 'feedback',         label: 'Feedback',        path: '/feedback' },
        { name: 'profile',          label: 'Profile',         path: '/profile' }
      ],
      initialRender: true
    };
  },

  computed: {
    /* current route */
    activeRoute() {
      return this.$route.path;
    },

    indicatorStyle() {
      const top = this.initialRender
        ? (this.$store.state.sidebar.previousIndicatorTop ||
           this.$store.state.sidebar.currentIndicatorTop)
        : this.$store.state.sidebar.currentIndicatorTop;
      return { top: `${top}px` };
    },

    filteredMenuItems() {
      return this.menuItems.filter(item =>
        item.adminOnly ? this.$store.state.userinfo.role === 'ADMIN' : true
      );
    },
    username()    { return this.$store.state.userinfo.username; },
    avatarPath()  { return this.$store.state.userinfo.avatar_path; }
  },

  mounted() {
    if (this.pageLoaded) this.initializeIndicator();
  },

  watch: {
    pageLoaded(val) {
      if (val) this.initializeIndicator();
    },
    activeRoute() {
      if (!this.pageLoaded) return;
      this.$nextTick(this.setIndicatorPosition);
    }
  },

  methods: {
    initializeIndicator() {
      this.$nextTick(() => {
        this.setIndicatorPosition();
        setTimeout(() => (this.initialRender = false), 50);
      });
    },

    navigate(path) {
      this.$store.commit(
        'sidebar/setPreviousIndicatorTop',
        this.$store.state.sidebar.currentIndicatorTop
      );
      this.$router.push(path);
    },

    setIndicatorPosition() {
      const menuEls = this.$refs.menuItems;
      if (menuEls && menuEls.length) {
        const activeEl = menuEls.find(
          el => el.getAttribute('data-path') === this.activeRoute
        );
        if (activeEl) {
          this.$store.commit(
            'sidebar/setCurrentIndicatorTop',
            activeEl.offsetTop
          );
        }
      }
    }
  }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

.sidebar-menu {
  width: 250px;
  background-color: #1B1C20;
  height: 100vh;
  padding-top: 20px;
  position: fixed;
  left: 0;
  top: 0;
}

.menu-item {
  position: relative;
  padding: 15px 20px;
  color: #ffffff;
  font-family: 'Rethink Sans', sans-serif;
  font-size: 20px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}

.menu-item span { padding-left: 24px; }

.menu-item:first-of-type { margin-top: 40px; }

.menu-item:hover { color: white; }

.indicator {
  position: absolute;
  left: 0;
  width: 4px;
  height: 40px;
  background-color: #ffffff;
  transition: top 0.3s ease;
}

span.active {
  color: white;
  font-weight: 600;
}

.user-info {
  position: absolute;
  bottom: 40px;
  left: 0;
  width: 100%;
  padding: 0 20px;
  display: flex;
  align-items: center;
  cursor: pointer;          /* ← 新增：显示可点击 */
}

.avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  object-fit: cover;
}

.username {
  margin-left: 20px;
  color: #ffffff;
  font-family: 'Rethink Sans', sans-serif;
  font-size: 18px;
  font-weight: 600;
}
</style>
