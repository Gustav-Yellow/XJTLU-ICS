<template>
  <div class="editable-tag-container">
    <div class="tag-header">
      <span class="tag-prefix" :style="{ color: titleColor, fontSize: textSize + 'px' }">{{ title }}:</span>
    </div>
    <div class="tags-area" @click.self="finishEditing">
      <div 
        v-for="(tag, index) in localTags" 
        :key="'tag-' + index" 
        class="tag"
        :style="{ 
          backgroundColor: tagBgColor, 
          fontSize: textSize + 'px',
          padding: `${textSize * 0.3}px ${textSize * 0.8}px`,
          borderRadius: textSize * 0.4 + 'px',
          margin: `${textSize * 0.25}px ${textSize * 0.4}px ${textSize * 0.25}px 0`
        }"
      >
        <span :style="{ color: tagTextColor }">{{ tag }}</span>
        <span 
          v-if="editable" 
          class="delete-tag"
          @click="removeTag(index)"
          :style="{ fontSize: textSize * 0.8 + 'px' }"
        >×</span>
      </div>
      
      <!-- 编辑中的新标签 -->
      <div 
        v-if="isAddingTag"
        class="tag editing-tag"
        :style="{ 
          backgroundColor: tagBgColor, 
          fontSize: textSize + 'px',
          padding: `${textSize * 0.3}px ${textSize * 0.8}px`,
          borderRadius: textSize * 0.4 + 'px',
          margin: `${textSize * 0.25}px ${textSize * 0.4}px ${textSize * 0.25}px 0`
        }"
      >
        <input 
          ref="newTagInput"
          v-model="newTagText"
          class="tag-input"
          :style="{ 
            color: tagTextColor,
            fontSize: textSize + 'px',
            width: `${Math.max(20, newTagText.length * textSize * 0.6)}px`
          }"
          @keyup.enter="confirmNewTag"
          @blur="confirmNewTag"
          @click.stop
        />
      </div>
      
      <!-- 添加按钮 -->
      <div 
        v-if="editable && !isAddingTag"
        class="add-tag"
        @click="startAddingTag"
        :style="{ 
          backgroundColor: tagBgColor, 
          fontSize: textSize + 'px',
          width: textSize * 2 + 'px',
          height: textSize * 2 + 'px',
          borderRadius: textSize * 0.4 + 'px',
          margin: `${textSize * 0.25}px ${textSize * 0.4}px ${textSize * 0.25}px 0`
        }"
      >
        <span :style="{ color: tagTextColor }">+</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TagComponent',
  props: {
    title: {
      type: String,
      default: 'XXXX'
    },
    modelValue: {
      type: Array,
      default: () => ['Tag 1', 'Tag 2', 'Tag 3']
    },
    editable: {
      type: Boolean,
      default: false
    },
    titleColor: {
      type: String,
      default: '#FFFFFF'
    },
    tagBgColor: {
      type: String,
      default: '#444444'
    },
    tagTextColor: {
      type: String,
      default: '#FFFFFF'
    },
    textSize: {
      type: Number,
      default: 16
    }
  },
  data() {
    return {
      localTags: [...this.modelValue],
      isAddingTag: false,
      newTagText: ''
    }
  },
  methods: {
    removeTag(index) {
      const updatedTags = [...this.localTags];
      updatedTags.splice(index, 1);
      this.updateTags(updatedTags);
    },
    startAddingTag() {
      this.isAddingTag = true;
      this.newTagText = '';
      // 在下一个事件循环中聚焦到输入框
      this.$nextTick(() => {
        if (this.$refs.newTagInput) {
          this.$refs.newTagInput.focus();
        }
      });
    },
    confirmNewTag() {
      if (this.newTagText && this.newTagText.trim() !== '') {
        const updatedTags = [...this.localTags, this.newTagText.trim()];
        this.updateTags(updatedTags);
      }
      this.isAddingTag = false;
      this.newTagText = '';
    },
    finishEditing() {
      if (this.isAddingTag) {
        this.confirmNewTag();
      }
    },
    updateTags(tags) {
      this.localTags = tags;
      this.$emit('update:modelValue', tags);
    }
  },
  watch: {
    modelValue: {
      handler(newVal) {
        if (JSON.stringify(newVal) !== JSON.stringify(this.localTags)) {
          this.localTags = [...newVal];
        }
      },
      deep: true
    }
  }
}
</script>

<style scoped>

@import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

.editable-tag-container {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  background-color: transparent;
  padding: 6px 8px;
  border-radius: 4px;
}

.tag-header {
  display: flex;
  align-items: center;
  margin-bottom: 8px;
}

.tag-prefix {
  font-weight: 500;
  margin-right: 8px;
}

.tags-area {
  display: flex;
  flex-wrap: wrap;
  align-items: center; 
  padding-left: 0;
  width: 100%;
}

.tag {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  position: relative;
}

.editing-tag {
  min-width: 60px;
  height: 24px;
}

.tag-input {
  background: transparent;
  border: none;
  outline: none;
  padding: 0;
  min-width: 20px;
}

.delete-tag {
  position: absolute;
  top: -6px;
  right: -6px;
  cursor: pointer;
  font-weight: bold;
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  width: 16px;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  line-height: 1;
}

.add-tag {
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
</style>