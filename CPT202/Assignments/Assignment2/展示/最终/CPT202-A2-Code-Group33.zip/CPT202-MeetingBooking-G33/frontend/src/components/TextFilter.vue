<template>
    <div class="filter-item">
      <label>{{ label }}</label>
      <input
        type="text"
        v-model="localVal"
        :placeholder="placeholder"
        @blur="check"
      />
    </div>
  </template>
  
  <script>
  export default {
    name: 'TextFilter',
    props: {
      /** v-model 对应值 */
      value:        { type: String, default: '' },
      /** 额外配置 */
      label:        String,
      placeholder:  String,
      defaultValue: { type: String, default: '' },
      validateFn:   { type: Function, default: () => true }
    },
    data () {
      return { localVal: this.value || this.defaultValue };
    },
    watch: {
      value (v) { this.localVal = v; },
      localVal (v) { this.$emit('input', v); }
    },
    methods: {
      check () {
        if (!this.validateFn(this.localVal)) {
          this.localVal = this.defaultValue;
        }
      }
    }
  };
  </script>
  
  <style scoped>
  @import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');
  .filter-item { 
    display:flex; 
    flex-direction:column; 
    gap:4px; 
  }
  label { 
    color:#fff; 
    font-size:14px; 
  }
  input {
    background:transparent; 
    border:1px solid #444; 
    border-radius:4px;
    padding:6px 8px; 
    color:#fff;
    font-family:'Rethink Sans', sans-serif; 
    font-weight:400;
  }
  input::placeholder { 
    color:#9a9a9a; 
  }
  </style>
  