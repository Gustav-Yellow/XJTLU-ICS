<template>
  <div class="timeslot-container">
    <div class="timeslot-header">
      <div class="hour-label"></div>
      <div 
        v-for="(day, dayIndex) in weekDays" 
        :key="dayIndex" 
        class="day-header"
      >
        <div class="day-name">{{ day.dayName }}</div>
        <div class="day-date">{{ day.date }}</div>
      </div>
    </div>
    
    <div class="timeslot-grid">
      <!-- Time labels -->
      <div class="time-labels">
        <div 
          v-for="hour in hours" 
          :key="hour" 
          class="hour-label"
        >
          {{ hour }}:00
        </div>
        <div class="hour-label extra">23:00</div>
      </div>
    
      
      <!-- Grid cells -->
      <div class="grid-content">
        <div 
          v-for="(day, dayIndex) in weekDays" 
          :key="dayIndex" 
          class="day-column"
        >
          <div 
            v-for="hour in hours" 
            :key="`${dayIndex}-${hour}`" 
            class="time-cell"
            :class="{
              'occupied': isOccupied(dayIndex, hour),
              'selected': isSelected(dayIndex, hour)
            }"
            :style="{
              backgroundColor: getCellBackgroundColor(dayIndex, hour)
            }"
            @mousedown="startSelection(dayIndex, hour)"
            @mouseenter="dragSelection(dayIndex, hour)"
            @mouseup="endSelection"
          ></div>
        </div>
      </div>
    </div>
    
    <div class="legend">
      <div class="legend-item">
        <div class="legend-color" :style="{ backgroundColor: availableColor }"></div>
        <div class="legend-label">Available</div>
      </div>
      <div class="legend-item">
        <div class="legend-color" :style="{ backgroundColor: occupiedColor }"></div>
        <div class="legend-label">Occupied</div>
      </div>
      <div class="legend-item">
        <div class="legend-color" :style="{ backgroundColor: selectedColor }" ></div>
        <div class="legend-label">Selected</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TimeSlot',
  props: {
    modelValue: {
      type: Array,
      default: () => []
    },
    availableColor: {
      type: String,
      default: '#f5f5f5'
    },
    occupiedColor: {
      type: String,
      default: '#ffcccb'
    },
    selectedColor: {
      type: String,
      default: '#90ee90'
    },
    // Array of occupied slots in format: [{day: 0-6, hour: 9-22}, ...]
    occupiedSlots: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      hours: Array.from({ length: 14 }, (_, i) => i + 9), // 9:00 to 22:00
      weekDays: this.generateWeekDays(),
      isSelecting: false,
      selectionStart: null,
      selectionEnd: null,
      localSelectedSlots: [] // 用于临时保存选择
    };
  },
  created() {
    // 初始化时从 modelValue 复制数据
    this.localSelectedSlots = [...this.modelValue];
  },
  watch: {
    // 当外部 modelValue 变化时，更新内部状态
    modelValue: {
      handler(newValue) {
        this.localSelectedSlots = [...newValue];
      },
      deep: true
    }
  },
  methods: {
    generateWeekDays() {
      const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const today = new Date();
      
      return Array.from({ length: 7 }, (_, i) => {
        const date = new Date(today);
        date.setDate(today.getDate() + i);
        
        return {
          dayIndex: i,
          dayName: days[date.getDay()],
          date: `${date.getMonth() + 1}/${date.getDate()}`
        };
      });
    },
    
    isOccupied(dayIndex, hour) {
      return this.occupiedSlots.some(slot => 
        slot.day === dayIndex && slot.hour === hour
      );
    },
    
    isSelected(dayIndex, hour) {
      return this.localSelectedSlots.some(slot => 
        slot.day === dayIndex && slot.hour === hour
      );
    },
    
    getCellBackgroundColor(dayIndex, hour) {
      if (this.isSelected(dayIndex, hour)) {
        return this.selectedColor;
      } else if (this.isOccupied(dayIndex, hour)) {
        return this.occupiedColor;
      }
      return this.availableColor;
    },
    
    startSelection(dayIndex, hour) {
      if (this.isOccupied(dayIndex, hour)) {
        return; // Cannot select occupied slots
      }
      
      this.isSelecting = true;
      this.selectionStart = { day: dayIndex, hour };
      this.selectionEnd = { day: dayIndex, hour };
      this.updateSelectedSlots();
    },
    
    dragSelection(dayIndex, hour) {
      if (!this.isSelecting) return;
      
      // Only allow selection within the same day
      if (dayIndex === this.selectionStart.day && !this.isOccupied(dayIndex, hour)) {
        this.selectionEnd = { day: dayIndex, hour };
        this.updateSelectedSlots();
      }
    },
    
    endSelection() {
      if (!this.isSelecting) return;
      
      this.isSelecting = false;
      // 选择完成时发出事件，更新父组件的值
      this.$emit('update:modelValue', [...this.localSelectedSlots]);
    },
    
    updateSelectedSlots() {
      // Clear previous selection
      this.localSelectedSlots = [];
      
      const day = this.selectionStart.day;
      const startHour = Math.min(this.selectionStart.hour, this.selectionEnd.hour);
      const endHour = Math.max(this.selectionStart.hour, this.selectionEnd.hour);
      
      // Check if there are any occupied slots in the range
      let hasOccupied = false;
      for (let hour = startHour; hour <= endHour; hour++) {
        if (this.isOccupied(day, hour)) {
          hasOccupied = true;
          break;
        }
      }
      
      // If no occupied slots, add all slots in the range to selection
      if (!hasOccupied) {
        for (let hour = startHour; hour <= endHour; hour++) {
          this.localSelectedSlots.push({ day, hour });
        }
      }
    }
  }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Rethink+Sans:wght@400;600&display=swap');

.timeslot-container {
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 600;
  padding: 20px;
  margin: -10px 0;
  background-color: transparent;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.timeslot-header {
  display: flex;
  padding-bottom: 10px;
  margin-bottom: 15px;
}

.hour-label {
  width: 60px;
  text-align: right;
  padding-right: 10px;
  color: #ffffff;
  font-size: 14px;
}

.day-header {
  flex: 1;
  text-align: center;
  font-weight: bold;
  padding: 0 5px;
}

.day-name {
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 600;
  color:#ffffff;
  font-size: 14px;
  margin-bottom: 5px;
}

.day-date {
  font-size: 12px;
  color: #E4E4E4;
}

.timeslot-grid {
  display: flex;
  position: relative;
}

.time-labels {
  display: flex;
  flex-direction: column;
  margin-right: 10px;
}

.time-labels .hour-label {
  height: 35.5px;
  display: flex;
  align-items: flex-start;
  justify-content: flex-end;
}

.hour-label.extra {
  position: absolute;
  top: 495px;
  left: 0px;
  color: #ffffff;
  font-size: 14px;
}

.grid-content {
  flex: 1;
  display: flex;
}

.day-column {
  flex: 1;
  display: flex;
  flex-direction: column;
  margin: 0 2px;
}

.time-cell {
  height: 30px;
  border: 1px solid #ddd;
  border-radius: 3px;
  margin: 2px 0;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.time-cell:hover {
  opacity: 0.8;
}

.legend {
  display: flex;
  justify-content: center;
  margin-top: 20px;
  gap: 20px;
}

.legend-item {
  display: flex;
  align-items: center;
}

.legend-color {
  width: 15px;
  height: 15px;
  border: 1px solid #ddd;
  border-radius: 3px;
  margin-right: 5px;
}

.legend-label {
  color: #ffffff;
  font-weight: 400;
}
</style>