import Vue from 'vue';
import Router from 'vue-router';
import Login from '@/views/Login.vue';
import SignUp from '@/views/SignUp.vue';
import ResetPassword from '@/views/ResetPassword.vue';
import Profile from '@/views/Profile.vue';
import Rooms from '@/views/Rooms.vue';
import MyBookings from '@/views/MyBookings.vue'
import User from '@/views/User.vue';
import Feedback from '@/views/Feedback.vue';
import BookingsReview from '@/views/BookingsReview.vue';

Vue.use(Router);

export default new Router({
  routes: [
    { path: '/', redirect: '/login' },
    { path: '/login', component: Login },
    { path: '/signup', component: SignUp },
    { path: '/reset_password', component: ResetPassword},
    { path: '/profile', component: Profile},
    { path: '/rooms', component: Rooms},
    { path: '/my_bookings', component: MyBookings},
    { path: '/users', component: User},
    { path: '/feedback', component: Feedback},
    { path: '/bookings_review', component: BookingsReview},
  ],
});