export default {
  namespaced: true, 
  state: {
    previousIndicatorTop: 0,
    currentIndicatorTop: 0
  },
  mutations: {
    setPreviousIndicatorTop(state, value) {
      state.previousIndicatorTop = value;
    },
    setCurrentIndicatorTop(state, value) {
      state.currentIndicatorTop = value;
    }
  }
}