export default {
    namespaced: true, 
    state: {
        userid: -1,
        username: '',
        email: '',
        avatar_path: '',
        role: 'UNKONWN',
        is_locked: false,
    },
    mutations: {
        setUserID(state, value) {
            state.userid = value;
        },
        setUsername(state, value) {
            state.username = value;
        },
        setEmail(state, value) {
            state.email = value;
        },
        setAvatarPath(state, value) {
            state.avatar_path = value
        },
        setRole(state, value) {
            if (value != 'ADMIN') state.role = 'USER';
            else state.role = value;
        },
        setLocked(state, value) { 
            state.is_locked = value;
        }
    }
}