<template>
    <div class="background-page">
      <div class="profile-page">
      <div class="split-layout">
        <!-- 左侧 Sidebar -->
        <div class="sidebar-container">
          <sidebar-menu  :pageLoaded="pageLoaded" />
        </div>
        <!-- 右侧中央区域 -->
        <div v-if="pageLoaded" class="central-section-wrapper">
          <div class="central-section">
            <div class="section-container rooms-container">
              <h2>Booking Review</h2>
              <data-table 
                :headers="tableHeaders" 
                :data="getBookings"
                header-bg-color="transparent"
                :header-bg-opacity="1"
                body-bg-color="transparent"
                :body-bg-opacity="1"
                :allow-actions="true"
                :defaultPageSize="10"
                :showExtraIconButton="false"
                @row-click="openDetailModal"
                :showFilter="true"
                :filterConfig="[{ 
                    field:'room_name',      
                    type:'text',   
                    props:{ 
                      label:'Room',      
                      placeholder:'enter room name…',      
                      defaultValue:'',  
                      validateFn:v=>true
                    } 
                  }, { 
                    field:'username',
                    type:'text',   
                    props:{ 
                      label:'User',  
                      placeholder:'enter user name…',  
                      defaultValue:'',  
                      validateFn:v=>true 
                    } 
                  }, {
                    field: 'event_time',
                    type: 'daterange',         // ← 对应上面 componentMap 的键
                    props: {
                      label: 'Time',
                      placeholderMin: 'Start',
                      placeholderMax: 'End',
                      defaultMin: '',
                      defaultMax: ''
                    }
                  }, { 
                  field:'status',      
                  type:'select', 
                  props:{ 
                    label:'Status',  
                    options: getStatus, 
                    defaultValue:'' 
                  } 
                }, 
                ]"
                @filter-search="handleSearch"
                @filter-cancel="resetFilters"
                :action-visible="row => row.status == 'pending'"
              >
                <template #actions="{ row, rowIndex }">
                  <div class="action-buttons-container">
                    <icon-button
                      background-color="#488C46"
                      :border-enabled="false"
                      image-content='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-check-icon lucide-circle-check"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>'
                      image-color="transparent"
                      text-content="Accept"
                      text-color="#ffffff"
                      :size="14"
                      @click="openAcceptModal(row, rowIndex)"
                    />
                    <icon-button
                      background-color="#830A0A"
                      :border-enabled="false"
                      image-content='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>'
                      image-color="rgba(0, 0, 0, 0)"
                      text-content="Reject"
                      text-color="#ffffff"
                      :size="14"
                      @click="openRejectModal(row, rowIndex)"
                    />
                  </div>
                </template>
              </data-table>
            </div>
          </div>
        </div>
        <LoadingMessage v-else message="Redirecting..." />
      </div>
  
      <!-- Detail Modal -->
      <Modal :visible="showDetailModal" width="400px" autoHeight panelBgColor="#151517" @close="closeDetailModal">
        <h2>Booking {{ selectedBook ? selectedBook.id : '' }}</h2>
        <EditableLabel 
          prefix="Room"
          prefixColor="white"
          :modelValue="detailData.room"
          valueColor="white"
        />
        <EditableLabel 
          prefix="Subject"
          prefixColor="white"
          :modelValue="detailData.subject"
          valueColor="white"
        />
        <EditableLabel
          prefix="Start Time"
          prefixColor="white"
          :modelValue="detailData.start_time"
          valueColor="white"
        />
        <EditableLabel
          prefix="End Time"
          prefixColor="white"
          :modelValue="detailData.end_time"
          valueColor="white"
        />
        <EditableLabel
          prefix="Create Time"
          prefixColor="white"
          :modelValue="detailData.create_time"
          valueColor="white"
        />
        <EditableLabel
          prefix="Update Time"
          prefixColor="white"
          :modelValue="detailData.update_time"
          valueColor="white"
        />
      </Modal>
  
      <!-- Accept Modal -->
      <Modal :visible="showAcceptModal" width="500px" autoHeight panelBgColor="#151517" @close="closeAcceptModal">
        <h2>Accept Booking {{ selectedBook ? selectedBook.id : '' }}</h2>
        <EditableLabel 
          prefix="Review"
          prefixColor="white"
          :modelValue="acceptData.review"
          @update:modelValue="acceptData.review = $event"
          valueColor="white"
          :showEditButton="true"
        />
        <CustomButton 
          label="Accept"
          @click="confirmAccept" 
          :primary-bg-color="'rgba(72, 140, 70, 1)'"
          :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
          :primary-text-color="'#ffffff'"
        />
        <CustomButton
          label="Cancel" 
          @click="closeAcceptModal" 
          :primary-bg-color="'rgba(37, 40, 55, 1)'"
          :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
          :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
          :primary-text-color="'#ffffff'"
        />
      </Modal>
  
      <!-- Reject Modal -->
      <Modal :visible="showRejectModal" width="500px" height="280px" panelBgColor="#151517" @close="closeRejectModal">
        <h2>Reject Booking {{ selectedBook ? selectedBook.id : '' }}</h2>
        <EditableLabel 
          prefix="Review"
          prefixColor="white"
          :modelValue="rejectData.review"
          @update:modelValue="rejectData.review = $event"
          valueColor="white"
          :showEditButton="true"
        />
        <CustomButton 
            label="Reject" 
            @click="confirmReject" 
            :primary-bg-color="'rgba(131, 10, 10, 1)'"
            :primary-hover-bg-color="'rgba(131, 10, 10, 0.9)'"
            :primary-active-bg-color="'rgba(131, 10, 10, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
        <CustomButton
            label="Cancel" 
            @click="closeRejectModal" 
            :primary-bg-color="'rgba(37, 40, 55, 1)'"
            :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
            :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
      </Modal>
      </div>
    </div>
  </template>
  
  <script>
  
  import SidebarMenu from '@/components/SidebarMenu.vue';
  import DataTable from '@/components/DataTable.vue';
  import IconButton from '@/components/IconButton.vue';
  import Modal from '@/components/Modal.vue';
  import TimeSlot from '@/components/TimeSlot.vue';
  import CustomButton from '@/components/Button.vue';
  import EditableLabel from '@/components/EditableLabel.vue';
  import EditableSelect from '@/components/EditableSelect.vue';
  import Tag from '@/components/Tag.vue';
  import LoadingMessage from '@/components/LoadingMessage.vue';
  import axios from 'axios';
  import { formatDateTime } from '@/functions/formatDateTime';
  
  export default {
    name: 'BookingsReviewPage',
    components: {
      SidebarMenu,
      DataTable,
      IconButton,
      Modal,
      TimeSlot,
      CustomButton,
      EditableLabel,
      EditableSelect,
      Tag,
      LoadingMessage
    },
    data() {
      return {
        pageLoaded: false,

        profile: {
          role: this.$store.state.userinfo.role,
        },
  
        tableHeaders: [
          { key: 'id', label: 'ID' },
          { key: 'room', label: 'Room' },
          { key: 'user', label: 'User' },
          { key: 'start_time', label: 'Start Time' },
          { key: 'end_time', label: 'End Time' },
          { key: 'status', label: 'Status'}
        ],
        // 用来保存当前的所有缓存信息
        tableData: null,
        buildings: null,
        types: null,
        // 用来保存当前选中的房间数据 {id, name, type, location}
        selectedBook: null,
        // 控制弹窗的显示
        showDetailModal: false,
        showAcceptModal: false,
        showEditModal: false,
        showRejectModal: false,
        showAddModal: false,
  
        detailData: {
          room: '',
          subject: '',
          start_time: '',
          end_time: '',
          status: '',
          review_time: '',
          admin_reply: '',
          create_time: '',
          update_time: '',
        },
        acceptData: {
          review: '',
        },
        rejectData: {
          review: '',
        },
      };
    },
    mounted() {
        this.getUserInfo()
    },
    computed: {
      getBookings() {
        if (this.tableData) return this.tableData;
  
        // 这里补充获得所有预定信息的逻辑
        this.tableData = [
          { id: 1, room: 'SD 540', user: 'WoZhenDe', start_time: 'Feb 28th 14:00', end_time: 'Feb 28th 16:00', status: 'pending'}, // time 格式：月 日 时 方便阅读， status 记得首字母大写
          { id: 2, room: 'FB 514', user: 'XieBuDong', start_time: 'Feb 29th 17:00', end_time: 'Feb 29th 18:00', status: 'pending'},
          { id: 3, room: 'IR 102', user: 'LeAAAAAAA', start_time: 'Feb 29th 17:00', end_time: 'Feb 29th 18:00', status: 'cancelled'}
        ]
        return this.tableData;
      },

      getStatus() {
        return [
            {id: 'approved', label: 'Approved'},
            {id: 'rejected', label: 'Rejected'},
            {id: 'pending', label: 'Pending'},
            {id: 'cancelled', label: 'Cancelled'}
          ];
      }
    },
    methods: {
      userInfoComplete() {
        return this.$store.state.userinfo.username != null && this.$store.state.userinfo.username != '' &&
        this.$store.state.userinfo.userid != null && this.$store.state.userinfo.userid != '' &&
        this.$store.state.userinfo.email != null && this.$store.state.userinfo.email != '' &&
        this.$store.state.userinfo.avatar_path != null && this.$store.state.userinfo.avatar_path != '' &&
        (this.$store.state.userinfo.role == 'ADMIN' || this.$store.state.userinfo.role == 'USER') ;
      },
      async fetchAllInfos() {
        // 获取所有待处理的预订
        await this.fetchPendingBookings();
      },
      
      // 获取当前登录用户信息
      async getUserInfo() {
        if (this.userInfoComplete()){
          console.log(this.$store.state.userinfo.role);
          if (this.$store.state.userinfo.role == 'ADMIN') {
            await this.fetchAllInfos();
            this.pageLoaded = true;
          }
          else {
            this.$router.push('/rooms');
          }
          return;
        }
        try {
          const response = await axios.get('/api/user/me', { timeout: 5000 });
          console.log(response.data.code === 200);
          if (response.data.code === 200) {
            const userData = response.data.data
            
            // 更新Vuex中的用户信息
            this.$store.commit('userinfo/setUsername', userData.username);
            this.$store.commit('userinfo/setUserID', userData.user_id);
            this.$store.commit('userinfo/setRole', userData.role);
            this.$store.commit('userinfo/setLocked', userData.is_locked);
            if (userData.avatar_url)
              this.$store.commit('userinfo/setAvatarPath', userData.avatar_url);
            else
              this.$store.commit('userinfo/setAvatarPath', 'http://sulthbbxs.hd-bkt.clouddn.com/avatars/default.jpg');

            await this.fetchAllInfos();
            console.log('2', userData);
            this.pageLoaded = true;
          }
          else {
            this.$router.push('/login');
          }
        } catch (error) {
          console.error('Failed to fetch user info:', error);
          if (error.response && error.response.status === 401) {
            alert('Please login first')
          }
          this.$router.push('/login');
        }
      },
      async fetchPendingBookings() {
        try {
          // 使用/query接口代替/list接口，默认查询pending状态的预订
          const queryParams = {
            status: 'pending' // 默认查询待审批的预订
          };
          
          const response = await axios.post('/api/admin/bookings/query', queryParams, {
            timeout: 5000
          });
          
          if (response.data.code === 200) {
            // 转换后端数据格式为前端表格所需格式
            this.tableData = response.data.data.map(booking => ({
              id: booking.booking_id,
              user: booking.username || '', // 获取用户名
              room: booking.room_name || '',
              start_time: formatDateTime(booking.start_time),
              end_time: formatDateTime(booking.end_time),
              status: booking.status || 'pending' // 获取状态
            }));
          } else {
            console.error('获取预订列表失败:', response.data.message);
          }
        } catch (error) {
          console.error('获取预订列表错误:', error);
        }
      },
      
      // 获取当前选中预订的ID
      getBookID() {
        if (!this.selectedBook) return -1;
        return this.selectedBook.id;
      },
      
      async fetchBookingDetail(bookingId) {
        try {
          const response = await axios.get(`/api/admin/bookings/${bookingId}`, { timeout: 5000 });
          
          if (response.data.code === 200) {
            const booking = response.data.data;
            return {
              id: booking.booking_id,
              room: booking.room_name,
              roomid: booking.room_id,
              subject: booking.subject || 'No Subject', // 添加会议主题
              start_time: formatDateTime(booking.start_time),
              end_time: formatDateTime(booking.end_time),
              status: booking.status,
              review_time: booking.review_time ? formatDateTime(booking.review_time) : '',
              admin_reply: booking.admin_reply || '',
              create_time: formatDateTime(booking.created_at),
              update_time: formatDateTime(booking.updated_at)
            };
          } else {
            console.error('获取预订详情失败:', response.data.message);
            return null;
          }
        } catch (error) {
          console.error('获取预订详情错误:', error);
          return null;
        }
      },
      
      async getCurrentBookDetails() {
        const id = this.getBookID();
        if (id === -1) {
          return {
            id: -1, 
            room: '', 
            start_time: '', 
            end_time: '', 
            status: '',
            review_time: '', 
            admin_reply: '', 
            create_time: '', 
            update_time: ''
          };
        }
        
        const bookingDetail = await this.fetchBookingDetail(id);
        if (bookingDetail) {
          return bookingDetail;
        }
        
        return {
          id: id,
          room: this.selectedBook.room,
          roomid: 1,
          start_time: this.selectedBook.start_time,
          end_time: this.selectedBook.end_time,
          status: 'Pending',
          review_time: '',
          admin_reply: '',
          create_time: '',
          update_time: ''
        };
      },
      
      async setDetailModal() {
        try {
          const currentBooking = await this.getCurrentBookDetails();
          this.detailData.room = currentBooking.room;
          this.detailData.subject = currentBooking.subject; // 设置会议主题
          this.detailData.start_time = currentBooking.start_time;
          this.detailData.end_time = currentBooking.end_time;
          this.detailData.status = currentBooking.status;
          this.detailData.review_time = currentBooking.review_time;
          this.detailData.admin_reply = currentBooking.admin_reply;
          this.detailData.create_time = currentBooking.create_time;
          this.detailData.update_time = currentBooking.update_time;
        } catch (error) {
          console.error('获取会议详情失败:', error);
          alert('获取会议详情失败，请稍后再试');
        }
      },
      
      setAcceptModal() {
        this.acceptData.review = 'Your booking request has been approved.'
      },
      setRejectModal() {
        this.rejectData.review = 'Your booking request has been rejected.'
      },
      openAddRoomModal() {
        this.showAddModal = true;
        this.setAddModal();
      },
      openDetailModal(row){
        this.selectedBook = row;
        this.showDetailModal = true;
        this.setDetailModal();
      },
      openAcceptModal(row, rowIndex) {
        this.selectedBook = row;
        this.showAcceptModal = true;
        this.setAcceptModal();
      },
      openRejectModal(row, rowIndex) {
        this.selectedBook = row
        this.showRejectModal = true;
        this.setRejectModal();
      },
      closeDetailModal() {
        this.showDetailModal = false;
      },
      closeAcceptModal() {
        this.showAcceptModal = false;
      },
      closeRejectModal() {
        this.showRejectModal = false;
      },
      confirmAdd() {
        // 这里补充添加房间的逻辑 信息可通过addData获取
  
        console.log("Confirm add");
        this.tableData = null; // 清除缓存
      },
      async confirmAccept() {
        const id = this.getBookID();
        if (id === -1) return;
        
        try {
          const response = await axios.post(`/api/admin/bookings/${id}/approve`, null, {
            params: { adminReply: this.acceptData.review}, 
            timeout: 5000 
          });
          
          if (response.data.code === 200) {
            console.log('预订批准成功!');
            alert('Booking approved.');
          } else {
            console.error('预订批准失败:', response.data.message);
            alert('Booking approving failed: ' + response.data.message);
          }
        } catch (error) {
          console.error('预订批准错误:', error);
          alert('Booking approving failed, please try again later.');
        } finally {
          this.fetchPendingBookings();
          this.closeAcceptModal();
        }
      },
      
      async confirmReject() {
        const id = this.getBookID();
        if (id === -1) return;
        
        try {
          const response = await axios.post(`/api/admin/bookings/${id}/reject`, null, {
            params: { adminReply: this.rejectData.review}, 
            timeout: 5000
          });
          
          if (response.data.code === 200) {
            console.log('预订拒绝成功!');
            alert('Booking rejected.');
          } else {
            console.error('预订拒绝失败:', response.data.message);
            alert('Booking rejection failed: ' + response.data.message);
          }
        } catch (error) {
          console.error('预订拒绝错误:', error);
          alert('Booking rejection failed, please try again later.');
        } finally {
          this.fetchPendingBookings();
          this.closeRejectModal();
        }
      },

      async handleSearch(filters) {
        const room = filters.room_name || '';         // 房间名称搜索条件
        const user = filters.username || '';          // 用户名搜索条件
        const status = filters.status || '';          // 状态筛选条件

        // 获取时间范围，如果不存在则设为空字符串
        const { min = '', max = '' } = filters.event_time || {};

        console.log(
          `室名: ${room}, 用户名: ${user}, ` +
          `开始时间: ${min}, 结束时间: ${max}, 状态: ${status}`
        );

        try {
          // 构建查询参数
          const queryParams = {
            roomName: room,    // 房间名称
            username: user,    // 用户名
            status: status,    // 预约状态
            startTimeFrom: min ? new Date(min).toISOString() : '',  // 开始时间范围
            startTimeTo: max ? new Date(max).toISOString() : ''     // 结束时间范围
          };

          const response = await axios.post('/api/admin/bookings/query', queryParams, {
            timeout: 5000
          });
          
          if (response.data.code === 200) {
            // 转换后端数据格式为前端表格所需格式
            this.tableData = response.data.data.map(booking => ({
              id: booking.booking_id,
              user: booking.username || '',      // 获取用户名
              room: booking.room_name || '',     // 获取房间名称
              start_time: formatDateTime(booking.start_time),
              end_time: formatDateTime(booking.end_time),
              status: booking.status || ''       // 获取状态
            }));
          } else {
            console.error('筛选预订列表失败:', response.data.message);
          }
        } catch (error) {
          console.error('筛选预订列表错误:', error);
        }
      },
      
      async resetFilters() {
        // 重置筛选条件，恢复默认列表
        await this.fetchPendingBookings();
      }
    }
  };
  </script>
  
  <style scoped>
  h2 {
    font-family: 'Rethink Sans', sans-serif;
    font-size: 24px;
    color: #FFFFFF;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px solid #333333;
  }

  .background-page {
    background-color: #151517;
    height: 100%;
    width: 100%;
  }
  
  .profile-page {
    background-color: #151517;
    min-height: 100vh;
    display: flex;
    align-items: flex-start;
  }
  
  .split-layout {
    display: flex;
    width: 100%;
  }
  
  .sidebar-container {
    width: 250px;
    flex-shrink: 0;
  }
  
  .central-section-wrapper {
    flex: 1;
    display: flex;
    justify-content: center;
    padding: 0 20px;
  }
  
  .central-section {
    width: 100%;
    max-width: 1200px;
    padding: 30px 40px;
    background-color: #151517;
  }
  
  .rooms-container {
    margin-bottom: 30px;
    background-color: transparent;
    border-radius: 8px;
    padding: 30px;
  }
  
  .action-buttons-container {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    align-items: center;
  }
  </style>
