<template>
    <div class="background-page">
      <div class="profile-page">
      <div class="split-layout">
        <!-- 左侧 Sidebar -->
        <div class="sidebar-container">
          <sidebar-menu  :pageLoaded="pageLoaded" />
        </div>
        <!-- 右侧中央区域 -->
        <div v-if="pageLoaded" class="central-section-wrapper">
          <div class="central-section">
            <div v-if="isUser" class="section-container rooms-container">
              <h2>My Feedbacks</h2>
              <data-table 
                :headers="userTableHeaders" 
                :data="getUserFeedbacks"
                header-bg-color="transparent"
                :header-bg-opacity="1"
                body-bg-color="transparent"
                :body-bg-opacity="1"
                :allow-actions="true"
                :defaultPageSize="10"
                :showExtraIconButton="true"
                :extraIconButtonProps="{
                    backgroundColor: 'rgba(37, 40, 55, 1)',
                    borderEnabled: false,
                    imageContent: `
                    <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='transparent' stroke='#ffffff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-circle-plus-icon lucide-circle-plus'>
                    <circle cx='12' cy='12' r='10'/>
                    <path d='M8 12h8'/>
                    <path d='M12 8v8'/>
                    </svg>`,
                    imageColor: 'transparent',
                    textContent: 'Add',
                    textColor: '#ffffff',
                    size: 14
                }"
                @row-click="openUserDetailModal"
                @extra-icon-click="openAddModal"
              >
              <template #actions="{ row, rowIndex }">
                  <div class="action-buttons-container">
                  </div>
                </template>
              </data-table>
            </div>
            <div v-if="isAdmin" class="section-container rooms-container">
              <h2>Pending Feedbacks</h2>
              <data-table 
                :headers="adminTableHeaders" 
                :data="getPendingAdminFeedbacks"
                header-bg-color="transparent"
                :header-bg-opacity="1"
                body-bg-color="transparent"
                :body-bg-opacity="1"
                :allow-actions="true"
                :defaultPageSize="10"
                :showExtraIconButton="false"
                @row-click="openAdminDetailModal"
              >
                <template #actions="{ row, rowIndex }">
                  <div class="action-buttons-container">
                    <icon-button
                      background-color="#488C46"
                      :border-enabled="false"
                      image-content='
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-message-square-quote-icon lucide-message-square-quote">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1-2 2z"/>
                        <path d="M8 12a2 2 0 0 0 2-2V8H8"/>
                        <path d="M14 12a2 2 0 0 0 2-2V8h-2"/>
                      </svg>'
                      image-color="transparent"
                      text-content="Reply"
                      text-color="#ffffff"
                      :size="14"
                      @click="openReplyModal(row, rowIndex)"
                    />
                  </div>
                </template>
              </data-table>
            </div>
            <div v-if="isAdmin" class="section-container rooms-container">
              <h2>Resolved Feedbacks</h2>
              <data-table 
                :headers="userTableHeaders" 
                :data="getResolvedAdminFeedbacks"
                header-bg-color="transparent"
                :header-bg-opacity="1"
                body-bg-color="transparent"
                :body-bg-opacity="1"
                :allow-actions="false"
                :defaultPageSize="10"
                :showExtraIconButton="false"
                @row-click="openAdminDetailModal"
              >
              </data-table>
            </div>
          </div>
        </div>
        <LoadingMessage v-else message="Redirecting..." />
      </div>

      <!-- Add Modal -->
      <Modal :visible="showAddModal" width="500px" autoHeight panelBgColor="#151517" @close="closeAddModal">
        <h2>Add Feedback</h2>
        <EditableLabel 
          prefix="Feedback"
          prefixColor="white"
          :modelValue="addData.content"
          @update:modelValue="addData.content = $event"
          valueColor="white"
          :showEditButton="true"
        />
        <CustomButton 
          label="Send"
          @click="confirmAdd" 
          :primary-bg-color="'rgba(72, 140, 70, 1)'"
          :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
          :primary-text-color="'#ffffff'"
        />
        <CustomButton
          label="Cancel" 
          @click="closeReplyModal" 
          :primary-bg-color="'rgba(37, 40, 55, 1)'"
          :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
          :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
          :primary-text-color="'#ffffff'"
        />
      </Modal>
  
      <!-- Admin Detail Modal -->
      <Modal :visible="showAdminDetailModal" width="500px" autoHeight panelBgColor="#151517" @close="closeAdminDetailModal">
        <h2>Feedback {{ selectedFdback ? selectedFdback.feedback_id : '' }}</h2>
        <EditableLabel 
          prefix="User ID"
          prefixColor="white"
          :modelValue="detailData.user_id"
          valueColor="white"
        />
        <EditableLabel
          prefix="User Name"
          prefixColor="white"
          :modelValue="detailData.username"
          valueColor="white"
        />
        <EditableLabel
          prefix="Status"
          prefixColor="white"
          :modelValue="detailData.status"
          valueColor="white"
        />
        <EditableLabel
          prefix="Content"
          prefixColor="white"
          :modelValue="detailData.content"
          valueColor="white"
        />
        <EditableLabel
          prefix="Create Time"
          prefixColor="white"
          :modelValue="detailData.create_time"
          valueColor="white"
        />
        <EditableLabel
          v-if="detailData.reply != ''"
          prefix="Reply"
          prefixColor="white"
          :modelValue="detailData.reply"
          valueColor="white"
        />
        <EditableLabel
          v-if="detailData.reply_time != ''"
          prefix="Reply Time"
          prefixColor="white"
          :modelValue="detailData.reply_time"
          valueColor="white"
        />
      </Modal>

      <!-- User Detail Modal -->
      <Modal :visible="showUserDetailModal" width="500px" autoHeight panelBgColor="#151517" @close="closeUserDetailModal">
        <h2>Feedback {{ selectedFdback ? selectedFdback.feedback_id : '' }}</h2>
        <EditableLabel
          prefix="Status"
          prefixColor="white"
          :modelValue="detailData.status"
          valueColor="white"
        />
        <EditableLabel
          prefix="Content"
          prefixColor="white"
          :modelValue="detailData.content"
          valueColor="white"
        />
        <EditableLabel
          prefix="Create Time"
          prefixColor="white"
          :modelValue="detailData.create_time"
          valueColor="white"
        />
        <EditableLabel
          v-if="detailData.reply != ''"
          prefix="Reply"
          prefixColor="white"
          :modelValue="detailData.reply"
          valueColor="white"
        />
        <EditableLabel
          v-if="detailData.reply_time != ''"
          prefix="Reply Time"
          prefixColor="white"
          :modelValue="detailData.reply_time"
          valueColor="white"
        />
      </Modal>
  
      <!-- Reply Modal -->
      <Modal :visible="showReplyModal" width="500px" autoHeight panelBgColor="#151517" @close="closeReplyModal">
        <h2>Reply to Feedback {{ selectedFdback ? selectedFdback.feedback_id : '' }}</h2>
        <EditableLabel 
          prefix="Review"
          prefixColor="white"
          :modelValue="replyData.reply"
          @update:modelValue="replyData.reply = $event"
          valueColor="white"
          :showEditButton="true"
        />
        <CustomButton 
          label="Reply"
          @click="confirmReply" 
          :primary-bg-color="'rgba(72, 140, 70, 1)'"
          :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
          :primary-text-color="'#ffffff'"
        />
        <CustomButton
          label="Cancel" 
          @click="closeReplyModal" 
          :primary-bg-color="'rgba(37, 40, 55, 1)'"
          :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
          :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
          :primary-text-color="'#ffffff'"
        />
      </Modal>
      </div>
    </div>
  </template>
  
  <script>
  
  import SidebarMenu from '@/components/SidebarMenu.vue';
  import DataTable from '@/components/DataTable.vue';
  import IconButton from '@/components/IconButton.vue';
  import Modal from '@/components/Modal.vue';
  import TimeSlot from '@/components/TimeSlot.vue';
  import CustomButton from '@/components/Button.vue';
  import EditableLabel from '@/components/EditableLabel.vue';
  import EditableSelect from '@/components/EditableSelect.vue';
  import Tag from '@/components/Tag.vue';
  import LoadingMessage from '@/components/LoadingMessage.vue';
  import axios from 'axios';
  import { formatDateTime } from '@/functions/formatDateTime';
  
  export default {
    name: 'BookingsReviewPage',
    components: {
      SidebarMenu,
      DataTable,
      IconButton,
      Modal,
      TimeSlot,
      CustomButton,
      EditableLabel,
      EditableSelect,
      Tag,
      LoadingMessage
    },
    data() {
      return {
        pageLoaded: false,

        profile: {
          role: this.$store.state.userinfo.role,
        },
  
        userTableHeaders: [
          { key: 'feedback_id', label: 'ID' },
          { key: 'content', label: 'Content' },
          { key: 'status', label: 'Status' },
        ],
        
        adminTableHeaders: [
          { key: 'feedback_id', label: 'ID' },
          { key: 'content', label: 'Content' },
        ],

        // 用来保存当前的所有缓存信息
        userTableData: null,
        adminPendingTableData: null,
        adminResolvedTableData: null,

        buildings: null,
        types: null,
        // 用来保存当前选中的房间数据 {id, name, type, location}
        selectedFdback: null,
        // 控制弹窗的显示
        showAddModal: false,
        showAdminDetailModal: false,
        showUserDetailModal: false,
        showReplyModal: false,
  
        addData: {
          content: '',
        },
        detailData: {
          feedback_id: '',
          user_id: '',
          username: '',
          status: '',
          content: '',
          reply: '',
          create_time: '',
          reply_time: '',
        },
        replyData: {
          reply: '',
        },
      };
    },
    mounted() {
      // 判断是否已登录，并获取数据
      this.getUserInfo();
    },
    computed: {
      isAdmin(){
        return this.$store.state.userinfo.role == 'ADMIN';
      },
      isUser() {
        return this.$store.state.userinfo.role == 'USER';
      },
      getUserFeedbacks() {
        if (this.userTableData) return this.userTableData;
  
        // 这里补充获得所有用户自己反馈的逻辑
        this.userTableData = [
          {
            feedback_id: 3,
            status: "resolved",
            content: "The room projector was not working.",
          },
          {
            feedback_id: 4,
            status: "resolved",
            content: "The meeting room was too cold.",
          }
        ]
        return this.userTableData;
      },
      getPendingAdminFeedbacks() {
        if (this.adminPendingTableData) return this.adminPendingTableData;

        // 这里补充获得所有反馈的逻辑
        this.adminPendingTableData = [
          {
            feedback_id: 3,
            status: "resolved",
            content: "The room projector was not working.",
          },
          {
            feedback_id: 4,
            status: "resolved",
            content: "The meeting room was too cold.",
          }
        ]

        return this.adminPendingTableData;
      },
      getResolvedAdminFeedbacks() {
        if (this.adminResolvedTableData) return this.adminResolvedTableData;

        this.adminResolvedTableData = [
          {
            feedback_id: 3,
            status: "resolved",
            content: "The room projector was not working.",
          },
          {
            feedback_id: 4,
            status: "resolved",
            content: "The meeting room was too cold.",
          }
        ]

        return this.adminResolvedTableData;
      },
    },
    methods: {
      userInfoComplete() {
        return this.$store.state.userinfo.username != null && this.$store.state.userinfo.username != '' &&
        this.$store.state.userinfo.userid != null && this.$store.state.userinfo.userid != '' &&
        this.$store.state.userinfo.email != null && this.$store.state.userinfo.email != '' &&
        this.$store.state.userinfo.avatar_path != null && this.$store.state.userinfo.avatar_path != '' &&
        (this.$store.state.userinfo.role == 'ADMIN' || this.$store.state.userinfo.role == 'USER') ;
      },
      async fetchAllInfos() {
        if (this.isUser) {
          // 获取用户的待处理反馈和已解决反馈
          await this.fetchUserPendingFeedbacks();
          await this.fetchUserResolvedFeedbacks();
        } else if (this.isAdmin) {
          // 获取管理员查看的所有待处理反馈和已解决反馈
          await this.fetchAdminPendingFeedbacks();
          await this.fetchAdminResolvedFeedbacks();
        }
        else {
          console.log('Invalid user role');
        }
      },
      // 获取当前登录用户信息
      async getUserInfo() {
        if (this.userInfoComplete()){
            await this.fetchAllInfos();
            this.pageLoaded = true;
            return;
        }
        try {
          const response = await axios.get('/api/user/me', { timeout: 5000 });
          if (response.data.code === 200) {
            const userData = response.data.data;
            
            // 更新Vuex中的用户信息
            this.$store.commit('userinfo/setUsername', userData.username);
            this.$store.commit('userinfo/setUserID', userData.user_id);
            this.$store.commit('userinfo/setRole', userData.role);
            this.$store.commit('userinfo/setLocked', userData.is_locked);
            if (userData.avatar_url)
              this.$store.commit('userinfo/setAvatarPath', userData.avatar_url);
            else
              this.$store.commit('userinfo/setAvatarPath', 'http://sulthbbxs.hd-bkt.clouddn.com/avatars/default.jpg');

            await this.fetchAllInfos();

            this.pageLoaded = true;
          }
          else {
            this.$router.push('/login');
          }
        } catch (error) {
          console.error('Failed to fetch user info:', error);
          if (error.response && error.response.status === 401) {
            alert('Please login first')
          }
          this.$router.push('/login');
        }
      },
      // 获取用户的待处理反馈
      async fetchUserPendingFeedbacks() {
        try {
          const response = await axios.get('/api/feedback/allPending', { timeout: 5000 });
          
          if (response.data.code === 200) {
            // 合并所有用户反馈到一个列表中
            this.userTableData = response.data.data;
          } else {
            console.error('获取用户待处理反馈失败:', response.data.message);
          }
        } catch (error) {
          console.error('获取用户待处理反馈错误:', error);
        }
      },
      
      // 获取用户的已解决反馈
      async fetchUserResolvedFeedbacks() {
        try {
          const response = await axios.get('/api/feedback/allResolved', { timeout: 5000 });
          
          if (response.data.code === 200) {
            // 将已解决的反馈添加到用户反馈列表中
            if (this.userTableData) {
              this.userTableData = [...this.userTableData, ...response.data.data];
            } else {
              this.userTableData = response.data.data;
            }
          } else {
            console.error('获取用户已解决反馈失败:', response.data.message);
          }
        } catch (error) {
          console.error('获取用户已解决反馈错误:', error);
        }
      },
      
      // 获取管理员查看的所有待处理反馈
      async fetchAdminPendingFeedbacks() {
        try {
          const response = await axios.get('/api/admin/feedback/allPending', { timeout: 5000 });
          
          if (response.data.code === 200) {
            this.adminPendingTableData = response.data.data;
          } else {
            console.error('获取所有待处理反馈失败:', response.data.message);
          }
        } catch (error) {
          console.error('获取所有待处理反馈错误:', error);
        }
      },
      
      // 获取管理员查看的所有已解决反馈
      async fetchAdminResolvedFeedbacks() {
        try {
          const response = await axios.get('/api/admin/feedback/allResolved', { timeout: 5000 });
          
          if (response.data.code === 200) {
            this.adminResolvedTableData = response.data.data;
          } else {
            console.error('获取所有已解决反馈失败:', response.data.message);
          }
        } catch (error) {
          console.error('获取所有已解决反馈错误:', error);
        }
      },
      
      // 获取反馈详情
      async fetchFeedbackDetail(feedbackId) {
        try {
          const response = await axios.get(`/api/feedback/${feedbackId}`, { timeout: 5000 });
          
          if (response.data.code === 200) {
            const feedback = response.data.data;
            return {
              feedback_id: feedback.feedback_id,
              user_id: feedback.user_id,
              username: feedback.username,
              status: feedback.status,
              content: feedback.content,
              reply: feedback.reply || '',
              create_time: formatDateTime(feedback.create_time),
              reply_time: feedback.reply_time ? formatDateTime(feedback.reply_time) : ''
            };
          } else {
            console.error('获取反馈详情失败:', response.data.message);
            return null;
          }
        } catch (error) {
          console.error('获取反馈详情错误:', error);
          return null;
        }
      },
      
      // 获取当前选中反馈的详情
      async getCurrentFdbackDetails() {
        // 确保有选中的反馈
        if (!this.selectedFdback || !this.selectedFdback.feedback_id) {
          return {
            feedback_id: -1,
            user_id: '',
            username: '',
            status: '',
            content: '',
            reply: '',
            create_time: '',
            reply_time: ''
          };
        }
        
        // 获取反馈详情
        try {
          const response = await axios.get(`/api/feedback/${this.selectedFdback.feedback_id}`, { timeout: 5000 });
          
          if (response.data.code === 200) {
            const feedbackDetail = response.data.data;
            console.log("获取到的反馈详情:", feedbackDetail); // 调试日志
            return {
              feedback_id: feedbackDetail.feedback_id,
              user_id: feedbackDetail.user_id,
              username: feedbackDetail.username,
              status: feedbackDetail.status,
              content: feedbackDetail.content,
              reply: feedbackDetail.reply || '',
              create_time: formatDateTime(feedbackDetail.create_time),
              reply_time: feedbackDetail.reply_time ? formatDateTime(feedbackDetail.reply_time) : ''
            };
          } else {
            console.error('获取反馈详情失败:', response.data.message);
            return null;
          }
        } catch (error) {
          console.error('获取反馈详情错误:', error);
          return null;
        }
      },
      
      async setDetailModal() {
        try {
          const currentFeedback = await this.getCurrentFdbackDetails();
          if (!currentFeedback) {
            console.error("无法获取反馈详情");
            return;
          }
          
          console.log("设置详情模态框数据:", currentFeedback); // 调试日志
          
          this.detailData.feedback_id = currentFeedback.feedback_id;
          this.detailData.user_id = currentFeedback.user_id;
          this.detailData.username = currentFeedback.username;
          this.detailData.status = currentFeedback.status;
          this.detailData.content = currentFeedback.content;
          this.detailData.reply = currentFeedback.reply;
          this.detailData.create_time = currentFeedback.create_time;
          this.detailData.reply_time = currentFeedback.reply_time;
        } catch (error) {
          console.error("设置详情模态框时出错:", error);
        }
      },
      
      setAcceptModal() {
        this.acceptData.review = 'Your booking request has been approved.'
      },
      setRejectModal() {
        this.rejectData.review = 'Your booking request has been rejected.'
      },
      openAddModal() {
        this.showAddModal = true;
        this.setAddModal();
      },
      openAdminDetailModal(row){
        this.selectedFdback = row;
        this.showAdminDetailModal = true;
        this.setDetailModal();
      },
      openUserDetailModal(row){
        this.selectedFdback = row;
        this.showUserDetailModal = true;
        this.setDetailModal();
      },
      openReplyModal(row, rowIndex) {
        this.selectedFdback = row;
        this.showReplyModal = true;
        this.setAcceptModal();
      },
      closeAddModal() {
        this.showAddModal = false;
      },
      closeAdminDetailModal() {
        this.showAdminDetailModal = false;
      },
      closeUserDetailModal() {
        this.showUserDetailModal = false;
      },
      closeReplyModal() {
        this.showReplyModal = false;
      },
      async confirmAdd() {
        try {
          // 发送添加反馈请求
          const response = await axios.post('/api/feedback/add', {
            content: this.addData.content,
            timeout: 5000 
          });
          
          if (response.data.code === 200) {
            console.log('反馈添加成功!');
            alert('Feedback submitted.');
            // 刷新反馈列表
            this.fetchUserPendingFeedbacks();
            this.closeAddModal();
          } else {
            console.error('反馈添加失败:', response.data.message);
            alert('Feedback submit failed: ' + response.data.message);
          }
        } catch (error) {
          console.error('反馈添加错误:', error);
          alert('Feedback submit failed, please try again later.');
        }
      },
      async confirmReply() {
        if (!this.selectedFdback || !this.selectedFdback.feedback_id) return;
        
        try {
          // 发送回复反馈请求
          const response = await axios.post(`/api/admin/feedback/${this.selectedFdback.feedback_id}/reply`, {
            reply: this.replyData.reply,
            timeout: 5000 
          });
          
          if (response.data.code === 200) {
            console.log('反馈回复成功!');
            alert('Feedback replied.');
            // 刷新反馈列表
            this.fetchAdminPendingFeedbacks();
            this.fetchAdminResolvedFeedbacks();
            this.closeReplyModal();
          } else {
            console.error('反馈回复失败:', response.data.message);
            alert('Feedback reply failed: ' + response.data.message);
          }
        } catch (error) {
          console.error('反馈回复错误:', error);
          alert('Feedback reply failed, please try again later.');
        }
      },
      confirmReject() {
        let id = this.getBookID();
          if (id == -1) return;
  
          // 这里补充删除房间的逻辑
          console.log("Confirm delete " + id);
          this.userTableData = null; // 清除缓存
      },
    }
  };
  </script>
  
  <style scoped>
  h2 {
    font-family: 'Rethink Sans', sans-serif;
    font-size: 24px;
    color: #FFFFFF;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px solid #333333;
  }
  
  h4 {
    font-family: 'Rethink Sans', sans-serif;
    font-size: 18px;
    color: #DD2525;
    margin: 30px 0 10px;
  }

  .background-page {
    background-color: #151517;
    height: 100%;
    width: 100%;
  }
  
  .profile-page {
    background-color: #151517;
    min-height: 100vh;
    display: flex;
    align-items: flex-start;
  }
  
  .split-layout {
    display: flex;
    width: 100%;
  }
  
  .sidebar-container {
    width: 250px;
    flex-shrink: 0;
  }
  
  .central-section-wrapper {
    flex: 1;
    display: flex;
    justify-content: center;
    padding: 0 20px;
  }
  
  .central-section {
    width: 100%;
    max-width: 1200px;
    padding: 30px 40px;
    background-color: #151517;
  }
  
  .rooms-container {
    margin-bottom: 30px;
    background-color: transparent;
    border-radius: 8px;
    padding: 30px;
  }
  
  .action-buttons-container {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    align-items: center;
  }
  </style>
