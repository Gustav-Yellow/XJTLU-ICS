<template>
  <div class="login-page">
    <img class="bg-image" :src="backgroundImage" alt="Background" />
    <div class="form-container" ref="formContainer">
      <h2>Booking System</h2>
      <div class="fade-in" ref="fadeInContainer">
        <h3>Login</h3>
        <form @submit.prevent="handleLogin">
          <InputField
            id="username"
            label="Username / Email"
            align="left"
            placeholder="Please enter your username"
            v-model="form.username"
          />
          <InputField
            id="password"
            label="Password"
            type="password"
            align="left"
            placeholder="Please enter your password"
            v-model="form.password"
          />
          <Button 
            label="Login Account" 
            type="primary" 
            @click="handleLogin"
            :loading="isLoading"
          />
        </form>
        <div class="links">
          <Button label="Forget password?" type="secondary" @click="transitionToResetPassword"/>
          <h4>Don't have an account yet?</h4>
          <Button label="Register" type="secondary" @click="transitionToSignUp" />
        </div>
        <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import InputField from '@/components/InputField.vue';
import Button from '@/components/Button.vue';
import BgImage from '@/assets/background.png';
import axios from 'axios';

export default {
  name: 'Login',
  components: {
    InputField,
    Button,
  },
  data() {
    return {
      backgroundImage: BgImage,
      form: {
        username: '',
        password: '',
      },
      targetContainerHeightSignUp: '880px',
      targetContainerHeightResetPassword: '620px',
      isLoading: false,
      errorMessage: '',
      _errorTimeout: null,
    };
  },
  mounted() {
    const container = this.$refs.formContainer;
    container.style.height = 495 + 'px';
    
    // 检查是否已登录
    this.checkLoginStatus();
  },
  methods: {
    showError(msg, delay = 3000) {
      if (this._errorTimeout) {
        clearTimeout(this._errorTimeout);
      }
      this.errorMessage = msg;
      this._errorTimeout = setTimeout(() => {
        this.errorMessage = '';
        this._errorTimeout = null;
      }, delay);
    },

    userInfoComplete() {
        return this.$store.state.userinfo.username != null && this.$store.state.userinfo.username != '' &&
        this.$store.state.userinfo.userid != null && this.$store.state.userinfo.userid != '' &&
        this.$store.state.userinfo.email != null && this.$store.state.userinfo.email != '' &&
        this.$store.state.userinfo.avatar_path != null && this.$store.state.userinfo.avatar_path != '' &&
        (this.$store.state.userinfo.role == 'ADMIN' || this.$store.state.userinfo.role == 'USER') ;
    },
    async getUserInfo() {
      try {
        const response = await axios.get('/api/user/me', { timeout: 5000 });
        if (response.data.code === 200) {
          const userData = response.data.data;

          // 更新Vuex中的用户信息
          this.$store.commit('userinfo/setUsername', userData.username);
          this.$store.commit('userinfo/setUserID', userData.user_id);
          this.$store.commit('userinfo/setRole', userData.role);
          this.$store.commit('userinfo/setUsername', userData.username);
          this.$store.commit('userinfo/setLocked', userData.is_locked);
          if (userData.avatar_url)
            this.$store.commit('userinfo/setAvatarPath', userData.avatar_url);
          else
            this.$store.commit('userinfo/setAvatarPath', 'http://sulthbbxs.hd-bkt.clouddn.com/avatars/default.jpg');

          // 跳转到主页
          this.$router.push('/rooms');
        }
      } catch (error) {
        console.error('Failed to fetch user info:', error);
      }
    },

    // 检查用户是否已登录
    async checkLoginStatus() {
      if (this.userInfoComplete()) {
        // 用户已登录，直接跳转到主页
        this.$router.push('/rooms');
        return;
      }

      try {
        const userInfo = localStorage.getItem('userInfo');
        if (userInfo) {
          // 验证token是否有效
          const response = await axios.get('/api/user/me', { timeout: 5000 });
          if (response.data.code === 200) {
            // 用户已登录，获取登录信息，并尝试跳转
            await this.getUserInfo();
          }
        }
      } catch (error) {
        // 如果验证失败，清除本地存储的信息
        this.$store.commit('userinfo/setUsername', '');
        this.$store.commit('userinfo/setEmail', '');
        this.$store.commit('userinfo/setRole', '');
        this.$store.commit('userinfo/setAvatarPath', '');
        this.$store.commit('userinfo/setUserID', '');
        this.$store.commit('userinfo/setLocked', false);

        localStorage.removeItem('userInfo');
        console.log('Token verification failed, please log in again');
      }
    },
    
    async handleLogin() {
      if (this.isLoading) return;
      this.isLoading = true;
      this.errorMessage = '';
      
      try {
        // 构建登录请求数据
        const loginData = {
          user_account: this.form.username,
          password: this.form.password
        };
        // 发送登录请求到后端
        const response = await axios.post('/api/user/login', loginData, {
            headers: {
              'Content-Type': 'application/json'
            },
          });
        
        // 处理登录成功
        if (response.data.code === 200) {
          const userData = response.data.data;
          
          console.log(userData);
          // 存储用户信息到Vuex 
          this.$store.commit('userinfo/setUsername', userData.username);
          this.$store.commit('userinfo/setUserID', userData.user_id);
          this.$store.commit('userinfo/setRole', userData.role);
          this.$store.commit('userinfo/setUsername', userData.username);
          this.$store.commit('userinfo/setLocked', userData.is_locked);
          if (userData.avatar_url)
            this.$store.commit('userinfo/setAvatarPath', userData.avatar_url);
          else
            this.$store.commit('userinfo/setAvatarPath', 'http://sulthbbxs.hd-bkt.clouddn.com/avatars/default.jpg');
          
          // 存储到localStorage作为备份
          localStorage.setItem('userInfo', JSON.stringify(userData));
          
          console.log('Login successful!');
          
          // 登录成功后跳转到首页或其他页面
          this.$router.push('/rooms');
        } else {
          // 处理错误情况
          this.showError(response.data.message || 'Login failed. Please check your username and password.');
          console.error('Login failed:', this.errorMessage);
        }
      } catch (error) {
        // 处理网络错误或服务器错误
        console.error('Login error:', error);
        this.showError((error.response && error.response.data && error.response.data.message) || 'Login failed. Please try again later.');
      } finally {
        this.isLoading = false;
      }
    },
    transitionToSignUp() {
      const fadeInEl = this.$refs.fadeInContainer;
      const containerEl = this.$refs.formContainer;
      fadeInEl.classList.add('fade-out');
      fadeInEl.addEventListener(
        'animationend',
        () => {
          containerEl.style.height = this.targetContainerHeightSignUp;
          containerEl.addEventListener(
            'transitionend',
            () => {
              this.$router.push('/signup');
            },
            { once: true }
          );
        },
        { once: true }
      );
    },
    transitionToResetPassword() {
      const fadeInEl = this.$refs.fadeInContainer;
      const containerEl = this.$refs.formContainer;
      fadeInEl.classList.add('fade-out');
      fadeInEl.addEventListener(
        'animationend',
        () => {
          containerEl.style.height = this.targetContainerHeightResetPassword;
          containerEl.addEventListener(
            'transitionend',
            () => {
              this.$router.push('/reset_password');
            },
            { once: true }
          );
        },
        { once: true }
      );
    },
  },
};
</script>

<style scoped>
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes fadeOut {
  from { opacity: 1; }
  to { opacity: 0; }
}

.fade-in {
  animation: fadeIn 0.5s ease-out forwards;
}

.fade-out {
  animation: fadeOut 0.5s ease-out forwards;
}

.login-page {
  position: relative;
  overflow-y: auto;
}

.bg-image {
  display: block;
  width: 100%;
  height: auto;
}

.form-container {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(240, 242, 255, 0.85);
  padding: 30px 30px 15px;
  border-radius: 10px;
  width: 100%;
  max-width: 400px;
  text-align: center;
  transition: height 0.25s ease-out;
}

h2 {
  font-size: 42px;
  margin-bottom: 10px;
  font-family: 'Rethink Sans', sans-serif;
  color: #76778E;
  font-weight: 600;
}

h3 {
  font-size: 30px;
  margin: 0 0 20px 0;
  text-align: left;
  font-family: 'Rethink Sans', sans-serif;
  color: #252837;
  font-weight: 600;
}

h4 {
  font-size: 16px;
  margin: 0 0 -20px 0;
  font-family: 'Rethink Sans', sans-serif;
  font-weight: 600;
  color: #878787;
}

.links {
  margin-top: 5px;
}

.links button {
  margin: 5px 0;
}

.error-message {
  color: #d32f2f;
  font-size: 14px;
  margin-bottom: 10px;
  text-align: center;
}
</style>
