<template>
    <div class="profile-page">
      <div class="split-layout">
        <!-- 左侧 Sidebar -->
        <div class="sidebar-container">
          <sidebar-menu  :pageLoaded="pageLoaded" />
        </div>
        <!-- 右侧中央区域 -->
        <div v-if="pageLoaded" class="central-section-wrapper">
          <div class="central-section">
            <div class="section-container rooms-container">  
              <h2>My Bookings</h2>
              <data-table 
                :headers="tableHeaders" 
                :data="getBookings"
                header-bg-color="transparent"
                :header-bg-opacity="1"
                body-bg-color="transparent"
                :body-bg-opacity="1"
                :allow-actions="true"
                :defaultPageSize="10"
                :showExtraIconButton="false"
                :extraIconButtonProps="{
                  backgroundColor: 'rgba(37, 40, 55, 1)',
                  borderEnabled: false,
                  imageContent: `
                  <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='transparent' stroke='#ffffff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-circle-plus-icon lucide-circle-plus'>
                    <circle cx='12' cy='12' r='10'/>
                    <path d='M8 12h8'/>
                    <path d='M12 8v8'/>
                  </svg>`,
                  imageColor: 'transparent',
                  textContent: 'Add',
                  textColor: '#ffffff',
                  size: 14
                }"
                @row-click="openDetailModal"
              >
                <template #actions="{ row, rowIndex }">
                  <div class="action-buttons-container">
                    <icon-button
                      background-color="#175894"
                      :border-enabled="false"
                      image-content='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg>'
                      image-color="transparent"
                      text-content="Edit"
                      text-color="#ffffff"
                      :size="14"
                      @click="openEditModal(row, rowIndex)"
                    />
                    <icon-button
                      background-color="#830A0A"
                      :border-enabled="false"
                      image-content='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>'
                      image-color="rgba(0, 0, 0, 0)"
                      text-content="Delete"
                      text-color="#ffffff"
                      :size="14"
                      @click="openDeleteModal(row, rowIndex)"
                    />
                  </div>
                </template>
              </data-table>
            </div>
            <div class="section-container rooms-container">
              <h2>History Bookings</h2>
              <data-table 
                :headers="tableHeaders" 
                :data="getHistoryBookings"
                header-bg-color="transparent"
                :header-bg-opacity="1"
                body-bg-color="transparent"
                :body-bg-opacity="1"
                :allow-actions="true"
                :defaultPageSize="10"
                :showExtraIconButton="false"
                :extraIconButtonProps="{
                  backgroundColor: 'rgba(37, 40, 55, 1)',
                  borderEnabled: false,
                  imageContent: `
                  <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='transparent' stroke='#ffffff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-circle-plus-icon lucide-circle-plus'>
                    <circle cx='12' cy='12' r='10'/>
                    <path d='M8 12h8'/>
                    <path d='M12 8v8'/>
                  </svg>`,
                  imageColor: 'transparent',
                  textContent: 'Add',
                  textColor: '#ffffff',
                  size: 14
                }"
                @row-click="openDetailModal"
              >
              <template #actions="{ row, rowIndex }">
                  <div class="action-buttons-container">
                    <icon-button
                      background-color="#830A0A"
                      :border-enabled="false"
                      image-content='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>'
                      image-color="rgba(0, 0, 0, 0)"
                      text-content="Delete"
                      text-color="#ffffff"
                      :size="14"
                      @click="openDeleteHistoryModal(row, rowIndex)"
                    />
                  </div>
                </template>
              </data-table>
            </div>
          </div>
        </div>
        <LoadingMessage v-else message="Redirecting..." />
      </div>
  
      <!-- Detail Modal -->
      <Modal :visible="showDetailModal" :autoHeight="true" width="500px" panelBgColor="#151517" @close="closeDetailModal">
        <h2>My Booking {{ selectedBook ? selectedBook.id : '' }}</h2>
        <EditableLabel 
          prefix="Room"
          prefixColor="white"
          :modelValue="detailData.room"
          valueColor="white"
        />
        <EditableLabel
          prefix="Start Time"
          prefixColor="white"
          :modelValue="detailData.start_time"
          valueColor="white"
        />
        <EditableLabel
          prefix="End Time"
          prefixColor="white"
          :modelValue="detailData.end_time"
          valueColor="white"
        />
        <EditableLabel
          prefix="Status"
          prefixColor="white"
          :modelValue="detailData.status"
          valueColor="white"
        />
        <EditableLabel
          prefix="Create Time"
          prefixColor="white"
          :modelValue="detailData.created_at"
          valueColor="white"
        />
        <EditableLabel
          prefix="Update Time"
          prefixColor="white"
          :modelValue="detailData.updated_at"
          valueColor="white"
        />
        <EditableLabel
          v-if="detailData.review_time != ''"
          prefix="Review Time"
          prefixColor="white"
          :modelValue="detailData.review_time"
          valueColor="white"
        />
        <EditableLabel
          v-if="detailData.admin_reply != ''"
          prefix="Admin Reply"
          prefixColor="white"
          :modelValue="detailData.admin_reply"
          valueColor="white"
        />
      </Modal>
  
      <!-- Edit Modal -->
      <Modal :visible="showEditModal" width="700px" height="920px" panelBgColor="#151517" @close="closeEditModal">
        <h2>Edit Booking {{ selectedBook ? selectedBook.id : '' }}</h2>
        <EditableSelect
          prefix="Room"
          prefixColor="white"
          valueColor="white"
          :modelValue="editData.roomId"
          @update:modelValue="editData.roomId = $event"
          :options="getRooms"
          :showEditButton="true"
        />
        <TimeSlot
          :occupiedSlots="editData.occupiedSlots"
          :modelview="editData.selectedSlots"
          @update:modelValue="editData.selectedSlots = $event"
        />
         <CustomButton 
          label="Confirm"
          @click="confirmEdit" 
          :primary-bg-color="'rgba(72, 140, 70, 1)'"
          :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
          :primary-text-color="'#ffffff'"
        />
        <CustomButton
          label="Cancel" 
          @click="closeEditModal" 
          :primary-bg-color="'rgba(37, 40, 55, 1)'"
          :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
          :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
          :primary-text-color="'#ffffff'"
        />
      </Modal>
  
      <!-- Delete Modal -->
      <Modal :visible="showDeleteModal" width="500px" height="280px" panelBgColor="#151517" @close="closeDeleteModal">
        <h2>Delete Booking</h2>
        <h4>Delete booking {{ selectedBook ? selectedBook.id : '' }} ?</h4>
        <CustomButton 
            label="Delete" 
            @click="confirmDelete" 
            :primary-bg-color="'rgba(131, 10, 10, 1)'"
            :primary-hover-bg-color="'rgba(131, 10, 10, 0.9)'"
            :primary-active-bg-color="'rgba(131, 10, 10, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
        <CustomButton
            label="Cancel" 
            @click="closeDeleteModal" 
            :primary-bg-color="'rgba(37, 40, 55, 1)'"
            :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
            :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
      </Modal>

        <!-- Delete History Modal -->
      <Modal :visible="showDeleteHistoryModal" width="500px" height="280px" panelBgColor="#151517" @close="closeDeleteHistoryModal">
        <h2>Delete Booking History</h2>
        <h4>Delete booking history{{ selectedBook ? selectedBook.id : '' }} ?</h4>
        <CustomButton 
            label="Delete" 
            @click="confirmDeleteHistory" 
            :primary-bg-color="'rgba(131, 10, 10, 1)'"
            :primary-hover-bg-color="'rgba(131, 10, 10, 0.9)'"
            :primary-active-bg-color="'rgba(131, 10, 10, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
        <CustomButton
            label="Cancel" 
            @click="closeDeleteHistoryModal" 
            :primary-bg-color="'rgba(37, 40, 55, 1)'"
            :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
            :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
      </Modal>
    </div>
  </template>
  
  <script>
  import SidebarMenu from '@/components/SidebarMenu.vue';
  import DataTable from '@/components/DataTable.vue';
  import IconButton from '@/components/IconButton.vue';
  import Modal from '@/components/Modal.vue';
  import TimeSlot from '@/components/TimeSlot.vue';
  import CustomButton from '@/components/Button.vue';
  import EditableLabel from '@/components/EditableLabel.vue';
  import EditableSelect from '@/components/EditableSelect.vue';
  import Tag from '@/components/Tag.vue';
  import LoadingMessage from '@/components/LoadingMessage.vue';
  import axios from 'axios';
  
  export default {
    name: 'MyBookingsPage',
    components: {
      SidebarMenu,
      DataTable,
      IconButton,
      Modal,
      TimeSlot,
      CustomButton,
      EditableLabel,
      EditableSelect,
      LoadingMessage,
      Tag
    },
    data() {
      return {
        pageLoaded: false,

        profile: {
          role: this.$store.state.userinfo.role,
        },
  
        tableHeaders: [
          { key: 'id', label: 'ID' },
          { key: 'room', label: 'Room' },
          { key: 'start_time', label: 'Start Time' },
          { key: 'end_time', label: 'End Time' },
          { key: 'status', label: 'Status'}
        ],
        // 用来保存当前的所有缓存信息
        tableData: null,
        historyTableData: null,
        rooms: null,
        // 用来保存当前选中的预定数据条例 {id, room, start_time, end_time, status}
        selectedBook: null,

        loading: {
          bookings: false,
          historyBookings: false,
          rooms: false,
          detail: false
        },
        error: null,

        // 控制弹窗的显示
        showDetailModal: false,
        showEditModal: false,
        showDeleteModal: false,
        showDeleteHistoryModal: false,

        detailData: {
          room: '',
          start_time: '',
          end_time: '',
          status: '',
          review_time: '',
          admin_reply: '',
          created_at: '',
          updated_at: '',
        },
        editData: {
          name: '',
          roomId: '',
          occupiedSlots: [],
          selectedSlots: []
        },
        bookingDetail: null
      };
    },
    mounted() {
      // 判断是否已登录并尝试加载缓存信息
      this.getUserInfo();
    },
    watch: {
      'editData.roomId': function(newRoomId) {
        if (newRoomId) {
          this.fetchRoomOccupiedSlots(newRoomId);
        }
      }
    },
    computed: {
      getBookings() {
        if (this.tableData) return this.tableData;
        return [];
      },
      getHistoryBookings() {
        if (this.historyTableData) return this.historyTableData;
        return [];
      },
      getRooms() {
        if (this.rooms) return this.rooms;
        return [];
      }
    },
    methods: {
      userInfoComplete() {
        return this.$store.state.userinfo.username != null && this.$store.state.userinfo.username != '' &&
        this.$store.state.userinfo.userid != null && this.$store.state.userinfo.userid != '' &&
        this.$store.state.userinfo.email != null && this.$store.state.userinfo.email != '' &&
        this.$store.state.userinfo.avatar_path != null && this.$store.state.userinfo.avatar_path != '' &&
        (this.$store.state.userinfo.role == 'ADMIN' || this.$store.state.userinfo.role == 'USER') ;
    },
      async fetchAllInfos() {
        // 加载我的预订
        await this.fetchBookings();
        // 加载历史预订
        await this.fetchHistoryBookings();
        // 加载所有会议室（用于修改预订时选择）
        await this.fetchRooms();
      },
      // 获取当前登录用户信息
      async getUserInfo() {
        if (this.userInfoComplete()) {
          await this.fetchAllInfos();
          this.pageLoaded = true;
          return;
        }
        try {
          const response = await axios.get('/api/user/me', { timeout: 5000 });
          if (response.data.code === 200) {
            const userData = response.data.data;

            // 更新Vuex中的用户信息
            this.$store.commit('userinfo/setUsername', userData.username);
            this.$store.commit('userinfo/setUserID', userData.user_id);
            this.$store.commit('userinfo/setRole', userData.role);
            this.$store.commit('userinfo/setLocked', userData.is_locked);
            if (userData.avatar_url)
              this.$store.commit('userinfo/setAvatarPath', userData.avatar_url);
            else
              this.$store.commit('userinfo/setAvatarPath', 'http://sulthbbxs.hd-bkt.clouddn.com/avatars/default.jpg');

            await this.fetchAllInfos();
            this.pageLoaded = true;
          }
          else {
            this.$router.push('/login');
          }
        } catch (error) {
          console.error('Failed to fetch user info:', error);
          if (error.response && error.response.status === 401) {
            alert('Please login first');
          }
          // 如果未登录，重定向到登录页面
          this.$router.push('/login');
        }
      },
      // 获取当前用户的未来预订
      async fetchBookings() {
        this.loading.bookings = true;
        this.error = null;
        
        try {
          const response = await axios.get('/api/bookings/list', { timeout: 5000 });
          
          if (response.data.code === 200) {
            // 转换后端数据格式为前端表格所需格式
            this.tableData = response.data.data.map(booking => {
              // 格式化日期时间
              const startTime = this.formatDateTime(booking.start_time);
              const endTime = this.formatDateTime(booking.end_time);
              
              return {
                id: booking.booking_id,
                room: booking.room_name,
                start_time: startTime,
                end_time: endTime,
                status: booking.status.charAt(0).toUpperCase() + booking.status.slice(1).toLowerCase()
              };
            });
          } else {
            this.error = response.data.message || 'Get booking list failed';
            console.error('Get booking list failed:', this.error);

            this.tableData = [{
                  id: 1,
                  room: 'PLACEHOLDER',
                  start_time: 'PLACEHOLDER',
                  end_time: 'PLACEHOLDER',
                  status: 'pending'
                }, {
                  id: 2,
                  room: 'PLACEHOLDER',
                  start_time: 'PLACEHOLDER',
                  end_time: 'PLACEHOLDER',
                  status: 'pending'
                }];
          }
        } catch (error) {
          this.error = error.message || 'Network error, please try again later';
          console.error('Get booking list error:', error);
          // 使用后备数据
          this.tableData = [{
                  id: 1,
                  room: 'PLACEHOLDER',
                  start_time: 'PLACEHOLDER',
                  end_time: 'PLACEHOLDER',
                  status: 'pending'
                }, {
                  id: 2,
                  room: 'PLACEHOLDER',
                  start_time: 'PLACEHOLDER',
                  end_time: 'PLACEHOLDER',
                  status: 'pending'
                }];
        } finally {
          this.loading.bookings = false;
        }
        
      },
      
      // 获取当前用户的历史预订
      async fetchHistoryBookings() {
        this.loading.historyBookings = true;
        
        try {
          const response = await axios.get('/api/bookings/history', { timeout: 5000 });
          
          if (response.data.code === 200) {
            // 转换后端数据格式为前端表格所需格式
            this.historyTableData = response.data.data.map(booking => {
              // 格式化日期时间
              const startTime = this.formatDateTime(booking.start_time);
              const endTime = this.formatDateTime(booking.end_time);
              
              return {
                id: booking.booking_id,
                room: booking.room_name,
                start_time: startTime,
                end_time: endTime,
                status: booking.status.charAt(0).toUpperCase() + booking.status.slice(1).toLowerCase()
              };
            });
          } else {
            console.error('Get history booking list failed:', response.data.message);

            // 使用后备数据
            this.historyTableData = [{
                id: 1,
                room: 'PLACEHOLDER',
                start_time: 'PLACEHOLDER',
                end_time: 'PLACEHOLDER',
                status: 'pending'
              }, {
                id: 2,
                room: 'PLACEHOLDER',
                start_time: 'PLACEHOLDER',
                end_time: 'PLACEHOLDER',
                status: 'pending'
              }];
          }
        } catch (error) {
          console.error('Get history booking list error:', error);
          // 使用后备数据
          this.historyTableData = [{
                  id: 1,
                  room: 'PLACEHOLDER',
                  start_time: 'PLACEHOLDER',
                  end_time: 'PLACEHOLDER',
                  status: 'pending'
                }, {
                  id: 2,
                  room: 'PLACEHOLDER',
                  start_time: 'PLACEHOLDER',
                  end_time: 'PLACEHOLDER',
                  status: 'pending'
                }];

        } finally {
          this.loading.historyBookings = false;
        }

      },
      
      // 获取所有会议室列表（用于修改预订时选择）
      async fetchRooms() {
        this.loading.rooms = true;
        
        try {
          const response = await axios.get('/api/rooms/list', { timeout: 5000 });
          
          if (response.data.code === 200) {
            this.rooms = response.data.data.map(room => ({
              id: room.room_id,
              label: room.room_name
            }));
          } else {
            console.error('Get room list failed:', response.data.message);
          }
        } catch (error) {
          console.error('Get room list error:', error);
        } finally {
          this.loading.rooms = false;
        }
      },
      
      // 获取预订详情
      async fetchBookingDetail(bookingId) {
        this.loading.detail = true;
        
        try {
          const response = await axios.get(`/api/bookings/${bookingId}`, { timeout: 5000 });
          
          if (response.data.code === 200) {
            return response.data.data;
          } else {
            console.error('Get booking detail failed:', response.data.message);
            return null;
          }
        } catch (error) {
          console.error('Get booking detail error:', error);
          return null;
        } finally {
          this.loading.detail = false;
        }
      },
      
      // 获取会议室的已占用时间槽
      async fetchRoomOccupiedSlots(roomId) {
        try {
          // 获取会议室详情（包括已预订的时间槽）
          const response = await axios.get(`/api/rooms/${roomId}`, { timeout: 5000 });
          
          if (response.data.code === 200) {
            const roomDetail = response.data.data;
            this.editData.occupiedSlots = this.processOccupiedSlots(roomDetail.recent_bookings);
          } else {
            console.error('Get room occupied slots failed:', response.data.message);
            // 后备方案
            this.editData.occupiedSlots = this.processOccupiedSlots([
              { start_time: "2025-04-30T09:00:00", end_time: "2025-04-30T11:00:00" },
              { start_time: "2025-05-01T14:00:00", end_time: "2025-05-01T16:00:00" },
            ]);
          }
        } catch (error) {
          console.error('Get room occupied slots error:', error);
          // 后备方案
          this.editData.occupiedSlots = this.processOccupiedSlots([
              { start_time: "2025-04-30T09:00:00", end_time: "2025-04-30T11:00:00" },
              { start_time: "2025-05-01T14:00:00", end_time: "2025-05-01T16:00:00" },
            ]);
        }
      },
      
      processOccupiedSlots(bookings) {
        const WORK_START = 9;   // 工作时段开始小时（可根据需要调整）
        const WORK_END   = 22;  // 工作时段结束小时（可根据需要调整）
        
        // 初始化一个空的时间槽数组
        const slots = [];
        const today = new Date();
        const todayZero = new Date(today);
        todayZero.setHours(0, 0, 0, 0);
        
        const msPerDay = 24 * 60 * 60 * 1000;
        
        // 处理预订时间槽
        if (bookings && bookings.length > 0) {
          bookings.forEach(booking => {
            const start = new Date(booking.start_time);
            const end   = new Date(booking.end_time);
    
            // 用"凌晨"时间来算相差的天数
            const startZero = new Date(start);
            startZero.setHours(0, 0, 0, 0);
            const endZero = new Date(end);
            endZero.setHours(0, 0, 0, 0);
    
            const dayStart = Math.floor((startZero - todayZero) / msPerDay);
            const dayEnd   = Math.floor((endZero   - todayZero) / msPerDay);
    
            // 如果结束日期在 7 天外或结束在今天之前，跳过
            if (dayEnd < 0 || dayStart > 6) return;
    
            // 遍历每一天，把该天对应小时段都标为 occupied
            for (let d = dayStart; d <= dayEnd; d++) {
              if (d < 0 || d > 6) continue;
    
              // 当天的开始小时
              const hStart = (d === dayStart)
                ? start.getHours()
                : WORK_START;
    
              // 当天的结束小时（不含这一小时）
              const hEnd = (d === dayEnd)
                ? end.getHours()
                : WORK_END + 1;
    
              for (let h = hStart; h < hEnd; h++) {
                // 只标记工作时间范围内的小时
                if (h >= WORK_START && h <= WORK_END) {
                  slots.push({ day: d, hour: h });
                }
              }
            }
          });
        }
    
        // 把"今天"已经过去的整点当作 occupied（无论是否有booking）
        // 例如当前 12:17，就把 9、10、11、12 都标为占用
        const now = new Date();
        const currentHour = now.getHours();
        for (let h = WORK_START; h <= Math.min(currentHour, WORK_END); h++) {
          slots.push({ day: 0, hour: h });
        }
    
        // 去重
        const unique = [];
        const seen = new Set();
        slots.forEach(s => {
          const key = `${s.day}-${s.hour}`;
          if (!seen.has(key)) {
            seen.add(key);
            unique.push(s);
          }
        });
    
        return unique;
      },
      
      // 格式化日期时间
      formatDateTime(dateTimeStr) {
        const date = new Date(dateTimeStr);
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        
        const month = months[date.getMonth()];
        const day = date.getDate();
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        
        // 获取日期后缀 (st, nd, rd, th)
        let suffix = 'th';
        if (day % 10 === 1 && day !== 11) suffix = 'st';
        else if (day % 10 === 2 && day !== 12) suffix = 'nd';
        else if (day % 10 === 3 && day !== 13) suffix = 'rd';
        
        return `${month} ${day}${suffix} ${hours}:${minutes}`;
      },
      
      getBookID() {
        return this.selectedBook ? this.selectedBook.id : -1;
      },
      
      async getCurrentBookDetails() {
        const id = this.getBookID();
        if (id === -1) {
          return {
            id: -1, 
            room: '', 
            start_time: '', 
            end_time: '', 
            status: '',
            review_time: '', 
            admin_reply: '', 
            created_at: '', 
            updated_at: ''
          };
        }
  
        // 获取预订详情
        const bookingDetail = await this.fetchBookingDetail(id);
        
        if (bookingDetail) {
          this.bookingDetail = bookingDetail;
          
          return {
            id: id,
            room: bookingDetail.room_name,
            roomId: bookingDetail.room_id,
            start_time: this.formatDateTime(bookingDetail.start_time),
            end_time: this.formatDateTime(bookingDetail.end_time),
            status: bookingDetail.status.charAt(0).toUpperCase() + bookingDetail.status.slice(1).toLowerCase(),
            review_time: bookingDetail.review_time ? this.formatDateTime(bookingDetail.review_time) : '',
            admin_reply: bookingDetail.admin_reply || '',
            created_at: this.formatDateTime(bookingDetail.created_at),
            updated_at: bookingDetail.updated_at ? this.formatDateTime(bookingDetail.updated_at) : ''
          };
        }
        
        // 如果没有获取到详情，则使用表格中的数据
        return {
          id: id,
          room: this.selectedBook.room,
          roomId: '',
          start_time: this.selectedBook.start_time,
          end_time: this.selectedBook.end_time,
          status: this.selectedBook.status,
          review_time: '',
          admin_reply: '',
          created_at: '',
          updated_at: ''
        };
      },

      async getCurrentRoomDetails() {
        let id = this.getRoomID();
        if (id === -1) {
          return {
            name: '', 
            type: '', 
            typeid: 1, 
            locationid: 1, 
            location: '',
            capacity: '', 
            description: '', 
            facilities: [], 
            imageUrl: '', 
            occupiedSlots: []
          };
        }

        // 获取会议室详情
        const roomDetail = await this.fetchRoomDetail(id);
        if (roomDetail) {
          this.roomDetail = roomDetail;
          
          // 处理占用时间槽，从recent_bookings中获取数据
          this.occupiedSlots = this.processOccupiedSlots(roomDetail.recent_bookings);
          
          const result = {
            name: roomDetail.room_name || '',
            typeid: roomDetail.type_id || 1,
            type: roomDetail.type_name || '',
            locationid: roomDetail.building_id || 1,
            location: roomDetail.building_name || '',
            capacity: roomDetail.capacity ? roomDetail.capacity.toString() : '0',
            description: roomDetail.description || 'No description',
            facilities: roomDetail.facilities || [],
            imageUrl: roomDetail.image_url || " ",
            occupiedSlots: this.occupiedSlots
          };
    
          return result;
      }
      
      return {
        name: this.selectedRoom.name, 
        typeid: 1, 
        type: this.selectedRoom.type,
        locationid: 1, 
        location: this.selectedRoom.location,
        capacity: '10', 
        description: 'A normal meeting room', 
        facilities: ['Projector', 'Microphone', 'Screen'], 
        imageUrls: [],
        occupiedSlots: []
      };
    },
      
      async setDetailModal() {
        const currentBooking = await this.getCurrentBookDetails();

        this.detailData.room = currentBooking.room;
        this.detailData.start_time = currentBooking.start_time;
        this.detailData.end_time = currentBooking.end_time;
        this.detailData.status = currentBooking.status;
        this.detailData.review_time = currentBooking.review_time;
        this.detailData.admin_reply = currentBooking.admin_reply;
        this.detailData.created_at = currentBooking.created_at;
        this.detailData.updated_at = currentBooking.updated_at;
      },
      
      async setEditModal() {
        const currentBooking = await this.getCurrentBookDetails();
        this.editData.roomId = currentBooking.roomId;
        // 初始化选中的时间槽
        this.editData.selectedSlots = [];
        // 获取该会议室的已占用时间槽
        await this.fetchRoomOccupiedSlots(currentBooking.roomId);
      },
      
      async openDetailModal(row) {
        this.selectedBook = row;
        this.showDetailModal = true;
        await this.setDetailModal();
      },
      
      async openEditModal(row, rowIndex) {
        this.selectedBook = row;
        this.showEditModal = true;
        await this.setEditModal();
      },
      
      openDeleteModal(row, rowIndex) {
        console.log("Delete booking", row, rowIndex);
        this.selectedBook = row;
        this.showDeleteModal = true;
      },
      
      openDeleteHistoryModal(row, rowIndex) {
        console.log("Delete history booking", row, rowIndex);
        this.selectedBook = row;
        this.showDeleteHistoryModal = true;
      },
      
      closeDetailModal() {
        this.showDetailModal = false;
      },
      
      closeEditModal() {
        this.showEditModal = false;
      },
      
      closeDeleteModal() {
        this.showDeleteModal = false;
      },
      
      closeDeleteHistoryModal() {
        this.showDeleteHistoryModal = false;
      },

      toLocalISOString(date) {
        // 用毫秒 + 时区偏移，转换回 UTC 
        const tzOffset = date.getTimezoneOffset() * 60000;
        const localISO = new Date(date - tzOffset)
          .toISOString()
          .slice(0, -5);
        return localISO;
      },
      
      async confirmEdit() {
        const id = this.getBookID();
        if (id === -1) return;
          
        try {
          // 检查是否选择了时间槽
          if (!this.editData.selectedSlots || this.editData.selectedSlots.length === 0) {
            alert('Please choose at least one time slot');
            return;
          }
          
          // 对选中的时间槽进行排序（按日期和小时排序）
          const sortedSlots = [...this.editData.selectedSlots].sort((a, b) => {
            if (a.day !== b.day) {
              return a.day - b.day;
            }
            return a.hour - b.hour;
          });
          
          // 检查是否所有时间槽都在同一天
          const firstDay = sortedSlots[0].day;
          const allSameDay = sortedSlots.every(slot => slot.day === firstDay);
          
          if (!allSameDay) {
            alert('Not allowed to book across days, please choose slots on the same day.');
            return;
          }
          
          // 检查时间槽是否连续
          let isConsecutive = true;
          for (let i = 1; i < sortedSlots.length; i++) {
            const prevSlot = sortedSlots[i-1];
            const currSlot = sortedSlots[i];
            
            // 小时必须连续
            if (currSlot.hour !== prevSlot.hour + 1) {
              isConsecutive = false;
              break;
            }
          }
          
          if (!isConsecutive) {
            alert('Please choose consecutive time slots.');
            return;
          }
          
            // 创建开始时间（第一个时间槽）
            const firstSlot = sortedSlots[0];
            const startDate = new Date();
            startDate.setDate(startDate.getDate() + firstSlot.day);
            startDate.setHours(firstSlot.hour, 0, 0, 0);
            
            // 创建结束时间（最后一个时间槽结束时间）
            const lastSlot = sortedSlots[sortedSlots.length - 1];
            const endDate = new Date();
            endDate.setDate(endDate.getDate() + lastSlot.day);
            endDate.setHours(lastSlot.hour + 1, 0, 0, 0); // 结束时间是最后一个槽的下一个小时
            
            // 准备修改预订的数据，使用本地格式的日期时间字符串
            const modifyData = {
              room_id: this.editData.roomId,
              start_time: this.toLocalISOString(startDate),
              end_time: this.toLocalISOString(endDate),
            };
          
          // 发送修改预订请求
          const response = await axios.post(`/api/bookings/${id}/modify`, modifyData, { timeout: 5000 });
          
          if (response.data.code === 200) {
            console.log('Edit booking successful!');
            alert('Edit booking successful!');
            // 刷新预订列表
            this.fetchBookings();
            this.closeEditModal();
          } else {
            console.error('Edit booking failed:', response.data.message);
            alert('Edit booking failed: ' + response.data.message);
          }
        } catch (error) {
          console.error('Edit booking error:', error);
          alert('Edit booking failed, please try again later');
        }
      },
      
      async confirmDelete() {
        const id = this.getBookID();
        if (id === -1) return;
  
        try {
          // 发送取消预订请求
          const response = await axios.get(`/api/bookings/${id}/cancel`, { timeout: 5000 });
          
          if (response.data.code === 200) {
            console.log('Delete booking successful!');
            alert('Delete booking successful!');
            // 刷新预订列表
            this.fetchBookings();
            this.closeDeleteModal();
          } else {
            console.error('Delete booking failed:', response.data.message);
            alert('Delete booking failed: ' + response.data.message);
            this.$router.push('/login');
          }
        } catch (error) {
          console.error('Delete booking error:', error);
          alert('Delete booking failed, please try again later');
        }
      },
      
      // 目前后端API没有提供删除历史预订的功能，这个方法只是模拟
      confirmDeleteHistory() {
        const id = this.getBookID();
        if (id === -1) return;

        console.log("Confirm delete history booking", id);
        alert('Delete history booking feature not yet implemented');
        this.closeDeleteHistoryModal();
      },
    }
  };
  </script>
  
  <style scoped>
  h2 {
    font-family: 'Rethink Sans', sans-serif;
    font-size: 24px;
    color: #FFFFFF;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px solid #333333;
  }
  
  h4 {
    font-family: 'Rethink Sans', sans-serif;
    font-size: 18px;
    color: #DD2525;
    margin: 30px 0 10px;
  }
  
  .profile-page {
    background-color: #151517;
    min-height: 100vh;
    display: flex;
    align-items: flex-start;
  }
  
  .split-layout {
    display: flex;
    width: 100%;
  }
  
  .sidebar-container {
    width: 250px;
    flex-shrink: 0;
  }
  
  .central-section-wrapper {
    flex: 1;
    display: flex;
    justify-content: center;
    padding: 0 20px;
  }
  
  .central-section {
    width: 100%;
    max-width: 1200px;
    padding: 30px 40px;
    background-color: #151517;
  }
  
  .rooms-container {
    margin-bottom: 30px;
    background-color: transparent;
    border-radius: 8px;
    padding: 30px;
  }
  
  .action-buttons-container {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    align-items: center;
  }
  </style>
