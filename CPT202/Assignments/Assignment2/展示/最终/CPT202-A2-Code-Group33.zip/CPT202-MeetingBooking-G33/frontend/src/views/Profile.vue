<template>
  <div class="background-page">
    <div class="profile-page">
    <div class="split-layout">
      <!-- 左侧：固定宽度 250px 的 Sidebar -->
      <div class="sidebar-container">
        <sidebar-menu  :pageLoaded="pageLoaded" />
      </div>
      <!-- 右侧：中央区域 -->
      <div v-if="pageLoaded" class="central-section-wrapper">
        <div class="central-section">
          <!-- Personal Profile 部分 -->
          <div class="section-container">
            <h2>Personal Profile</h2>
            
            <div class="split-layout">
              <!-- 左侧字段 -->
              <div class="left-layout">
                <h3>Personal Information</h3>
                <input-field 
                  id="username"
                  label="Username"
                  v-model="profile.username"
                  :label-color="themeColors.labelColor"
                  :input-bg-color="themeColors.inputBgColor"
                  :input-text-color="themeColors.textColor"
                />
                <input-field 
                  id="email" 
                  label="Email" 
                  v-model="profile.email" 
                  :disabled="true"
                  :label-color="themeColors.labelColor"
                  :input-bg-color="themeColors.inputBgColor"
                  :input-text-color="themeColors.textColor"
                />
                
                <h3>Change Email</h3>
                <input-field 
                  id="new-email"
                  label="New Email"
                  v-model="newEmail" 
                  placeholder="Enter new email"
                  :label-color="themeColors.labelColor"
                  :input-bg-color="themeColors.inputBgColor"
                  :input-text-color="themeColors.textColor"
                />
                <input-field-button 
                  id="captcha" 
                  label="CAPTCHA" 
                  v-model="captcha"
                  :label-color="themeColors.labelColor"
                  :input-bg-color="themeColors.inputBgColor"
                  :input-text-color="themeColors.textColor" 
                  :button-text="emailCaptchaButtonText" 
                  :button-bg-color="themeColors.buttonBgColor"
                  :button-text-color="themeColors.buttonTextColor"
                  :disabled="emailCaptchaButtonDisabled"
                  @click="sendCaptcha" 
                />
                <custom-button 
                  label="Change Email" 
                  @click="changeEmail" 
                  :primary-bg-color="'rgba(37, 40, 55, 1)'"
                  :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
                  :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
                  :primary-text-color="themeColors.buttonTextColor"
                />
              </div>
              
              <!-- 右侧：头像 -->
              <div class="right-layout">
                <div class="avatar-container">
                  <h3 class="avatar-label">Avatar</h3>
                  <div class="avatar-wrapper" @click="triggerAvatarUpload">
                    <img
                      :src="avatar"
                      alt="User Avatar"
                      class="avatar-image"
                    />
                    <div class="edit-button-wrapper">
                      <button class="edit-button" @click.stop="triggerAvatarUpload">Edit</button>
                    </div>
                    <input
                        ref="avatarInput"
                        type="file"
                        accept="image/*"
                        style="display: none"
                        @change="onAvatarSelected"
                      />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Account 部分 -->
          <div class="section-container">
            <h2>Account</h2>
            
            <div class="split-layout">
              <!-- 左侧：密码修改逻辑 -->
              <div class="left-layout">
                <h3>Change Password</h3>
                <input-field 
                  id="old-password" 
                  label="Old Password" 
                  type="password" 
                  v-model="oldPassword"
                  :label-color="themeColors.labelColor"
                  :input-bg-color="themeColors.inputBgColor"
                  :input-text-color="themeColors.textColor"
                />
                <input-field 
                  id="new-password" 
                  label="New Password" 
                  type="password" 
                  v-model="newPassword"
                  :label-color="themeColors.labelColor"
                  :input-bg-color="themeColors.inputBgColor"
                  :input-text-color="themeColors.textColor"
                />
                <input-field-button 
                  id="password-captcha" 
                  label="CAPTCHA" 
                  v-model="passwordCaptcha"
                  :label-color="themeColors.labelColor"
                  :input-bg-color="themeColors.inputBgColor"
                  :input-text-color="themeColors.textColor" 
                  :button-text="passwordCaptchaButtonText" 
                  :button-bg-color="themeColors.buttonBgColor"
                  :button-text-color="themeColors.buttonTextColor"
                  :disabled="passwordCaptchaButtonDisabled"
                  @click="sendPasswordCaptcha" 
                />
                <custom-button 
                  label="Change Password" 
                  @click="changePassword"
                  :primary-bg-color="'rgba(37, 40, 55, 1)'"
                  :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
                  :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
                  :primary-text-color="themeColors.buttonTextColor"
                />

                <h3>Logout</h3>
                <custom-button 
                  label="Logout" 
                    @click="logout" 
                    :primary-bg-color="'rgba(37, 40, 55, 1)'"
                    :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
                    :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
                    :primary-text-color="themeColors.buttonTextColor"
                />

                <h4>Delete Account</h4>
                <custom-button 
                  label="Delete Account" 
                  @click="deleteAccount" 
                  :primary-bg-color="'rgba(131, 10, 10, 1)'"
                  :primary-hover-bg-color="'rgba(131, 10, 10, 0.9)'"
                  :primary-active-bg-color="'rgba(131, 10, 10, 0.5)'"
                  :primary-text-color="themeColors.buttonTextColor"
                />
              </div>
              <!-- 右侧：空白 -->
              <div class="right-layout">
                <!-- 此处保持空白 -->
              </div>
            </div>
          </div>
        </div>
      </div>
      <LoadingMessage v-else message="Redirecting..." />
    </div>
    </div>
  </div>
</template>

<script>
import SidebarMenu from '@/components/SidebarMenu.vue';
import InputField from '@/components/InputField.vue';
import CustomButton from '@/components/Button.vue';
import InputFieldButton from '@/components/InputFieldButton.vue';
import LoadingMessage from '@/components/LoadingMessage.vue';
import axios from 'axios';

export default {
  name: 'ProfilePage',
  components: {
    SidebarMenu,
    InputField,
    CustomButton,
    InputFieldButton,
    LoadingMessage
  },
  data() {
    return {
      pageLoaded: false,
      
      profile: {
        username: '',
        email: '',
      },

      newEmail: '',
      captcha: '',
      oldPassword: '',
      newPassword: '',
      avatar: '',
      captchaButtonDisabled: false,
      captchaCountdown: 0,
      countdownInterval: null,
      
      passwordCaptcha: '',
      avatar: '',
      
      // 邮箱验证码状态
      emailCaptchaButtonDisabled: false,
      emailCaptchaCountdown: 0,
      emailCaptchaButtonText: 'Send Captcha',
      emailCountdownInterval: null,
      
      // 密码验证码状态
      passwordCaptchaButtonDisabled: false,
      passwordCaptchaCountdown: 0,
      passwordCaptchaButtonText: 'Send Captcha',
      passwordCountdownInterval: null,
    
      themeColors: {
        textColor: '#1B1C20',
        labelColor: '#FFFFFF',
        inputBgColor: '#FFFFFF',
        buttonBgColor: '#252837',
        buttonHoverBgColor: '#2C3E50',
        buttonTextColor: '#FFFFFF'
      }
    };
  },
  mounted() {
    // 页面加载时获取用户信息
    this.getUserInfo()
  },
  computed: {
    getUserName() {
      return this.$store.state.userinfo.username;
    },
    getUserEmail() {
      return this.$store.state.userinfo.email;
    }
  },
  beforeDestroy() {
    if (this.emailCountdownInterval) {
      clearInterval(this.emailCountdownInterval);
    }
    if (this.passwordCountdownInterval) {
      clearInterval(this.passwordCountdownInterval);
    }
  },
  methods: {
    userInfoComplete() {
      console.log(this.$store.state.userinfo.username);
      return this.$store.state.userinfo.username != null && this.$store.state.userinfo.username != '' &&
       this.$store.state.userinfo.userid != null && this.$store.state.userinfo.userid != '' &&
       this.$store.state.userinfo.email != null && this.$store.state.userinfo.email != '' &&
       this.$store.state.userinfo.avatar_path != null && this.$store.state.userinfo.avatar_path != '' &&
      (this.$store.state.userinfo.role == 'ADMIN' || this.$store.state.userinfo.role == 'USER') ;
    },
    // 获取当前登录用户信息
    async getUserInfo() {
      if (this.userInfoComplete()) {
        this.profile.username = this.$store.state.userinfo.username;
        this.profile.email = this.$store.state.userinfo.email;
        this.avatar = this.$store.state.userinfo.avatar_path;
        this.pageLoaded = true;
        return;
      }
      try {
        const response = await axios.get('/api/user/me', { timeout: 5000 });
        if (response.data.code === 200) {
          const userData = response.data.data;
          this.profile.username = userData.username;
          this.profile.email = userData.email;
          this.avatar = userData.avatar_url;
          
          // 更新Vuex中的用户信息
          this.$store.commit('userinfo/setUsername', userData.username);
          this.$store.commit('userinfo/setUserID', userData.user_id);
          this.$store.commit('userinfo/setRole', userData.role);
          this.$store.commit('userinfo/setLocked', userData.is_locked);
          if (userData.avatar_url)
            this.$store.commit('userinfo/setAvatarPath', userData.avatar_url);
          else
            this.$store.commit('userinfo/setAvatarPath', 'http://sulthbbxs.hd-bkt.clouddn.com/avatars/default.jpg');

          this.pageLoaded = true;
        }
      } catch (error) {
        console.error('Failed to fetch user info:', error);
        if (error.response && error.response.status === 401) {
          alert('Please login first');
        }
        this.$router.push('/login');
      }
    },
    triggerAvatarUpload() {
      this.$refs.avatarInput.click();
    },

    async onAvatarSelected(e) {
      const file = e.target.files[0];
      if (!file) return;

      this.avatar = URL.createObjectURL(file);
      const formData = new FormData();

      const parts = file.name.split('.');
      const ext = parts.length > 1 ? parts.pop() : 'png';

      const filename = `${Date.now()}.${ext}`;
      formData.append('file', file, filename);
      try {
        const res = await axios.post(
          '/api/user/upload-avatar',
          formData,
          { 
            params: { user_id: this.$store.state.userinfo.userid },
            headers: { 'Content-Type': 'multipart/form-data' }, 
            timeout: 5000
          }
        );
        if (res.data.code === 200) {
          alert('Avatar updated successfully');
          const newUrl = res.data.data.avatar_url;
          this.avatar = newUrl;
          this.$store.commit('userinfo/setAvatarPath', newUrl);
        } else {
          alert(res.data.message || 'Failed to upload avatar');
        }
      } catch (err) {
        console.error('Upload error:', err);
        alert('Error uploading avatar');
      } finally {
        e.target.value = '';
      }
    },
    async sendCaptcha() {
      if (this.emailCaptchaButtonDisabled || !this.newEmail) {
        return;
      }
      
      // 禁用按钮并开始倒计时
      this.emailCaptchaButtonDisabled = true;
      this.emailCaptchaCountdown = 60;
      this.emailCaptchaButtonText = `${this.emailCaptchaCountdown}s`;
      
      this.emailCountdownInterval = setInterval(() => {
        this.emailCaptchaCountdown--;
        this.emailCaptchaButtonText = `${this.emailCaptchaCountdown}s`;
        if (this.emailCaptchaCountdown <= 0) {
          clearInterval(this.emailCountdownInterval);
          this.emailCaptchaButtonDisabled = false;
          this.emailCaptchaButtonText = 'Send Captcha';
        }
      }, 1000);
      
      try {
        // 调用发送验证码的API
        await axios.get(`/api/user/ask_code?email=${this.newEmail}`, { timeout: 5000 });
        console.log('Captcha sent successfully');
      } catch (error) {
        console.error('Failed to send captcha:', error);
        clearInterval(this.emailCountdownInterval);
        this.emailCaptchaButtonDisabled = false;
        this.emailCaptchaButtonText = 'Send Captcha';
      }
    },
    async sendPasswordCaptcha() {
      if (this.passwordCaptchaButtonDisabled) {
        return;
      }
      
      // 禁用按钮并开始倒计时
      this.passwordCaptchaButtonDisabled = true;
      this.passwordCaptchaCountdown = 60;
      this.passwordCaptchaButtonText = `${this.passwordCaptchaCountdown}s`;
      
      this.passwordCountdownInterval = setInterval(() => {
        this.passwordCaptchaCountdown--;
        this.passwordCaptchaButtonText = `${this.passwordCaptchaCountdown}s`;
        if (this.passwordCaptchaCountdown <= 0) {
          clearInterval(this.passwordCountdownInterval);
          this.passwordCaptchaButtonDisabled = false;
          this.passwordCaptchaButtonText = 'Send Captcha';
        }
      }, 1000);
      
      try {
        // 使用用户当前邮箱请求验证码
        await axios.get(`/api/user/ask_code?email=${this.profile.email}`, { timeout: 5000 });
        console.log('Password captcha sent successfully');
      } catch (error) {
        console.error('Failed to send password captcha:', error);
        clearInterval(this.passwordCountdownInterval);
        this.passwordCaptchaButtonDisabled = false;
        this.passwordCaptchaButtonText = 'Send Captcha';
      }
    },
    async changeEmail() {
      if (!this.newEmail || !this.captcha) {
        alert('请输入新邮箱和验证码');
        return;
      }
      
      try {
        const response = await axios.post('/api/user/change-email', {
          oldEmail: this.profile.email,
          newEmail: this.newEmail,
          code: this.captcha
        }, { timeout: 5000 });
        
        if (response.data.code === 200) {
          alert('Email changed successfully');
          // 更新本地显示的邮箱
          this.profile.email = this.newEmail;
          // 更新Vuex中的邮箱
          this.$store.commit('userinfo/setEmail', this.newEmail);
          // 清空表单
          this.newEmail = '';
          this.captcha = '';
        } else {
          alert('Email change failed:' + response.data.message);
        }
      } catch (error) {
        console.error('更改邮箱失败:', error);
        alert('Email change failed, please try again later');
      }
    },
    async changePassword() {
      if (!this.newPassword || !this.passwordCaptcha) {
        alert('Please enter new password and captcha');
        return;
      }
      
      try {
        const response = await axios.post('/api/user/reset-password', {
          newPassword: this.newPassword,
          code: this.passwordCaptcha,
          email: this.profile.email  // 使用当前用户邮箱
        }, { timeout: 5000 });
        
        if (response.data.code === 200) {
          alert('Password changed successfully');
          // 清空表单
          this.oldPassword = '';
          this.newPassword = '';
          this.passwordCaptcha = '';
        } else {
          alert('Password change failed' + response.data.message);
        }
      } catch (error) {
        console.error('更改密码失败:', error);
        alert('Password change failed, please try again later');
      }
    },
    deleteAccount() {
      alert('Account deletion function not yet implemented in backend');
    },
    async logout() {
      try {
        const response = await axios.post('/api/user/logout', { timeout: 5000 });
        if (response.data.code === 200) {
          console.log('Logout successful');
        }
      } catch (error) {
        console.error('Failed to logout:', error);
      } finally {
        // 无论成功还是失败，都执行以下操作
        // 清除本地存储的用户信息
        localStorage.removeItem('userInfo');
        
        // 清除 JSESSIONID cookie
        document.cookie = 'JSESSIONID=;';
        
        // 清除 Vuex 状态
        this.$store.commit('userinfo/setUsername', '');
        this.$store.commit('userinfo/setEmail', '');
        this.$store.commit('userinfo/setRole', '');
        this.$store.commit('userinfo/setAvatarPath', '');
        this.$store.commit('userinfo/setUserID', -1);
        this.$store.commit('userinfo/setLocked', false);
        
        // 跳转到登录页
        this.$router.push('/login');
      }
    }
  }
};
</script>

<style scoped>
.background-page {
    background-color: #151517;
    height: 100%;
    width: 100%;
  }

.profile-page {
  background-color: #151517;
  min-height: 100vh;
  display: flex;
  align-items: flex-start;
}

/* 外层 Split Layout */
.split-layout {
  display: flex;
  width: 100%;
}

/* 左侧：固定宽度 Sidebar */
.sidebar-container {
  width: 250px;
  flex-shrink: 0;
}

/* 右侧：中央区域的包装器 */
.central-section-wrapper {
  flex: 1;
  display: flex;
  justify-content: center; /* 水平居中 */
  padding: 0 20px; /* 两侧留出一些间距 */
}

/* 中央区域 */
.central-section {
  width: 100%;
  max-width: 1200px; /* 限制最大宽度 */
  padding: 30px 40px;
  background-color: #151517;
}

.section-container {
  margin-bottom: 30px;
  background-color: rgba(0, 0, 0, 0);
  border-radius: 8px;
  padding: 30px;
}

/* 内部的 Split Layout */
.split-layout .split-layout {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 40px;
}

/* 左侧布局 */
.left-layout {
  max-width: 500px;
  margin-top: -20px;
  margin-right: 100px;
  flex: 1;
}

/* 右侧布局（头像部分） */
.right-layout {
  width: 300px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
}

h2 {
  font-family: 'Rethink Sans', sans-serif;
  font-size: 24px;
  color: #FFFFFF;
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 1px solid #333333;
}

h3 {
  font-family: 'Rethink Sans', sans-serif;
  font-size: 18px;
  color: #FFFFFF;
  margin: 30px 0 10px;
}

h4 {
    font-family: 'Rethink Sans', sans-serif;
    font-size: 18px;
    color: #DD2525;
    margin: 30px 0 10px;
}

/* 头像区域 */
.avatar-container {
  width: 100%;
}

.avatar-label {
  font-family: 'Rethink Sans', sans-serif;
  font-size: 16px;
  color: #FFFFFF;
  margin-top: 40px;
  margin-bottom: 8px;
  text-align: left;
}

.avatar-wrapper {
  position: relative;
  width: 100%;
  height: 0;
  padding-bottom: 100%;
  background-color: transparent;
  border-radius: 50%;
  overflow: visible;
}

.avatar-image {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
  background-color: transparent;
}

.edit-button-wrapper {
  position: absolute;
  bottom: 10px;
  left: 10px;
  z-index: 5;
}

.edit-button {
  background-color: #1a252f;
  color: white;
  border: none;
  border-radius: 4px;
  padding: 5px 10px;
  font-family: 'Rethink Sans', sans-serif;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.edit-button:hover {
  background-color: #2c3e50;
}

additional-elements {
  margin-top: 20px;
}

.logout-container {
  margin-top: 20px;
}
</style>