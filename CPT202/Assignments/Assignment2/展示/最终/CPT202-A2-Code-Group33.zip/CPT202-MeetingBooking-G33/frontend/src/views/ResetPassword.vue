<template>
    <div class="signup-page">
      <img class="bg-image" :src="backgroundImage" alt="Background" />
      <div class="form-container" ref="formContainer">
        <h2>Booking System</h2>
        <div class="fade-in" ref="fadeInContainer">
          <h3>Reset Password</h3>
          <form @submit.prevent="handlePasswordReset">
            <InputField
              id="email"
              label="Email"
              type="email"
              placeholder="Please enter your email"
              v-model="form.email"
            />
            <InputFieldButton
              label="Captcha"
              placeholder="Please enter Captcha"
              :buttonText="captchaCountdown > 0 ? `${captchaCountdown}s` : 'Send Captcha'"
              :disabled="captchaButtonDisabled"
              v-model="form.captcha"
              @click="handleCaptchaSend"
            />
            <InputField
              id="newPassword"
              label="New Password"
              type="password"
              placeholder="Please enter your password"
              v-model="form.password"
            />
            <InputField
              id="confirm-password"
              label="Confirm Password"
              type="password"
              placeholder="Please enter your password again"
              v-model="form.confirmPassword"
            />
            <Button 
                label="Reset Password" 
                type="primary" 
                @click="handlePasswordReset" 
                :loading="isLoading"
            />
            <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
          </form>
          <div class="links">
            <Button label="Back to login" type="secondary" @click="transitionToLogin" />
          </div>
        </div>
      </div>
    </div>
  </template>
    
    <script>
    import InputField from '@/components/InputField.vue';
    import Button from '@/components/Button.vue';
    import BgImage from '@/assets/background.png';
    import InputFieldButton from '@/components/InputFieldButton.vue';
    import axios from 'axios';
    
    export default {
      name: 'ResetPassword',
      components: {
        InputField,
        Button,
        InputFieldButton,
      },
      data() {
        return {
          backgroundImage:  BgImage,
          form: {
            email: '',
            password: '',
            confirmPassword: '',
            captcha: '',
          },
          targetContainerHeight: '495px',
          isLoading: false,
          errorMessage: '',
          captchaButtonDisabled: false,
          captchaCountdown: 0,
          countdownInterval: null,
        };
      },
      mounted() {
        const container = this.$refs.formContainer;
        container.style.height = 620 + 'px';
      },
      beforeDestroy() {
        // 清除倒计时计时器
        if (this.countdownInterval) {
          clearInterval(this.countdownInterval);
        }
      },
      methods: {
        async handlePasswordReset() {
          if (this.isLoading) return;
          
          // 表单验证
          if (!this.form.email || !this.form.password || !this.form.confirmPassword || !this.form.captcha) {
            this.errorMessage = '请填写所有必填字段';
            return;
          }
          
          if (this.form.password !== this.form.confirmPassword) {
            this.errorMessage = '两次输入的密码不一致';
            return;
          }
          
          if (this.form.password.length < 8) {
            this.errorMessage = '密码长度至少为8位';
            return;
          }
          
          this.isLoading = true;
          this.errorMessage = '';
          
          try {
            // 调用后端重置密码接口
            const response = await axios.post('/api/user/reset-password', {
              email: this.form.email,
              newPassword: this.form.password,
              code: this.form.captcha
            }, { 
              timeout: 5000 
            });
            
            if (response.data.code === 200) {
              // 重置密码成功
              alert('Password reset. Please login again.');
              this.transitionToLogin();
            } else {
              this.errorMessage = response.data.message || 'Password reset failed. Please try again.';
            }
          } catch (error) {
            console.error('Password reset error:', error);
            this.errorMessage = (error.response && error.response.data && error.response.data.message) || 
                               'Password reset failed, please try again later';
          } finally {
            this.isLoading = false;
          }
        },
        async handleCaptchaSend() {
          if (this.captchaButtonDisabled || !this.form.email) {
            if (!this.form.email) {
              this.errorMessage = 'Please enter your email';
            }
            return;
          }
          
          // 验证邮箱格式
          if (!/\S+@\S+\.\S+/.test(this.form.email)) {
            this.errorMessage = 'Please enter a valid email address';
            return;
          }
          
          this.captchaButtonDisabled = true;
          
          try {
            // 调用发送验证码的API
            const response = await axios.get(`/api/user/ask_code?email=${encodeURIComponent(this.form.email)}`, { timeout: 5000 });
            
            if (response.data && response.data.code === 200) {
              console.log('验证码发送成功');
              // 启动倒计时
              this.startCaptchaCountdown();
            } else {
              this.errorMessage = response.data.message || 'Captcha sending failed, please try again later.';
              this.captchaButtonDisabled = false;
            }
          } catch (error) {
            console.error('验证码发送失败:', error);
            this.errorMessage = (error.response && error.response.data && error.response.data.message) || 
                               'Captcha sending failed, please try again later.';
            this.captchaButtonDisabled = false;
          }
        },
        startCaptchaCountdown() {
          this.captchaCountdown = 60;
          this.countdownInterval = setInterval(() => {
            if (this.captchaCountdown > 0) {
              this.captchaCountdown--;
            } else {
              clearInterval(this.countdownInterval);
              this.captchaButtonDisabled = false;
              this.captchaCountdown = 0;
            }
          }, 1000);
        },
        transitionToLogin() {
          const fadeInEl = this.$refs.fadeInContainer;
          const containerEl = this.$refs.formContainer;
          fadeInEl.classList.add('fade-out');
          fadeInEl.addEventListener(
            'animationend',
            () => {
              containerEl.style.height = this.targetContainerHeight;
              containerEl.addEventListener(
                'transitionend',
                () => {
                  this.$router.push('/login');
                },
                { once: true }
              );
            },
            { once: true }
          );
        }
      },
    };
    </script>
    
    <style scoped>
  
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
  
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
  
    .signup-page {
      position: relative;
      overflow-y: auto;
    }
    
    .bg-image {
      display: block;
      width: 100%;
      height: auto;
    }
  
    .fade-in {
      animation: fadeIn 0.5s ease-out forwards;
    }
  
    .fade-out {
      animation: fadeOut 0.5s ease-out forwards;
    }
  
    .form-container {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(240, 242, 255, 0.85);
      padding: 30px 30px 15px;
      border-radius: 10px;
      width: 100%;
      max-width: 400px;
      text-align: center;
      transition: height 0.25s ease-out;
    }
    
    h2 {
      font-size: 42px;
      margin-bottom: 10px;
      font-family: 'Rethink Sans', sans-serif;
      color: #76778E;
      font-weight: 600;
    }
    
    h3 {
      font-size: 30px;
      margin: 0 0 20px 0;
      text-align: left;
      font-family: 'Rethink Sans', sans-serif;
      color: #252837;
      font-weight: 600;
    }
  
    h4 {
      font-size: 16px;
      margin: 0 0 -20px 0;
      font-family: 'Rethink Sans', sans-serif;
      font-weight: 600;
      color: #878787
    }
    
    .links {
      margin-top: 15px;
    }
    
    .error-message {
      color: red;
      font-size: 14px;
      margin-top: 10px;
    }
    </style>