<template>
  <div class="profile-page">
    <div class="split-layout">
      <!-- 左侧 Sidebar -->
      <div class="sidebar-container">
        <sidebar-menu  :pageLoaded="pageLoaded" />
      </div>
      <!-- 右侧中央区域 -->
      <div v-if="pageLoaded" class="central-section-wrapper">
        <div class="central-section">
          <div class="section-container rooms-container">
            <h2>Rooms</h2>
            <h4 v-if="isLocked">Your account has been temporarily locked. You cannot book room until your account is unlocked.</h4>
            <data-table 
              :headers="tableHeaders" 
              :data="getTableData"
              header-bg-color="transparent"
              :header-bg-opacity="1"
              body-bg-color="transparent"
              :body-bg-opacity="1"
              :allow-actions="true"
              :defaultPageSize="10"
              :showExtraIconButton="isAdmin"
              :extraIconButtonProps="{
                backgroundColor: 'rgba(37, 40, 55, 1)',
                borderEnabled: false,
                imageContent: `
                <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='transparent' stroke='#ffffff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-circle-plus-icon lucide-circle-plus'>
                  <circle cx='12' cy='12' r='10'/>
                  <path d='M8 12h8'/>
                  <path d='M12 8v8'/>
                </svg>`,
                imageColor: 'transparent',
                textContent: 'Add',
                textColor: '#ffffff',
                size: 14
              }"
              @row-click="openDetailModal"
              @extra-icon-click="openAddRoomModal"
              :showFilter="true"
              :filterConfig="[{ 
                  field:'room',      
                  type:'text',   
                  props:{ 
                    label:'Room',      
                    placeholder:'enter room…',      
                    defaultValue:'',  
                    validateFn:v=>v.length<=20 
                  } 
                }, { 
                  field:'facilities',
                  type:'text',   
                  props:{ 
                    label:'Facility',  
                    placeholder:'enter facility…',  
                    defaultValue:'',  
                    validateFn:v=>v.length<=20 
                  } 
                }, { 
                  field:'building',      
                  type:'select', 
                  props:{ 
                    label:'Location',  
                    options: getBuildings, 
                    defaultValue:'' 
                  } 
                }, { 
                  field:'capacity',  
                  type:'range',  
                  props:{ 
                    label:'Capacity',  
                    placeholderMin:'min', 
                    placeholderMax:'max', 
                    defaultMin:0, 
                    validateFn:({min, max}) => min <= max 
                  } 
                }
              ]"
              @filter-search="handleSearch"
              @filter-cancel="resetFilters"
            >
              <template #actions="{ row, rowIndex }">
                <div class="action-buttons-container">
                  <icon-button
                    v-if="showBookingButton"
                    background-color="#488C46"
                    :border-enabled="false"
                    image-content='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21V7"/><path d="m16 12 2 2 4-4"/><path d="M22 6V4a1 1 0 0 0-1-1h-5a4 4 0 0 0-4 4 4 4 0 0 0-4-4H3a1 1 0 0 0-1 1v13a1 1 0 0 0 1 1h6a3 3 0 0 1 3 3 3 3 0 0 1 3-3h6a1 1 0 0 0 1-1v-1.3"/></svg>'
                    image-color="transparent"
                    text-content="Book"
                    text-color="#ffffff"
                    :size="14"
                    @click="openBookModal(row, rowIndex)"
                  />
                  <icon-button
                    v-if="isAdmin"
                    background-color="#175894"
                    :border-enabled="false"
                    image-content='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg>'
                    image-color="transparent"
                    text-content="Edit"
                    text-color="#ffffff"
                    :size="14"
                    @click="openEditModal(row, rowIndex)"
                  />
                  <icon-button
                    v-if="isAdmin"
                    background-color="#830A0A"
                    :border-enabled="false"
                    image-content='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>'
                    image-color="rgba(0, 0, 0, 0)"
                    text-content="Delete"
                    text-color="#ffffff"
                    :size="14"
                    @click="openDeleteModal(row, rowIndex)"
                  />
                </div>
              </template>
            </data-table>
          </div>
        </div>
      </div>
      <LoadingMessage v-else message="Redirecting..." />
    </div>

    <!-- Add Modal -->
    <Modal :visible="showAddModal" width="500px" autoHeight panelBgColor="#151517" @close="closeAddModal">
      <h2>Add Room</h2>
      <PhotoEditor 
        v-model="addData.imageUrl"
        :editable="true"
        @upload="changeAddImageFile"
      />
      <EditableLabel 
        prefix="Name"
        prefixColor="white"
        :modelValue="addData.name"
        @update:modelValue="addData.name = $event"
        valueColor="white"
        :showEditButton="true"
      />
      <EditableAutocomplete
        prefix="Type"
        prefixColor="white"
        valueColor="white"
        :modelValue="addData.typeid"
        @update:modelValue="addData.typeid = $event"
        :options="getTypes"
        :showEditButton="true"
      />
      <EditableLabel 
        v-if="typeNotExist"
        prefix="Capacity"
        prefixColor="white"
        :modelValue="addData.capacity"
        @update:modelValue="addData.capacity = $event"
        valueColor="white"
        :showEditButton="true"
        allowedType="number"
      />
      <EditableAutocomplete
        prefix="Location"
        prefixColor="white"
        valueColor="white"
        :modelValue="addData.locationid"
        @update:modelValue="addData.locationid = $event"
        :options="getBuildings"
        :showEditButton="true"
        dropdownLeft=80
      />
      <EditableLabel
        v-if="false"
        prefix="Description"
        prefixColor="white"
        :modelValue="addData.description"
        @update:modelValue="addData.description = $event"
        valueColor="white"
        :showEditButton="true"
      />
      <Tag
        title="Facilities"
        :modelValue="addData.facilities"
        @update:modelValue="addData.facilities = $event"
        tagBgColor="rgba(37, 40, 55, 1)"
        :editable="true"
       />
       <CustomButton 
        label="Confirm"
        @click="confirmAdd" 
        :primary-bg-color="'rgba(72, 140, 70, 1)'"
        :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
        :primary-text-color="'#ffffff'"
      />
      <CustomButton
        label="Cancel" 
        @click="closeAddModal" 
        :primary-bg-color="'rgba(37, 40, 55, 1)'"
        :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
        :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
        :primary-text-color="'#ffffff'"
      />
    </Modal>

    <!-- Detail Modal -->
    <Modal :visible="showDetailModal" width="500px" autoHeight panelBgColor="#151517" @close="closeDetailModal">
      <h2>{{ selectedRoom ? selectedRoom.name : '' }}</h2>
      <PhotoEditor 
        v-model="detailData.imageUrl"
      />
      <EditableLabel 
        prefix="Name"
        prefixColor="white"
        :modelValue="detailData.name"
        valueColor="white"
      />
      <EditableLabel
        prefix="Type"
        prefixColor="white"
        :modelValue="detailData.type"
        valueColor="white"
      />
      <EditableLabel
        prefix="Capacity"
        prefixColor="white"
        :modelValue="detailData.capacity"
        valueColor="white"
      />
      <EditableLabel
        prefix="Location"
        prefixColor="white"
        :modelValue="detailData.location"
        valueColor="white"
      />
      <EditableLabel
        v-if="false"
        prefix="Description"
        prefixColor="white"
        :modelValue="detailData.description"
        valueColor="white"
      />
      <Tag
        title="Facilities"
        :modelValue="detailData.facilities"
        tagBgColor="rgba(37, 40, 55, 1)"
       />
    </Modal>

    <!-- Book Modal -->
    <Modal :visible="showBookModal" width="700px" height="880px" panelBgColor="#151517" @close="closeBookModal">
      <h2>Book {{ selectedRoom ? selectedRoom.name : '' }}</h2>
      <EditableLabel 
        prefix="Subject"
        prefixColor="white"
        :modelValue="bookData.subject"
        @update:modelValue="bookData.subject = $event"
        valueColor="white"
        :showEditButton="true"
      />
      <TimeSlot
        :occupiedSlots="getCurrentRoomOccupiedSlots"
        :modelview="bookData.selectedSlots"
        @update:modelValue="bookData.selectedSlots = $event"
      />
      <CustomButton 
        label="Book"
        @click="confirmBook" 
        :primary-bg-color="'rgba(72, 140, 70, 1)'"
        :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
        :primary-text-color="'#ffffff'"
      />
      <CustomButton
        label="Cancel" 
        @click="closeBookModal" 
        :primary-bg-color="'rgba(37, 40, 55, 1)'"
        :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
        :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
        :primary-text-color="'#ffffff'"
      />
    </Modal>

    <!-- Edit Modal -->
    <Modal :visible="showEditModal" width="500px" autoHeight panelBgColor="#151517" @close="closeEditModal">
      <h2>Edit Room</h2>
      <PhotoEditor 
        v-model="editData.imageUrl"
        :editable="true"
        @upload="changeEditImageFile"
      />
      <EditableLabel 
        prefix="Name"
        prefixColor="white"
        :modelValue="editData.name"
        @update:modelValue="editData.name = $event"
        valueColor="white"
        :showEditButton="true"
      />
      <EditableAutocomplete
        prefix="Type"
        prefixColor="white"
        valueColor="white"
        :modelValue="editData.typeid"
        @update:modelValue="editData.typeid = $event"
        :options="getTypes"
        :showEditButton="true"
      />
      <EditableLabel 
        v-if="editTypeNotExist"
        prefix="Capacity"
        prefixColor="white"
        :modelValue="editData.capacity"
        @update:modelValue="editData.capacity = $event"
        valueColor="white"
        :showEditButton="true"
        allowedType="number"
      />
      <EditableAutocomplete
        prefix="Location"
        prefixColor="white"
        valueColor="white"
        :modelValue="editData.locationid"
        @update:modelValue="editData.locationid = $event"
        :options="getBuildings"
        :showEditButton="true"
        dropdownLeft=80
      />
      <EditableLabel
        v-if="false"
        prefix="Description"
        prefixColor="white"
        :modelValue="editData.description"
        @update:modelValue="editData.description = $event"
        valueColor="white"
        :showEditButton="true"
      />
      <Tag
        title="Facilities"
        :modelValue="editData.facilities"
        @update:modelValue="editData.facilities = $event"
        tagBgColor="rgba(37, 40, 55, 1)"
        :editable="true"
       />
       <CustomButton 
        label="Confirm"
        @click="confirmEdit" 
        :primary-bg-color="'rgba(72, 140, 70, 1)'"
        :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
        :primary-text-color="'#ffffff'"
      />
      <CustomButton
        label="Cancel" 
        @click="closeEditModal" 
        :primary-bg-color="'rgba(37, 40, 55, 1)'"
        :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
        :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
        :primary-text-color="'#ffffff'"
      />
    </Modal>

    <!-- Delete Modal -->
    <Modal :visible="showDeleteModal" width="500px" height="280px" panelBgColor="#151517" @close="closeDeleteModal">
      <h2>Delete Room</h2>
      <h4>Delete room {{ selectedRoom ? selectedRoom.name : '' }} ?</h4>
      <CustomButton 
          label="Delete" 
          @click="confirmDelete" 
          :primary-bg-color="'rgba(131, 10, 10, 1)'"
          :primary-hover-bg-color="'rgba(131, 10, 10, 0.9)'"
          :primary-active-bg-color="'rgba(131, 10, 10, 0.5)'"
          :primary-text-color="'#ffffff'"
      />
      <CustomButton
          label="Cancel" 
          @click="closeDeleteModal" 
          :primary-bg-color="'rgba(37, 40, 55, 1)'"
          :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
          :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
          :primary-text-color="'#ffffff'"
      />
    </Modal>
  </div>
</template>

<script>
import SidebarMenu from '@/components/SidebarMenu.vue';
import DataTable from '@/components/DataTable.vue';
import IconButton from '@/components/IconButton.vue';
import Modal from '@/components/Modal.vue';
import TimeSlot from '@/components/TimeSlot.vue';
import CustomButton from '@/components/Button.vue';
import EditableLabel from '@/components/EditableLabel.vue';
import EditableSelect from '@/components/EditableSelect.vue';
import Tag from '@/components/Tag.vue';
import LoadingMessage from '@/components/LoadingMessage.vue';
import PhotoEditor from '@/components/PhotoEditor.vue';
import axios from 'axios';
import EditableAutocomplete from '@/components/EditableAutocomplete.vue';

export default {
  name: 'RoomsPage',
  components: {
    SidebarMenu,
    DataTable,
    IconButton,
    Modal,
    TimeSlot,
    CustomButton,
    EditableLabel,
    EditableSelect,
    EditableAutocomplete,
    LoadingMessage,
    Tag,
    PhotoEditor
  },
  data() {
    return {
      pageLoaded: false,

      profile: {
        role: this.$store.state.userinfo.role,
      },

      tableHeaders: [
        { key: 'id', label: 'ID' },
        { key: 'name', label: 'Name' },
        { key: 'type', label: 'Type' },
        { key: 'location', label: 'Location' }
      ],
      // 用来保存当前的所有缓存信息
      tableData: null,
      buildings: null,
      types: null,
      // 用来保存当前选中的房间数据 {id, name, type, location}
      selectedRoom: null,
      // 控制弹窗的显示
      showDetailModal: false,
      showBookModal: false,
      showEditModal: false,
      showDeleteModal: false,
      showAddModal: false,

      loading: false,
      uploadingPicture: false,
      error: null,

      // 过滤器信息
      filter: {
        room: '',
        facilities: '',
        capacity: { 
          min:null, 
          max:null 
        },
        building: '',
        type: ''
      },

      // 会议室信息的缓存
      addData: {
        name: '',
        typeid: '',
        locationid: '',
        capacity: '',
        description: '',
        facilities: [],
        imageUrl: '',
        imageFile: null,
      },
      detailData: {
        name: '',
        type: '',
        location: '',
        capacity: '',
        description: '',
        facilities: [],
        imageUrl: ''
      },
      bookData: {
        subject: 'New Booking',
        selectedSlots: [],
      },
      editData: {
        name: '',
        typeid: '',
        capacity: '',
        locationid: '',
        description: '',
        facilities: [],
        imageUrl: '',
        imageFile: null,
      },
      roomDetail: null,
      occupiedSlots: []
    };
  },
  mounted() {
    this.getUserInfo();
  },
  computed: {
    isAdmin(){
      return this.$store.state.userinfo.role == 'ADMIN';
    },
    isUser() {
      return this.$store.state.userinfo.role == 'USER';
    },
    isLocked() {
      return this.$store.state.userinfo.is_locked;
    },
    getRoomName() {
      return this.selectedRoom ? this.selectedRoom.name : '';
    },
    getTableData() {
      if (this.tableData) return this.tableData;
      return [];
    },
    getBuildings() {
      if (this.buildings) return this.buildings;
      return [
            {id: 1, label: 'Science Building A'},
            {id: 2, label: 'Science Building B'},
            {id: 3, label: 'Science Building C'},
            {id: 4, label: 'Science Building D'}
          ];
    },
    getTypes() {
      if (this.types) return this.types;
      return [
            {id: 1, label: 'Small'},
            {id: 2, label: 'Medium'},
            {id: 3, label: 'Big'}
          ];
    },
    getCurrentRoomOccupiedSlots() {
      if (this.occupiedSlots && this.occupiedSlots.length > 0) {
        return this.occupiedSlots;
      }
      return [];
    },
    showBookingButton() {
      return !this.$store.state.userinfo.is_locked;
    },
    typeNotExist () {
      if (!this.types) return false;
      return this.types.every(t => t.label !== this.addData.typeid);
    },
    editTypeNotExist () {
      if (!this.types) return false;
      return this.types.every(t => t.label !== this.editData.typeid);
    },
  },
  methods: {
    userInfoComplete() {
        return this.$store.state.userinfo.username != null && this.$store.state.userinfo.username != '' &&
        this.$store.state.userinfo.userid != null && this.$store.state.userinfo.userid != '' &&
        this.$store.state.userinfo.email != null && this.$store.state.userinfo.email != '' &&
        this.$store.state.userinfo.avatar_path != null && this.$store.state.userinfo.avatar_path != '' &&
        (this.$store.state.userinfo.role == 'ADMIN' || this.$store.state.userinfo.role == 'USER') ;
    },
    async fetchAllInfos() {
      // 页面加载时获取会议室列表
      await this.fetchRoomsList();
            
      // 获取房间类型和位置数据
      await this.fetchRoomTypes();
      await this.fetchBuildings();
    },
    // 获取当前登录用户信息
    async getUserInfo() {
        if (this.userInfoComplete()) {
          await this.fetchAllInfos();

          this.pageLoaded = true;
          return;
        }
        try {
          const response = await axios.get('/api/user/me', { timeout: 5000 });
          if (response.data.code === 200 || response.data.data) {
            const userData = response.data.data;
            // 更新Vuex中的用户信息
            this.$store.commit('userinfo/setUsername', userData.username);
            this.$store.commit('userinfo/setUserID', userData.user_id);
            this.$store.commit('userinfo/setRole', userData.role); 
            if (userData.avatar_url)
              this.$store.commit('userinfo/setAvatarPath', userData.avatar_url);
            else
              this.$store.commit('userinfo/setAvatarPath', 'http://sulthbbxs.hd-bkt.clouddn.com/avatars/default.jpg');

            await this.fetchAllInfos();
            this.pageLoaded = true;
          }
          else {
            this.$router.push('/login');
          }
        } catch (error) {
          console.error('Failed to fetch user info:', error);
          if (error.response && error.response.status === 401) {
            alert('Please login first')
          }
          this.$router.push('/login');
        }
      },
    // 获取会议室列表
    async fetchRoomsList() {
      this.loading = true;
      this.error = null;
      
      try {
        const response = await axios.get('/api/rooms/list', { timeout: 5000 });
        
        if (response.data.code === 200) {
          // 转换后端数据格式为前端表格所需格式
          this.tableData = response.data.data.map(room => ({
            id: room.room_id,
            name: room.room_name,
            type: room.type_name,
            location: room.building_name
          }));
        } else {
          this.error = response.data.message || 'Get room list failed';
          console.error('Get room list failed:', this.error);
        }
      } catch (error) {
        this.error = error.message || 'Network error, please try again later';
        console.error('Get room list error:', error);
      } finally {
        this.loading = false;
      }
    },
    
    // 获取会议室类型列表
    async fetchRoomTypes() {
      try {
        const response = await axios.get('/api/rooms/types', { timeout: 5000 });
        
        if (response.data.code === 200) {
          this.types = response.data.data;
        } else {
          console.error('获取房间类型失败:', response.data.message);
          // 使用备用数据
          this.types = [
            {id: 1, label: 'Small'},
            {id: 2, label: 'Medium'},
            {id: 3, label: 'Big'}
          ];
        }
      } catch (error) {
        console.error('获取房间类型失败:', error);
        // 使用备用数据
        this.types = [
          {id: 1, label: 'Small'},
          {id: 2, label: 'Medium'},
          {id: 3, label: 'Big'}
        ];
      }
    },
    
    // 获取建筑列表
    async fetchBuildings() {
      try {
        const response = await axios.get('/api/rooms/buildings', { timeout: 5000 });
        
        if (response.data.code === 200) {
          this.buildings = response.data.data;
        } else {
          console.error('获取建筑列表失败:', response.data.message);
          // 使用备用数据
          this.buildings = [
            {id: 1, label: 'Science Building A'},
            {id: 2, label: 'Science Building B'},
            {id: 3, label: 'Science Building C'},
            {id: 4, label: 'Science Building D'}
          ];
        }
      } catch (error) {
        console.error('获取建筑列表失败:', error);
        // 使用备用数据
        this.buildings = [
          {id: 1, label: 'Science Building A'},
          {id: 2, label: 'Science Building B'},
          {id: 3, label: 'Science Building C'},
          {id: 4, label: 'Science Building D'}
        ];
      }
    },
    
    // 获取会议室详情
    async fetchRoomDetail(roomId) {
      try {
        const response = await axios.get(`/api/rooms/${roomId}`, { timeout: 5000 });
        
        if (response.data.code === 200) {
          return response.data.data;
          
        } else {
          console.error('Get room detail failed:', response.data.message);
          return null;
        }
      } catch (error) {
        console.error('Get room detail error:', error);
        return null;
      }
    },
    
    processOccupiedSlots(bookings) {
      const WORK_START = 9;   // 工作时段开始小时（可根据需要调整）
      const WORK_END   = 22;  // 工作时段结束小时（可根据需要调整）
      
      // 初始化一个空的时间槽数组
      const slots = [];
      const today = new Date();
      const todayZero = new Date(today);
      todayZero.setHours(0, 0, 0, 0);
      
      const msPerDay = 24 * 60 * 60 * 1000;
      
      // 处理预订时间槽
      if (bookings && bookings.length > 0) {
        bookings.forEach(booking => {
          const start = new Date(booking.start_time);
          const end   = new Date(booking.end_time);
  
          // 用"凌晨"时间来算相差的天数
          const startZero = new Date(start);
          startZero.setHours(0, 0, 0, 0);
          const endZero = new Date(end);
          endZero.setHours(0, 0, 0, 0);
  
          const dayStart = Math.floor((startZero - todayZero) / msPerDay);
          const dayEnd   = Math.floor((endZero   - todayZero) / msPerDay);
  
          // 如果结束日期在 7 天外或结束在今天之前，跳过
          if (dayEnd < 0 || dayStart > 6) return;
  
          // 遍历每一天，把该天对应小时段都标为 occupied
          for (let d = dayStart; d <= dayEnd; d++) {
            if (d < 0 || d > 6) continue;
  
            // 当天的开始小时
            const hStart = (d === dayStart)
              ? start.getHours()
              : WORK_START;
  
            // 当天的结束小时（不含这一小时）
            const hEnd = (d === dayEnd)
              ? end.getHours()
              : WORK_END + 1;
  
            for (let h = hStart; h < hEnd; h++) {
              // 只标记工作时间范围内的小时
              if (h >= WORK_START && h <= WORK_END) {
                slots.push({ day: d, hour: h });
              }
            }
          }
        });
      }
  
      // 把"今天"已经过去的整点当作 occupied（无论是否有booking）
      // 例如当前 12:17，就把 9、10、11、12 都标为占用
      const now = new Date();
      const currentHour = now.getHours();
      for (let h = WORK_START; h <= Math.min(currentHour, WORK_END); h++) {
        slots.push({ day: 0, hour: h });
      }
  
      // 去重
      const unique = [];
      const seen = new Set();
      slots.forEach(s => {
        const key = `${s.day}-${s.hour}`;
        if (!seen.has(key)) {
          seen.add(key);
          unique.push(s);
        }
      });
  
      return unique;
    },
    
    getRoomID() {
      return this.selectedRoom ? this.selectedRoom.id : -1;
    },
    
    async getCurrentRoomDetails() {
      let id = this.getRoomID();
      if (id === -1) {
        return {
          name: '', 
          type: '', 
          typeid: 1, 
          locationid: 1, 
          location: '',
          capacity: '', 
          description: '', 
          facilities: [], 
          imageUrl: '', 
          occupiedSlots: []
        };
      }

      // 获取会议室详情
      const roomDetail = await this.fetchRoomDetail(id);
      console.log('roomDetail:', roomDetail);
      if (roomDetail) {
        this.roomDetail = roomDetail;
        
        // 处理占用时间槽，从recent_bookings中获取数据
        this.occupiedSlots = this.processOccupiedSlots(roomDetail.recent_bookings);
        
        const result = {
          name: roomDetail.room_name || '',
          typeid: roomDetail.type_id || 1,
          type: roomDetail.type_name || '',
          locationid: roomDetail.building_id || 1,
          location: roomDetail.building_name || '',
          capacity: roomDetail.capacity ? roomDetail.capacity.toString() : '0',
          description: roomDetail.description || 'No description',
          facilities: roomDetail.facilities || [],
          imageUrl: roomDetail.image_url || " ",
          occupiedSlots: this.occupiedSlots
        };
   
        return result;
      }
      
      return {
        name: this.selectedRoom.name, 
        typeid: 1, 
        type: this.selectedRoom.type,
        locationid: 1, 
        location: this.selectedRoom.location,
        capacity: '10', 
        description: 'A normal meeting room', 
        facilities: ['Projector', 'Microphone', 'Screen'], 
        imageUrls: [],
        occupiedSlots: []
      };
    },
    
    async setDetailModal() {
      const currentRoom = await this.getCurrentRoomDetails();
      this.detailData.name = currentRoom.name;
      this.detailData.type = currentRoom.type;
      this.detailData.location = currentRoom.location;
      this.detailData.capacity = currentRoom.capacity;
      this.detailData.description = currentRoom.description;
      this.detailData.facilities = currentRoom.facilities;
      this.detailData.imageUrl = currentRoom.imageUrl;
    },
    
    setAddModal() {
      this.addData.name = 'New Room';
      this.addData.typeid = this.types ? this.types[0].label : '';
      this.addData.capacity = '';
      this.addData.locationid = this.buildings ? this.buildings[0].label : '';
      this.addData.description = 'A new meeting room.';
      this.addData.facilities = [];
      this.addData.imageUrl = 'http://sulthbbxs.hd-bkt.clouddn.com/rooms/default.jpg';
      this.addData.imageFile = null;
    },
    
    async setBookModal() {
      const currentRoom = await this.getCurrentRoomDetails();
      this.bookData.selectedSlots = [];
      this.occupiedSlots = currentRoom.occupiedSlots;
    },
    
    async setEditModal() {
      const currentRoom = await this.getCurrentRoomDetails();

      this.editData.name = currentRoom.name || '';
      this.editData.typeid = currentRoom.type || '';
      this.editData.locationid = currentRoom.location || '';
      this.editData.description = currentRoom.description;
      this.editData.facilities = currentRoom.facilities;
      this.editData.imageUrl = currentRoom.imageUrl;
    },
    
    openAddRoomModal() {
      this.showAddModal = true;
      this.setAddModal();
    },
    
    async openDetailModal(row) {
      this.selectedRoom = row;
      this.showDetailModal = true;

      this.detailData.name = '';
      this.detailData.type = '';
      this.detailData.location = '';
      this.detailData.capacity = '';
      this.detailData.description = '';
      this.detailData.facilities = [];
      this.detailData.imageUrl = '';

      await this.setDetailModal();
    },

    async openBookModal(row, rowIndex) {
      console.log("Book room", row, rowIndex);
      this.selectedRoom = row;
      this.showBookModal = true;
      await this.setBookModal();
    },
    
    async openEditModal(row, rowIndex) {
      this.selectedRoom = row;
      this.showEditModal = true;

      this.editData.name = '';
      this.editData.typeid = '';
      this.editData.locationid = '';
      this.editData.description = '';
      this.editData.facilities = [];
      this.editData.imageUrl = '';

      await this.setEditModal();
    },
    
    openDeleteModal(row, rowIndex) {
      console.log("Delete room", row, rowIndex);
      this.selectedRoom = row;
      this.showDeleteModal = true;
    },
    
    closeAddModal() {
      this.showAddModal = false;
    },
    
    closeDetailModal() {
      this.showDetailModal = false;
    },
    
    closeBookModal() {
      this.showBookModal = false;
    },
    
    closeEditModal() {
      this.showEditModal = false;
    },
    
    closeDeleteModal() {
      this.showDeleteModal = false;
    },
    
    async confirmAdd() {
      try {
        const formData = new FormData();
        formData.append('room_name', this.addData.name);
        formData.append('type_name', this.addData.typeid);          // String
        formData.append('capacity', this.addData.capacity);         // Number, null if type is in  
        formData.append('building_name', this.addData.locationid);  // String

        for (let i = 0; i < this.addData.facilities.length; i++) {
          formData.append('facilities', this.addData.facilities[i]);
        }
        
        if (this.addData.imageFile) {
          const parts = this.addData.imageFile.name.split('.');
          const ext = parts.length > 1 ? parts.pop() : 'png';

          const filename = `${Date.now()}.${ext}`;
          formData.append('roomImage', this.addData.imageFile, filename);
        }
      
        const response = await axios.post('/api/admin/rooms/add', 
          formData, 
          {
            headers: {
              'Content-Type': 'multipart/form-data'
            },
            timeout: 5000
          }
        )

        if (response.data.code === 200) {
          alert('Room added successfully!');
          // 添加成功后刷新
          this.fetchAllInfos()

          this.closeAddModal();
        } else {
          console.error('Adding room failed:', response.data.message);
          alert('Adding room failed: ' + response.data.message);
        }
      } catch (error) {
        console.error('Adding room failed:', error);
        alert('Adding room failed, please try again later.');
      } finally {
        
      }
    },

    toLocalISOString(date) {
      // 用毫秒 + 时区偏移，转换回 UTC 
      const tzOffset = date.getTimezoneOffset() * 60000;
      const localISO = new Date(date - tzOffset)
        .toISOString()
        .slice(0, -5);
      return localISO;
    },
    
    async confirmBook() {
      const roomId = this.getRoomID();
      if (roomId === -1) return;
      
      try {
        // 检查是否选择了时间槽
        if (!this.bookData.selectedSlots || this.bookData.selectedSlots.length === 0) {
          alert('请选择至少一个时间槽');
          return;
        }
        
        // 对选中的时间槽进行排序（按日期和小时排序）
        const sortedSlots = [...this.bookData.selectedSlots].sort((a, b) => {
          if (a.day !== b.day) {
            return a.day - b.day;
          }
          return a.hour - b.hour;
        });
        
        // 检查是否所有时间槽都在同一天
        const firstDay = sortedSlots[0].day;
        const allSameDay = sortedSlots.every(slot => slot.day === firstDay);
        
        if (!allSameDay) {
          alert('不允许跨天预订，请选择同一天的时间槽');
          return;
        }
        
        // 检查时间槽是否连续
        let isConsecutive = true;
        for (let i = 1; i < sortedSlots.length; i++) {
          const prevSlot = sortedSlots[i-1];
          const currSlot = sortedSlots[i];
          
          // 小时必须连续
          if (currSlot.hour !== prevSlot.hour + 1) {
            isConsecutive = false;
            break;
          }
        }
        
        if (!isConsecutive) {
          alert('请选择连续的时间槽');
          return;
        }
        
        // 创建开始时间（第一个时间槽）
        const firstSlot = sortedSlots[0];
        const startDate = new Date();
        startDate.setDate(startDate.getDate() + firstSlot.day);
        startDate.setHours(firstSlot.hour, 0, 0, 0);
        
        // 创建结束时间（最后一个时间槽结束时间）
        const lastSlot = sortedSlots[sortedSlots.length - 1];
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + lastSlot.day);
        endDate.setHours(lastSlot.hour + 1, 0, 0, 0); // 结束时间是最后一个槽的下一个小时

        // 准备预订请求数据，使用与后端API匹配的参数名
        const bookingData = {
          room_id: roomId,
          subject: this.bookData.subject,
          start_time: this.toLocalISOString(startDate),
          end_time: this.toLocalISOString(endDate),
        };

        console.log('start time: ' + startDate.getHours());
        console.log('end time: ' + endDate.getHours());

        console.log('start string:' + bookingData.start_time);
        console.log('end string: ' + bookingData.end_time);
        
        // 发送预订请求
        const response = await axios.post('/api/bookings/application', bookingData, {timeout: 5000});
        
        if (response.data.code === 200) {
          console.log('Booking successful!');
          alert('Booking request submitted successfully!');
          this.closeBookModal();
        } else {
          console.error('Booking failed:', response.data.message);
          alert('Booking failed: ' + response.data.message);
        }
      } catch (error) {
        console.error('Booking error:', error);
        alert('Booking failed, please try again later');
      }
    },
    
    async confirmEdit() {
      const roomId = this.getRoomID();
      if (roomId === -1) return;
      
      try {
        // 准备请求数据，根据后端API需要的格式
        const roomRequest = {
          room_name: this.editData.name,
          type_name: this.editData.typeid,
          capacity: this.editData.capacity,
          building_name: this.editData.locationid,
          facilities: this.editData.facilities,
          // description: this.editData.description,
        };

        if (this.editData.imageFile) {
          await this.uploadRoomPicture(this.editData.imageFile);
        }
        
        // 调用更新房间信息的API
        const response = await axios.post(`/api/admin/rooms/${roomId}/edit`, roomRequest, {timeout: 5000});
        if (response.data.code === 200) {
          alert('Room updated successfully!');
          // 编辑成功后刷新
          this.fetchAllInfos()
          
          this.closeEditModal();
        } else {
          console.error('Edit room failed:', response.data.message);
          alert('Edit room failed: ' + response.data.message);
        }
      } catch (error) {
        console.error('Edit room failed:', error);
        alert('Edit room failed, please try again later.');
      }
    },
    
    async confirmDelete() {
      const roomId = this.getRoomID();
      if (roomId === -1) return;
      
      try {
        // 这里添加删除房间的API调用，需要管理员权限
        const response = await axios.get(`/api/admin/rooms/delete/${roomId}`);
        console.log("Delete room response:", response);
        if (response.data.code === 200) {
          alert('Room deleted successfully!');
        } else {
          console.error('Delete room failed:', response.data.message);
          alert('Delete room failed: ' + response.data.message);
        }
      } catch (error) {
        console.error('Delete room failed:', error);
      } finally {
        this.fetchRoomsList();
        this.closeDeleteModal();
      }
    },

    async handleSearch(filters) {
      this.filter = filters;
      const filterReq = {
        building_id: filters.building,
        capacityMax: filters.capacity.max,
        capacityMin: filters.capacity.min,
        room_name: filters.room,
        facility: filters.facilities,
      };

      console.log("Search filters:", filterReq);

      try {
        const response = await axios.post('/api/rooms/query-list', filterReq, { timeout: 5000 });
        
        if (response.data.code === 200) {
          this.tableData = response.data.data.map(room => ({
            id: room.room_id,
            name: room.room_name,
            type: room.type_name,
            location: room.building_name,
          }));
        } else {
          console.error('获取筛选列表失败:', response.data.message);
        }
      } catch (error) {
        console.error('获取建筑列表失败:', error);
      }
    },

    async resetFilters() {
      const filterReq = {
      };

      console.log("Search filters:", filterReq);

      try {
        const response = await axios.post('/api/rooms/query-list', filterReq, { timeout: 5000 });
        
        if (response.data.code === 200) {
          this.tableData = response.data.data.map(room => ({
            id: room.room_id,
            name: room.room_name,
            type: room.type_name,
            location: room.building_name,
          }));

          this.filter = {
              room: '',
              facilities: '',
              capacity: { 
                min:null, 
                max:null 
              },
              building: '',
              type: ''
            };
        } else {
          console.error('获取筛选列表失败:', response.data.message);
        }
      } catch (error) {
        console.error('获取建筑列表失败:', error);
      }
    },

    changeAddImageFile(file) {
      this.addData.imageFile = file;
    },

    changeEditImageFile(file) {
      this.editData.imageFile = file;
    },

    async uploadRoomPicture(file) {
        if (this.uploadingPicture) return;

        this.uploadingPicture = true;

        try {
          const formData = new FormData();

          const parts = file.name.split('.');
          const ext = parts.length > 1 ? parts.pop() : 'png';

          const filename = `${Date.now()}.${ext}`;
          formData.append('image', file, filename);
          
          const response = await axios.post(
            `/api/admin/rooms/${this.selectedRoom.id}/changeImage`,
            formData,
            {
              headers: {
                'Content-Type': 'multipart/form-data'
              },
              timeout: 5000
            }
          );

          if (response.data && response.data.data) {
            this.$emit('upload-success', response.data);
          } else {
            console.warn('上传完成，但后端返回失败：', response.data);
            this.$emit('upload-failed', response.data);
          }
        } catch (err) {
          console.error('上传出错：', err);
          this.$emit('upload-error', err);
        } finally {
          this.uploadingPicture = false;
        }
      },
    }
};
</script>

<style scoped>
h2 {
  font-family: 'Rethink Sans', sans-serif;
  font-size: 24px;
  color: #FFFFFF;
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 1px solid #333333;
}

h4 {
  font-family: 'Rethink Sans', sans-serif;
  font-size: 18px;
  color: #DD2525;
  margin: 30px 0 10px;
}

.profile-page {
  background-color: #151517;
  min-height: 100vh;
  display: flex;
  align-items: flex-start;
}

.split-layout {
  display: flex;
  width: 100%;
}

.sidebar-container {
  width: 250px;
  flex-shrink: 0;
}

.central-section-wrapper {
  flex: 1;
  display: flex;
  justify-content: center;
  padding: 0 20px;
}

.central-section {
  width: 100%;
  max-width: 1200px;
  padding: 30px 40px;
  background-color: #151517;
}

.rooms-container {
  margin-bottom: 30px;
  background-color: transparent;
  border-radius: 8px;
  padding: 30px;
}

.action-buttons-container {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  align-items: center;
}
</style>
