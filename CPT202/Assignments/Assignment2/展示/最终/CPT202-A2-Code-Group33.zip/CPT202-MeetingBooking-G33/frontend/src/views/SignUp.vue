<template>
  <div class="signup-page">
    <img class="bg-image" :src="backgroundImage" alt="Background" />
    <div class="form-container" ref="formContainer">
      <h2>Booking System</h2>
      <div class="fade-in" ref="fadeInContainer">
        <h3>Sign Up</h3>
        <form @submit.prevent="handleSignUp">
          <AvatarUploadField
            id="avatar-upload"
            label="Avatar"
            :size="50"
            :disabled="false"
            v-model="form.avatar_url"
            @file-selected="setAvatarFile"
          />
          <InputField
            id="username"
            label="Username"
            placeholder="Enter your username"
            v-model="form.username"
          />
          <InputField
            id="student_id"
            label="Student ID"
            placeholder="Enter your Student ID"
            v-model="form.student_id"
          />
          <InputField
            id="email"
            label="Email"
            type="email"
            placeholder="Enter your email"
            v-model="form.email"
          />
          <InputFieldButton
            label="Captcha"
            placeholder="Enter Captcha"
            buttonText="Send Captcha"
            v-model="form.captcha"
            @click="handleCaptchaSend"
            :disabled="captchaButtonDisabled"
          />
          <InputField
            id="password"
            label="Password"
            type="password"
            placeholder="Enter your password"
            v-model="form.password"
          />
          <InputField
            id="confirm-password"
            label="Confirm Password"
            type="password"
            placeholder="Enter your password again"
            v-model="form.confirmPassword"
          />
          <Button
            label="Sign Up"
            type="primary"
            @click="handleSignUp"
            :loading="isLoading"
          />
        </form>
        <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
        <div class="links">
          <h4>Already have an account?</h4>
          <Button label="Log in" type="secondary" @click="transitionToLogin" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import InputField from '@/components/InputField.vue';
  import Button from '@/components/Button.vue';
  import BgImage from '@/assets/background.png';
  import InputFieldButton from '@/components/InputFieldButton.vue';
  import AvatarUploadField from '@/components/AvatarUploadField.vue';
  import axios from 'axios';

  export default {
    name: 'SignUp',
    components: {
      AvatarUploadField,
      InputField,
      Button,
      InputFieldButton,
    },
    data() {
      return {
        backgroundImage:  BgImage, // 替换为实际背景图URL
        form: {
          avatar_file: '',
          avatar_url: '',
          username: '',
          email: '',
          password: '',
          confirmPassword: '',
          captcha: '',
          student_id: '',
        },
        targetContainerHeight: '495px',
        isLoading: false,
        captchaButtonDisabled: false,
        captchaCountdown: 0,
        countdownInterval: null,
        errorMessage: '',
      };
    },
    mounted() {
      const container = this.$refs.formContainer;
      container.style.height = 880 + 'px';
    },
    beforeDestroy() {
      // 清除倒计时计时器
      if (this.countdownInterval) {
        clearInterval(this.countdownInterval);
      }
    },
    methods: {
      setAvatarFile(file) {
        this.form.avatar_file = file;
      },

      async handleSignUp() {
        if (this.isLoading) return;

        // 表单验证
        if (!this.form.username || !this.form.email || !this.form.password || !this.form.confirmPassword || !this.form.captcha) {
          this.errorMessage = '请填写所有必填字段';
          return;
        }

        if (this.form.password !== this.form.confirmPassword) {
          this.errorMessage = '两次输入的密码不一致';
          return;
        }

        this.isLoading = true;
        this.errorMessage = '';

        try {
          // 用 FormData 构造 multipart/form-data
          const formData = new FormData();
          formData.append('username', this.form.username);
          formData.append('email',    this.form.email);
          formData.append('password', this.form.password);
          formData.append('code',     this.form.captcha);

          if (this.form.avatar_file) {
            const parts = this.form.avatar_file.name.split('.');
            const ext = parts.length > 1 ? parts.pop() : 'png';

            const filename = `${Date.now()}.${ext}`;
            formData.append('file', this.form.avatar_file, filename);
          }

          // 发送 multipart 请求
          const response = await axios.post('/api/user/register', formData, {timeout: 5000});

          if (response.data.code === 200) {
            console.log('Registration successful:', response.data);
            alert('Registration successful! Please log in.');
            this.transitionToLogin();
          } else {
            this.errorMessage = response.data.message || 'Registration failed';
          }
        } catch (error) {
          // 处理网络错误或服务器错误
          console.error('Registration error:', error);
          this.errorMessage = (error.response && error.response.data && error.response.data.message) ||
                             'Registration failed, please try again later.';
        } finally {
          this.isLoading = false;
        }
      },

      async handleCaptchaSend() {
        if (this.captchaButtonDisabled) return;

        // 验证邮箱格式
        if (!this.form.email || !/\S+@\S+\.\S+/.test(this.form.email)) {
          this.errorMessage = 'Please enter a valid email address';
          return;
        }

        this.captchaButtonDisabled = true;

        try {
          // 调用发送验证码的API
          const response = await axios.get(`/api/user/ask_code?email=${encodeURIComponent(this.form.email)}`, {timeout: 5000});

          if (response.data && response.data.code === 200) {
            console.log('Captcha sent successfully:', response.data);
            // 启动倒计时
            this.startCaptchaCountdown();
          } else {
            this.errorMessage = response.data.message || 'Captcha sending failed, please try again later.';
            this.captchaButtonDisabled = false;
          }
        } catch (error) {
          console.error('Captcha sending error:', error);
          this.errorMessage = (error.response && error.response.data && error.response.data.message) ||
                             'Captcha sending failed, please try again later.';
          this.captchaButtonDisabled = false;
        }
      },

      startCaptchaCountdown() {
        this.captchaCountdown = 60;
        this.countdownInterval = setInterval(() => {
          if (this.captchaCountdown > 0) {
            this.captchaCountdown--;
          } else {
            clearInterval(this.countdownInterval);
            this.captchaButtonDisabled = false;
            this.captchaCountdown = 0;
          }
        }, 1000);
      },

      transitionToLogin() {
        const fadeInEl = this.$refs.fadeInContainer;
        const containerEl = this.$refs.formContainer;
        fadeInEl.classList.add('fade-out');
        fadeInEl.addEventListener(
          'animationend',
          () => {
            containerEl.style.height = this.targetContainerHeight;
            containerEl.addEventListener(
              'transitionend',
              () => {
                this.$router.push('/login');
              },
              { once: true }
            );
          },
          { once: true }
        );
      }
    },
  };
</script>

<style scoped>

  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  @keyframes fadeOut {
    from { opacity: 1; }
    to { opacity: 0; }
  }

  .signup-page {
    position: relative;
    overflow-y: auto;
  }

  .bg-image {
    display: block;
    width: 100%;
    height: auto;
  }

  .fade-in {
    animation: fadeIn 0.5s ease-out forwards;
  }

  .fade-out {
    animation: fadeOut 0.5s ease-out forwards;
  }

  .form-container {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(240, 242, 255, 0.85);
    padding: 30px 30px 15px;
    border-radius: 10px;
    width: 100%;
    max-width: 400px;
    text-align: center;
    transition: height 0.25s ease-out;
  }

  h2 {
    font-size: 42px;
    margin-bottom: 10px;
    font-family: 'Rethink Sans', sans-serif;
    color: #76778E;
    font-weight: 600;
  }

  h3 {
    font-size: 30px;
    margin: 0 0 20px 0;
    text-align: left;
    font-family: 'Rethink Sans', sans-serif;
    color: #252837;
    font-weight: 600;
  }

  h4 {
    font-size: 16px;
    margin: 0 0 -20px 0;
    font-family: 'Rethink Sans', sans-serif;
    font-weight: 600;
    color: #878787
  }

  .links {
    margin-top: 15px;
  }

  .error-message {
    color: red;
    font-size: 14px;
    margin-top: 10px;
  }
</style>
