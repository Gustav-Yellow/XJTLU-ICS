<template>
    <div class="profile-page">
      <div class="split-layout">
        <!-- 左侧 Sidebar -->
        <div class="sidebar-container">
          <sidebar-menu  :pageLoaded="pageLoaded" />
        </div>
        <!-- 右侧中央区域 -->
        <div v-if="pageLoaded" class="central-section-wrapper">
          <div class="central-section">
            <div class="section-container rooms-container">
              <h2>Users</h2>
              <data-table 
                ref="table"
                :headers="tableHeaders" 
                :data="getTableData"
                header-bg-color="transparent"
                :header-bg-opacity="1"
                body-bg-color="transparent"
                :body-bg-opacity="1"
                :allow-actions="true"
                :defaultPageSize="10"
                :showExtraIconButton="true"
                :extraIconButtonProps="{
                  backgroundColor: 'rgba(37, 40, 55, 1)',
                  borderEnabled: false,
                  imageContent: `
                  <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='transparent' stroke='#ffffff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-circle-plus-icon lucide-circle-plus'>
                    <circle cx='12' cy='12' r='10'/>
                    <path d='M8 12h8'/>
                    <path d='M12 8v8'/>
                  </svg>`,
                  imageColor: 'transparent',
                  textContent: 'Add',
                  textColor: '#ffffff',
                  size: 14
                }"
                :showFilter="true"
                :filterConfig="[{ 
                    field:'username',      
                    type:'text',   
                    props:{ 
                      label:'Name',      
                      placeholder:'enter username…',      
                      defaultValue:'',  
                      validateFn:v=>true
                    } 
                  }, { 
                    field:'email',
                    type:'text',   
                    props:{ 
                      label:'Email',  
                      placeholder:'enter email…',  
                      defaultValue:'',  
                      validateFn:v=>true 
                    } 
                  }, { 
                    field:'booking_count',      
                    type:'range', 
                    props:{ 
                      label:'Booking Count',  
                      placeholderMin:'min', 
                      placeholderMax:'max', 
                      defaultMin:0, 
                      validateFn:({min, max}) => min <= max 
                    } 
                  },
                ]"
                @row-click="openDetailModal"
                @extra-icon-click="openAddModal"
                @filter-search="handleSearch"
                @filter-cancel="resetFilters"
              >
                <template #actions="{ row, rowIndex }">
                  <div class="action-buttons-container">
                    <icon-button
                      background-color="#830A0A"
                      :border-enabled="false"
                      image-content='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="transparent" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>'
                      image-color="rgba(0, 0, 0, 0)"
                      text-content="Delete"
                      text-color="#ffffff"
                      :size="14"
                      @click="openDeleteModal(row, rowIndex)"
                    />
                  </div>
                </template>
              </data-table>
            </div>
          </div>
        </div>
        <LoadingMessage v-else message="Redirecting..." />
      </div>
  
      <!-- Add Modal -->
      <Modal :visible="showAddModal" width="520px" autoHeight panelBgColor="#151517" @close="closeAddModal">
        <h2>Add User</h2>
        <EditableLabel 
          prefix="Name"
          prefixColor="white"
          :modelValue="addData.username"
          @update:modelValue="addData.username  = $event"
          valueColor="white"
          :showEditButton="true"
        />
        <EditableLabel 
          prefix="Email"
          prefixColor="white"
          :modelValue="addData.email"
          @update:modelValue="addData.email = $event"
          valueColor="white"
          :showEditButton="true"
        />
        <EditableLabel 
          prefix="Password"
          prefixColor="white"
          :modelValue="addData.password"
          @update:modelValue="addData.password = $event"
          valueColor="white"
          :showEditButton="true"
        />
        <EditableSelect
          prefix="Role"
          prefixColor="white"
          valueColor="white"
          :modelValue="addData.role"
          @update:modelValue="addData.role = $event"
          :options="roles"
          :showEditButton="true"
          dropdownLeft=80
        />
        <CustomButton 
          label="Confirm"
          @click="confirmAdd" 
          :primary-bg-color="'rgba(72, 140, 70, 1)'"
          :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
          :primary-text-color="'#ffffff'"
        />
        <CustomButton
          label="Cancel" 
          @click="closeAddModal" 
          :primary-bg-color="'rgba(37, 40, 55, 1)'"
          :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
          :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
          :primary-text-color="'#ffffff'"
        />
      </Modal>
  
      <!-- Detail Modal -->
      <Modal :visible="showDetailModal" width="550px" :autoHeight="true" panelBgColor="#151517" @close="closeDetailModal">
        <h2>{{ detailData.username + (detailData.is_locked ? '(Locked)' : '')}}</h2>
        <h4 v-if="detailData.is_locked">This account has been locked</h4>
        <EditableLabel 
          prefix="ID"
          prefixColor="white"
          :modelValue="detailData.user_id"
          valueColor="white"
        />
        <EditableLabel
          prefix="Email"
          prefixColor="white"
          :modelValue="detailData.email"
          valueColor="white"
        />
        <EditableLabel
          prefix="Role"
          prefixColor="white"
          :modelValue="detailData.role"
          valueColor="white"
        />
        <EditableLabel
          prefix="Create Time"
          prefixColor="white"
          :modelValue="detailData.created_at"
          valueColor="white"
        />
        <EditableLabel
          prefix="Update Time"
          prefixColor="white"
          :modelValue="detailData.updated_at"
          valueColor="white"
        />
        <ItemList
          title="Bookings"
          :modelValue="detailData.booking_history"
          :renderers="itemFieldRenderers"
          :container-height="400"
          :container-width="500"
          @card-click="openBookDetailModal"
         />
         <CustomButton 
            v-if="!detailData.is_locked"
            label="Lock User" 
            @click="confirmLock" 
            :primary-bg-color="'rgba(131, 10, 10, 1)'"
            :primary-hover-bg-color="'rgba(131, 10, 10, 0.9)'"
            :primary-active-bg-color="'rgba(131, 10, 10, 0.5)'"
            :primary-text-color="'#ffffff'"
          />
          <CustomButton
              v-if="detailData.is_locked"
              label="Unlock User" 
              @click="confirmUnlock" 
              :primary-bg-color="'rgba(37, 40, 55, 1)'"
              :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
              :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
              :primary-text-color="'#ffffff'"
          />
      </Modal>

      <!-- Delete Modal -->
      <Modal :visible="showDeleteModal" width="500px" height="280px" panelBgColor="#151517" @close="closeDeleteModal">
        <h2>Delete User</h2>
        <h4>Delete user {{ selectedUser ? selectedUser.username : '' }} ?</h4>
        <CustomButton 
            label="Delete" 
            @click="confirmDelete" 
            :primary-bg-color="'rgba(131, 10, 10, 1)'"
            :primary-hover-bg-color="'rgba(131, 10, 10, 0.9)'"
            :primary-active-bg-color="'rgba(131, 10, 10, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
        <CustomButton
            label="Cancel" 
            @click="closeDeleteModal" 
            :primary-bg-color="'rgba(37, 40, 55, 1)'"
            :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
            :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
      </Modal>
      <!-- Booking Detail Modal -->
      <Modal :visible="showBookingDetailModal" width="400px" autoHeight panelBgColor="#151517" @close="closeBookingDetailModal">
        <h2>Booking {{ selectedBookID || '' }}</h2>
        <EditableLabel 
          prefix="Room"
          prefixColor="white"
          :modelValue="bookingDetailData.room"
          valueColor="white"
        />
        <EditableLabel 
          prefix="Subject"
          prefixColor="white"
          :modelValue="bookingDetailData.subject"
          valueColor="white"
        />
        <EditableLabel 
          prefix="Status"
          prefixColor="white"
          :modelValue="bookingDetailData.status"
          valueColor="white"
        />
        <EditableLabel
          prefix="Start Time"
          prefixColor="white"
          :modelValue="bookingDetailData.start_time"
          valueColor="white"
        />
        <EditableLabel
          prefix="End Time"
          prefixColor="white"
          :modelValue="bookingDetailData.end_time"
          valueColor="white"
        />
        <EditableLabel
          prefix="Create Time"
          prefixColor="white"
          :modelValue="bookingDetailData.create_time"
          valueColor="white"
        />
        <EditableLabel
          prefix="Update Time"
          prefixColor="white"
          :modelValue="bookingDetailData.update_time"
          valueColor="white"
        />
        <CustomButton 
          v-if="bookingDetailData.status == 'pending'"
          label="Accept"
          @click="openAcceptModal" 
          :primary-bg-color="'rgba(72, 140, 70, 1)'"
          :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
          :primary-text-color="'#ffffff'"
        />
        <CustomButton 
            v-if="bookingDetailData.status == 'pending'"
            label="Reject" 
            @click="openRejectModal" 
            :primary-bg-color="'rgba(131, 10, 10, 1)'"
            :primary-hover-bg-color="'rgba(131, 10, 10, 0.9)'"
            :primary-active-bg-color="'rgba(131, 10, 10, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
        <CustomButton
            v-if="bookingDetailData.status == 'pending'"
            label="Close" 
            @click="closeBookingDetailModal" 
            :primary-bg-color="'rgba(37, 40, 55, 1)'"
            :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
            :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
      </Modal>
      <!-- Accept Modal -->
      <Modal :visible="showAcceptModal" width="500px" autoHeight panelBgColor="#151517" @close="closeAcceptModal">
        <h2>Accept Booking {{ selectedBookID }}</h2>
        <EditableLabel 
          prefix="Review"
          prefixColor="white"
          :modelValue="acceptData.review"
          @update:modelValue="acceptData.review = $event"
          valueColor="white"
          :showEditButton="true"
        />
        <CustomButton 
          label="Accept"
          @click="confirmAccept" 
          :primary-bg-color="'rgba(72, 140, 70, 1)'"
          :primary-hover-bg-color="'rgba(72, 140, 70, 0.9)'"
          :primary-text-color="'#ffffff'"
        />
        <CustomButton
          label="Cancel" 
          @click="closeAcceptModal" 
          :primary-bg-color="'rgba(37, 40, 55, 1)'"
          :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
          :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
          :primary-text-color="'#ffffff'"
        />
      </Modal> 
  
      <!-- Reject Modal -->
      <Modal :visible="showRejectModal" width="500px" height="280px" panelBgColor="#151517" @close="closeRejectModal">
        <h2>Reject Booking {{ selectedBookID }}</h2>
        <EditableLabel 
          prefix="Review"
          prefixColor="white"
          :modelValue="rejectData.review"
          @update:modelValue="rejectData.review = $event"
          valueColor="white"
          :showEditButton="true"
        />
        <CustomButton 
            label="Reject" 
            @click="confirmReject" 
            :primary-bg-color="'rgba(131, 10, 10, 1)'"
            :primary-hover-bg-color="'rgba(131, 10, 10, 0.9)'"
            :primary-active-bg-color="'rgba(131, 10, 10, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
        <CustomButton
            label="Cancel" 
            @click="closeRejectModal" 
            :primary-bg-color="'rgba(37, 40, 55, 1)'"
            :primary-hover-bg-color="'rgba(37, 40, 55, 0.9)'"
            :primary-active-bg-color="'rgba(37, 40, 55, 0.5)'"
            :primary-text-color="'#ffffff'"
        />
      </Modal>
    </div>
  </template>
  
  <script>
  
  import SidebarMenu from '@/components/SidebarMenu.vue';
  import DataTable from '@/components/DataTable.vue';
  import IconButton from '@/components/IconButton.vue';
  import Modal from '@/components/Modal.vue';
  import CustomButton from '@/components/Button.vue';
  import EditableLabel from '@/components/EditableLabel.vue';
  import ItemList from '@/components/ItemList.vue';
  import EditableSelect from '@/components/EditableSelect.vue';
  import LoadingMessage from '../components/LoadingMessage.vue';
  import axios from 'axios';
  import { formatDateTime } from '@/functions/formatDateTime';
  
  export default {
    name: 'UsersPage',
    components: {
      SidebarMenu,
      DataTable,
      IconButton,
      Modal,
      CustomButton,
      EditableLabel,
      ItemList,
      LoadingMessage,
      EditableSelect,
    },
    data() {
      return {
        pageLoaded: false,

        profile: {
          role: this.$store.state.userinfo.role,
        },
  
        tableHeaders: [
          { key: 'user_id', label: 'ID' },
          { key: 'username', label: 'Name' },
          { key: 'email', label: 'Email' },
          { key: 'booking_count', label: 'Booking Count' }
        ],

        roles: [
          {id: 1, label: 'ADMIN'}, 
          {id: 2, label: 'USER'}
        ],

        itemFieldRenderers: {
          booking_id:{
            component: 'EditableLabel',
            propMapping: {
              value: 'modelValue',
              staticProps: {
                prefix: 'Booking ID',
                prefixColor: 'white',
                valueColor: 'white',
              }
            }
          },
          room_name:{
            component: 'EditableLabel',
            propMapping: {
              value: 'modelValue',
              staticProps: {
                prefix: 'Room',
                prefixColor: 'white',
                valueColor: 'white',
              }
            }
          },
          start_time:{
            component: 'EditableLabel',
            propMapping: {
              value: 'modelValue',
              staticProps: {
                prefix: 'Start Time',
                prefixColor: 'white',
                valueColor: 'white',
              }
            }
          },
          end_time:{
            component: 'EditableLabel',
            propMapping: {
              value: 'modelValue',
              staticProps: {
                prefix: 'End Time',
                prefixColor: 'white',
                valueColor: 'white',
              }
            }
          },
          status:{
            component: 'EditableLabel',
            propMapping: {
              value: 'modelValue',
              staticProps: {
                prefix: 'Status',
                prefixColor: 'white',
                valueColor: 'white',
              }
            }
          },
        },

        // 用来保存当前的所有缓存信息
        tableData: null,
        buildings: null,
        types: null,
        // 用来保存当前选中的房间数据 {id, name, type, location}
        selectedUser: null,
        // 控制弹窗的显示
        showDetailModal: false,
        showBookModal: false,
        showEditModal: false,
        showDeleteModal: false,
        showAddModal: false,
        showBookingDetailModal: false,
        showAcceptModal: false,
        showRejectModal: false,
        selectedBookID: null,
  
        // 用户信息的缓存
        addData: {
          username: '',
          email: '',
          password: '',
          role: '',
        },
        detailData: {
          user_id: '',
          username: '',
          email: '',
          role: '',
          is_locked: false,
          created_at: '',
          updated_at: '',
          booking_history: [{
            booking_id: 1,
            room_name: 'SD 512',
            start_time: '2025-04-14T17:11:00.000+00.00',
            end_time: '2025-04-14T17:11:00.000+00.00',
            status: 'Approved',
          },
          {
            booking_id: 1,
            room_name: 'SD 512',
            start_time: '2025-04-14T17:11:00.000+00.00',
            end_time: '2025-04-14T17:11:00.000+00.00',
            status: 'Approved',
          }]
        },
        bookingDetailData: {
          booking_id: '',
          room: '',
          subject: '',
          start_time: '',
          end_time: '',
          status: '',
          review_time: '',
          admin_reply: '',
          create_time: '',
          update_time: '',
        },
        acceptData: {
          review: '',
        },
        rejectData: {
          review: '',
        },
      };
    },
    mounted() {
      this.getUserInfo();
    },
    computed: {
      getUserID() {
        return this.selectedUser ? this.selectedUser.user_id : -1;
      },
      getRoomName() {
        return this.selectedUser ? this.selectedUser.name : '';
      },
      getTableData() {
        if (this.tableData) return this.tableData;
  
        // 这里补充获得所有用户信息的逻辑
        this.tableData = [
          { user_id: 1, username: 'San.Zhang', email: 'San.Zhang@student.xjtlu.edu.cn', booking_count: '3' },
          { user_id: 2, username: 'Erick.Purowanto', email: 'Erick.Purowanto@xjtlu.edu.cn', booking_count: '62' },
          { user_id: 3, username: 'Hai-Ning.Liang', email: 'Hai-Ning.Liang@xjtlu.edu.cn', booking_count: '250' }
        ]
        return this.tableData;
      },
      getCurrentUserBookingSlots() {
        let id = this.getUserID();
        if (id === -1) return [];
  
        // 这里应该获取当前用户的预订时间槽
        // 返回示例数据
        return [
          { day: 0, hour: 9 },
          { day: 2, hour: 12 },
          { day: 4, hour: 15 }
        ]
      }
    },
    methods: {
      userInfoComplete() {
        return this.$store.state.userinfo.username != null && this.$store.state.userinfo.username != '' &&
        this.$store.state.userinfo.userid != null && this.$store.state.userinfo.userid != '' &&
        this.$store.state.userinfo.email != null && this.$store.state.userinfo.email != '' &&
        this.$store.state.userinfo.avatar_path != null && this.$store.state.userinfo.avatar_path != '' &&
        (this.$store.state.userinfo.role == 'ADMIN' || this.$store.state.userinfo.role == 'USER') ;
    },
      async fetchAllInfos(){
        // 获取用户列表
        await this.fetchUserList();
      },
      async fetchBookingDetail(bookingId) {
        try {
          const response = await axios.get(`/api/admin/bookings/${bookingId}`, { timeout: 5000 });
          
          if (response.data.code === 200) {
            const booking = response.data.data;
            return {
              id: booking.booking_id,
              room: booking.room_name,
              roomid: booking.room_id,
              subject: booking.subject || 'No Subject',
              start_time: formatDateTime(booking.start_time),
              end_time: formatDateTime(booking.end_time),
              status: booking.status,
              review_time: booking.review_time ? formatDateTime(booking.review_time) : '',
              admin_reply: booking.admin_reply || '',
              create_time: formatDateTime(booking.created_at),
              update_time: formatDateTime(booking.updated_at)
            };
          } else {
            console.error('获取预订详情失败:', response.data.message);
            return null;
          }
        } catch (error) {
          console.error('获取预订详情错误:', error);
          return null;
        }
      },
      async getBookingDetails() {
        const id = this.selectedBookID;
        if (id === -1 || id == null) {
          return {
            id: -1, 
            room: 'PLACEHOLDER', 
            roomid: -1,
            subject: 'PLACEHOLDER',
            start_time: 'PLACEHOLDER', 
            end_time: 'PLACEHOLDER', 
            status: 'pending',
            review_time: 'PLACEHOLDER', 
            admin_reply: 'PLACEHOLDER', 
            create_time: 'PLACEHOLDER', 
            update_time: 'PLACEHOLDER'
          };
        }
        
        const bookingDetail = await this.fetchBookingDetail(id);
        if (bookingDetail) {
          return bookingDetail;
        }
        
        return {
            id: -1, 
            room: 'PLACEHOLDER', 
            roomid: -1,
            subject: 'PLACEHOLDER',
            start_time: 'PLACEHOLDER', 
            end_time: 'PLACEHOLDER', 
            status: 'pending',
            review_time: 'PLACEHOLDER', 
            admin_reply: 'PLACEHOLDER', 
            create_time: 'PLACEHOLDER', 
            update_time: 'PLACEHOLDER'
          };
      },
      // 获取用户列表
      async fetchUserList() {
        try {
          const response = await axios.get('/api/admin/users/userlist', {timeout: 5000});
          
          if (response.data.code === 200) {
            // 转换后端数据格式为前端表格所需格式
            this.tableData = response.data.data.map(user => ({
              user_id: user.user_id,
              username: user.username,
              email: user.email,
              booking_count: user.meeting_count || '0' // 使用后端提供的预订数或默认为0
            }));
          } else {
            console.error('获取用户列表失败:', response.data.message);
          }
        } catch (error) {
          console.error('获取用户列表错误:', error);
        }
      },
      // 获取用户详情
      async fetchUserDetail(userId) {
        try {
          const response = await axios.get(`/api/admin/users/${userId}`, {timeout: 5000});
          
          if (response.data.code === 200) {
            const userData = response.data.data;

            return {
              user_id: userData.user_id,
              username: userData.username,
              email: userData.email,
              role: userData.role || 'USER',
              is_locked: userData.is_Locked,
              created_at: formatDateTime(userData.created_at),
              updated_at: formatDateTime(userData.updated_at),
              booking_history: Array.isArray(userData.booking_history) 
                ? userData.booking_history.map(booking => ({
                    booking_id: booking.booking_id,
                    room_name: booking.room_name || '',
                    start_time: formatDateTime(booking.start_time),
                    end_time: formatDateTime(booking.end_time),
                    status: booking.status || 'Pending'
                  }))
                : []
            };
          } else {
            console.error('获取用户详情失败:', response.data.message);
            return {
                user_id: '',
                username: '',
                email: '',
                role: '',
                is_locked: false,
                created_at: '',
                updated_at: '',
                booking_history: [{
                  booking_id: 1,
                  room_name: 'SD 512',
                  start_time: '2025-04-14T17:11:00.000+00.00',
                  end_time: '2025-04-14T17:11:00.000+00.00',
                  status: 'Approved',
                },
                {
                  booking_id: 2,
                  room_name: 'SD 512',
                  start_time: '2025-04-14T17:11:00.000+00.00',
                  end_time: '2025-04-14T17:11:00.000+00.00',
                  status: 'Approved',
                }]
              };
          }
        } catch (error) {
          console.error('获取用户详情错误:', error);
          return {
            user_id: '',
            username: '',
            email: '',
            role: '',
            is_locked: false,
            created_at: '',
            updated_at: '',
            booking_history: [{
              booking_id: 1,
              room_name: 'SD 512',
              start_time: '2025-04-14T17:11:00.000+00.00',
              end_time: '2025-04-14T17:11:00.000+00.00',
              status: 'Approved',
            },
            {
              booking_id: 1,
              room_name: 'SD 512',
              start_time: '2025-04-14T17:11:00.000+00.00',
              end_time: '2025-04-14T17:11:00.000+00.00',
              status: 'Approved',
            }]
          };
        }
      },
      async getCurrentUserDetails(){
        // 使用this.getUserID直接获取计算属性的值，而不是当作函数调用
        let id = this.getUserID;
        if (id === -1) {
          console.error('无效的用户ID');
          return {
            user_name: '', 
            email: '', 
            role: 'USER', 
            is_locked: false, 
            created_at: '',
            updated_at: '', 
            booking_history: []
          };
        }
        
        // 获取用户详情
        const userDetail = await this.fetchUserDetail(id);
        if (userDetail) {
          console.log('成功获取用户详情:', userDetail);
          return userDetail;
        }
        
        console.error('获取用户详情失败，使用基础数据');
        // 如果获取失败，使用表格中的基本数据
        return {
          user_id: this.selectedUser.user_id,
          username: this.selectedUser.username, 
          email: this.selectedUser.email,
          role: 'USER',
          is_locked: false,
          created_at: '',
          updated_at: '',
          booking_history: []
        };
      },
      async setDetailModal() {
        const currentUser = await this.getCurrentUserDetails();
        this.detailData.user_id = currentUser.user_id;
        this.detailData.username = currentUser.username;
        this.detailData.email = currentUser.email;
        this.detailData.role = currentUser.role;
        this.detailData.is_locked = currentUser.is_locked;
        this.detailData.created_at = currentUser.created_at;
        this.detailData.updated_at = currentUser.updated_at;
        this.detailData.booking_history = currentUser.booking_history;
      },
      // 获取当前登录用户信息
      async getUserInfo() {
        if (this.userInfoComplete()) {
          if (this.$store.state.userinfo.role == 'ADMIN') {
            await this.fetchAllInfos();
            this.pageLoaded = true;
          }
          else {
            this.$router.push('/rooms');
          }
          return;
        }
        try {
          const response = await axios.get('/api/user/me', {timeout: 5000});
          if (response.data.code === 200) {
            const userData = response.data.data;

            // 如果不是管理员，重定向到 Rooms 页面
            if (userData.role != 'ADMIN') {
              this.$router.push('/rooms');
              return;
            }

            await this.fetchAllInfos();

            // 更新Vuex中的用户信息
            this.$store.commit('userinfo/setUsername', userData.username);
            this.$store.commit('userinfo/setUserID', userData.user_id);
            this.$store.commit('userinfo/setRole', userData.role);
            this.$store.commit('userinfo/setLocked', userData.is_locked);
            if (userData.avatar_url)
              this.$store.commit('userinfo/setAvatarPath', userData.avatar_url);
            else
              this.$store.commit('userinfo/setAvatarPath', 'http://sulthbbxs.hd-bkt.clouddn.com/avatars/default.jpg');

            this.pageLoaded = true;
            
          }
          else {
            this.$router.push('/login');
          }
        } catch (error) {
          console.error('Failed to fetch user info:', error);
          if (error.response && error.response.status === 401) {
            // 如果未登录，重定向到登录页面
            this.$router.push('/login');
          }
        }
      },
      setAddModal() {
        this.addData.username = 'New User';
        this.addData.email = 'New.User@example.com';
        this.addData.role = 1;
        this.addData.password = 'password';
      },
      setAcceptModal() {
        this.acceptData.review = 'Your booking request has been approved.'
      },
      setRejectModal() {
        this.rejectData.review = 'Your booking request has been rejected.'
      },
      async setBookDetailModal() {
        try {
          const currentBooking = await this.getBookingDetails();

          this.bookingDetailData.booking_id = currentBooking.id;
          this.bookingDetailData.room = currentBooking.room;
          this.bookingDetailData.subject = currentBooking.subject; // 设置会议主题
          this.bookingDetailData.start_time = currentBooking.start_time;
          this.bookingDetailData.end_time = currentBooking.end_time;
          this.bookingDetailData.status = currentBooking.status.toLowerCase();
          this.bookingDetailData.review_time = currentBooking.review_time;
          this.bookingDetailData.admin_reply = currentBooking.admin_reply;
          this.bookingDetailData.create_time = currentBooking.create_time;
          this.bookingDetailData.update_time = currentBooking.update_time;
        } catch (error) {
          console.error('获取会议详情失败:', error);
          alert('Error: Failed to get meeting details');
        }
      },
      openAddModal() {
        this.showAddModal = true;
        this.setAddModal();
      },
      openDetailModal(row){
        this.selectedUser = row;
        this.showDetailModal = true;

        this.detailData.user_id = '';
        this.detailData.username = '';
        this.detailData.email = '';
        this.detailData.role = '';
        this.detailData.is_locked = false;
        this.detailData.created_at = '';
        this.detailData.updated_at = '';
        this.detailData.booking_history = [];

        this.setDetailModal();
      },
      openDeleteModal(row, rowIndex) {
        console.log("Delete room", row, rowIndex);
        this.selectedUser = row
        this.showDeleteModal = true;
      },
      openBookDetailModal({ item, index, renderers }) {
        console.log('Card clicked, index:', index, 'item:', item, 'renderers:', renderers);
        this.selectedBookID = item.booking_id;

        this.bookingDetailData.room        = '';
        this.bookingDetailData.subject     = '';
        this.bookingDetailData.start_time  = '';
        this.bookingDetailData.end_time    = '';
        this.bookingDetailData.status      = '';
        this.bookingDetailData.review_time = '';
        this.bookingDetailData.admin_reply = '';
        this.bookingDetailData.create_time = '';
        this.bookingDetailData.update_time = '';

        this.showBookingDetailModal = true;
        this.setBookDetailModal();
      },
      openAcceptModal() {
        this.showAcceptModal = true;
        this.setAcceptModal();
      },
      openRejectModal() {
        this.showRejectModal = true;
        this.setRejectModal();
      },
      closeBookingDetailModal() {
        this.showBookingDetailModal = false;
      },
      closeAddModal() {
        this.showAddModal = false;
      },
      closeDetailModal() {
        this.showDetailModal = false;
      },
      closeDeleteModal() {
        this.showDeleteModal = false;
      },
      closeAcceptModal() {
        this.showAcceptModal = false;
      },
      closeRejectModal() {
        this.showRejectModal = false;
      },
      async confirmAdd() {
        try {
          const userData = {
            userName: this.addData.username,
            email: this.addData.email,
            password: this.addData.password,
            role: this.addData.role === 1 ? 'ADMIN' : 'USER'
          };
          
          const response = await axios.post('/api/admin/users/addUser', userData, {timeout: 5000});
          
          if (response.data.code === 200) {
            console.log('用户添加成功!');
            alert('User added.');
            // 刷新用户列表
            this.fetchUserList();
            this.closeAddModal();
          } else {
            console.error('Adding user failed:', response.data.message);
            alert('用户添加失败: ' + response.data.message);
          }
        } catch (error) {
          console.error('用户添加错误:', error);
          alert('Adding user failed, please try again later.');
        }
      },
      async confirmDelete() {
        const id = this.getUserID;
        if (id === -1) return;
  
        try {
          const response = await axios.get('/api/admin/users/delete', {
            params: { userId: id },
            timeout: 5000
          });
          
          if (response.data.code === 200) {
            console.log('User deleted.');
            alert('User deleted.');

            this.fetchUserList();
          } else {
            console.error('User delete failed: ', response.data.message);
            alert('User delete failed: ' + response.data.message);
          }
        } catch (error) {
          console.error('User delete failed: ', error);
          alert('User delete failed， please try again later.');
        } finally {
          this.closeDeleteModal();
        }
      },

      async confirmLock() {
        try {
          const res = await axios.get('/api/admin/users/lock', {
            params: {userId: this.selectedUser.user_id},
            timeout: 5000
          });
          if (res.data.code === 200) {
            // 刷新用户列表
            this.closeDetailModal();
            this.fetchUserList();

            alert('User Locked.')
          }
          else {
            console.error('用户锁定失败:', res.data.message);
            alert('User lock failed.' + res.data.message);
          }
        } catch (error) {
          console.error('用户锁定错误:', error);
          alert('User lock error. Please try again later.', );
        }
      },

      async confirmUnlock() {
        try {
          const res = await axios.get('/api/admin/users/unlock', {
            params: {userId: this.selectedUser.user_id},
            timeout: 5000
          });
          if (res.data.code === 200) {
            // 刷新用户列表
            this.closeDetailModal();
            this.fetchUserList();

            alert('User Unlocked.')
          }
          else {
            console.error('用户解锁失败:', response.data.message);
            alert('User unlock failed: ' + response.data.message);
          }
        } catch (error) {
          console.error('用户解锁错误:', error);
          alert('User unlock error. Please try again later.', );
        }
      },
      async confirmAccept() {
        const id = this.selectedBookID;
        if (id === -1) return;
        
        try {
          const response = await axios.post(`/api/admin/bookings/${id}/approve`, null, {
            params: { adminReply: this.acceptData.review}, 
            timeout: 5000 
          });
          
          if (response.data.code === 200) {
            console.log('预订批准成功!');
            alert('Booking approved.');
          } else {
            console.error('预订批准失败:', response.data.message);
            alert('Booking approving failed: ' + response.data.message);
          }
        } catch (error) {
          console.error('预订批准错误:', error);
          alert('Booking approving failed, please try again later.');
        } finally {
          const id = this.getUserID;
          this.fetchUserDetail(id);

          this.closeAcceptModal();
          this.closeBookingDetailModal();
        }
      },
      
      async confirmReject() {
        const id = this.selectedBookID;
        if (id === -1) return;
        
        try {
          const response = await axios.post(`/api/admin/bookings/${id}/reject`, null, {
            params: { adminReply: this.rejectData.review}, 
            timeout: 5000
          });
          
          if (response.data.code === 200) {
            console.log('预订拒绝成功!');
            alert('Booking rejected.');

            this.closeRejectModal();
          } else {
            console.error('预订拒绝失败:', response.data.message);
            alert('Booking rejection failed: ' + response.data.message);
          }
        } catch (error) {
          console.error('预订拒绝错误:', error);
          alert('Booking rejection failed, please try again later.');
        } finally {
          const id = this.getUserID;
          this.fetchUserDetail(id);

          this.closeAcceptModal();
          this.closeBookingDetailModal();
        }
      },
      handleSearch(filters) {
        console.log(filters);
        let filterData = [
          {key: 'username', type: 'contains', value: filters.username},
          {key: 'email', type: 'contains', value: filters.email},
          {key: 'booking_count', type: 'between', min: filters.booking_count.min, max: filters.booking_count.max},
        ]
        this.$refs.table.filterData(filterData);
      },

      resetFilters() {
        this.$refs.table.clearFilters();
      },
    }
  };
  </script>
  
  <style scoped>
  h2 {
    font-family: 'Rethink Sans', sans-serif;
    font-size: 24px;
    color: #FFFFFF;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px solid #333333;
  }
  
  h4 {
    font-family: 'Rethink Sans', sans-serif;
    font-size: 18px;
    color: #DD2525;
    margin: 30px 0 10px;
  }
  
  .profile-page {
    background-color: #151517;
    min-height: 100vh;
    display: flex;
    align-items: flex-start;
  }
  
  .split-layout {
    display: flex;
    width: 100%;
  }
  
  .sidebar-container {
    width: 250px;
    flex-shrink: 0;
  }
  
  .central-section-wrapper {
    flex: 1;
    display: flex;
    justify-content: center;
    padding: 0 20px;
  }
  
  .central-section {
    width: 100%;
    max-width: 1200px;
    padding: 30px 40px;
    background-color: #151517;
  }
  
  .rooms-container {
    margin-bottom: 30px;
    background-color: transparent;
    border-radius: 8px;
    padding: 30px;
  }
  
  .action-buttons-container {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    align-items: center;
  }
  </style>
