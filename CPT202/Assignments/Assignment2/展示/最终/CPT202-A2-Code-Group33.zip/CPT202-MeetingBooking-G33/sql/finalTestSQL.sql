-- 如果数据库已存在，先删除（保证干净）
DROP DATABASE IF EXISTS meeting_booking;

-- 创建数据库
CREATE DATABASE meeting_booking DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用该数据库
USE meeting_booking;

-- 如果之前有表，确保干净删除（保险起见，一般 DROP DATABASE 就已经全清了）
-- 这里不需要额外 drop table

-- 创建 users 表
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'user',
    avatar_url VARCHAR(255),
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    is_locked TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 创建 buildings 表
CREATE TABLE buildings (
    building_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 创建 room_types 表
CREATE TABLE room_types (
    type_id INT PRIMARY KEY AUTO_INCREMENT,
    type_name VARCHAR(255) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL,
    capacity INT NOT NULL,
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 创建 rooms 表
CREATE TABLE rooms (
    room_id INT PRIMARY KEY AUTO_INCREMENT,
    room_name VARCHAR(100) NOT NULL,
    type_id INT NOT NULL,
    building_id INT NOT NULL,
    facilities JSON DEFAULT NULL,
    image_url VARCHAR(255) DEFAULT NULL,
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (type_id) REFERENCES room_types(type_id),
    FOREIGN KEY (building_id) REFERENCES buildings(building_id)
);

-- 创建 bookings 表
CREATE TABLE bookings (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    room_id INT NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    subject VARCHAR(50) NOT NULL,
    status VARCHAR(255) NOT NULL DEFAULT 'pending',
    reviewer_id INT DEFAULT NULL,
    review_time DATETIME DEFAULT NULL,
    admin_reply VARCHAR(255),
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (room_id) REFERENCES rooms(room_id),
    FOREIGN KEY (reviewer_id) REFERENCES users(user_id)
);

-- 创建 booking_participants 表
CREATE TABLE booking_participants (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT NOT NULL,
    user_id INT NOT NULL,
    is_attended TINYINT(1) NOT NULL DEFAULT 0,
    attended_at DATETIME DEFAULT NULL,
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    deleted_at DATETIME DEFAULT NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    UNIQUE KEY uq_booking_user (booking_id, user_id)
);

-- 创建 feedback 表
CREATE TABLE feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    reply TEXT DEFAULT NULL,
    create_time DATETIME NOT NULL,
    reply_time DATETIME DEFAULT NULL,
    status ENUM('pending', 'resolved') NOT NULL DEFAULT 'pending',
    admin_id INT DEFAULT NULL,
    resolved_notices TEXT DEFAULT NULL,

    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (admin_id) REFERENCES users(user_id)
);

-- ========================
-- 插入初始测试数据
-- ========================

-- 插入测试用户（密码都是加密后的 "12345678"）
INSERT INTO users (username, email, password, role, avatar_url, is_deleted, created_at, updated_at)
VALUES
    ('test', 'test@example.com', 'b5d78467840c9b1f7d5ec9199780379f', 'USER', '/avatars/default.jpg', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('test_admin', 'test_admin@example.com', 'b5d78467840c9b1f7d5ec9199780379f', 'ADMIN', '/avatars/default.jpg', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- 插入测试楼栋
INSERT INTO buildings (name)
VALUES ('Foundation Building');

-- 插入测试房间类型
INSERT INTO room_types (type_name, description, capacity)
VALUES ('Meeting Room', 'Meeting Room', 20);

-- 插入测试房间
INSERT INTO rooms (room_name, type_id, building_id, facilities, image_url)
VALUES ('FB114', 1, 1, JSON_ARRAY('Computer', 'White Board', 'Projector'), '/rooms/default.jpg');

-- 插入测试预订记录
INSERT INTO bookings (
    user_id,
    room_id,
    start_time,
    end_time,
    subject,
    status
) VALUES (
    1, -- 用户ID为1的用户
    1, -- 会议室ID为1
    '2025-04-14 10:00:00',
    '2025-04-14 12:00:00',
    '项目启动会议',
    'pending'
);
INSERT INTO bookings (
    user_id,
    room_id,
    start_time,
    end_time,
    subject,
    status
) VALUES (
    2, -- 用户ID为1的用户
    1, -- 会议室ID为1
    '2025-05-14 10:00:00',
    '2025-05-14 12:00:00',
    '项目启动会议2',
    'pending'
);

-- 插入预订参与者
INSERT INTO booking_participants (booking_id, user_id)
VALUES (1, 2);

-- 插入feedback
INSERT INTO feedback (user_id, content, reply, create_time, reply_time, status, admin_id, resolved_notices) VALUES
                                                                                                                (1, 'The projector in room A101 is not working.', 'The projector has been fixed.', '2025-04-10 09:15:00', '2025-04-10 11:00:00', 'resolved', 2, 'Projector replaced on 2025-04-10.'),
                                                                                                                (1, 'The air conditioner in lab B is too cold.', 'Temperature adjusted.', '2025-04-11 10:20:00', '2025-04-11 13:30:00', 'resolved', 2, 'Set to 24°C as requested.'),
                                                                                                                (2, 'Broken chairs in classroom C204.', 'Maintenance has replaced broken chairs.', '2025-04-12 14:00:00', '2025-04-13 08:30:00', 'resolved', 2, 'Furniture maintenance scheduled weekly.'),
                                                                                                                (2, 'Printer in the library doesn''t print.', 'Printer fixed and refilled.', '2025-04-13 16:45:00', '2025-04-14 09:20:00', 'resolved', 2, 'Printer toner was empty. Now refilled.'),
                                                                                                                (2, 'The elevator is making strange noise.', 'Elevator checked and repaired.', '2025-04-14 10:00:00', '2025-04-14 15:00:00', 'resolved', 2, 'Routine inspection done. Safe to use.');

INSERT INTO feedback (user_id, content, create_time, status) VALUES
                                                                 (1, 'The lights in the main hallway flicker.', '2025-04-15 09:10:00', 'pending'),
                                                                 (1, 'Trash bins are full in Room 108.', '2025-04-15 10:30:00', 'pending'),
                                                                 (2, 'WiFi is unstable on the 3rd floor.', '2025-04-15 11:20:00', 'pending'),
                                                                 (2, 'Air smells musty in basement lab.', '2025-04-15 13:00:00', 'pending'),
                                                                 (2, 'The clock in Lecture Hall 2 is broken.', '2025-04-15 14:15:00', 'pending');
