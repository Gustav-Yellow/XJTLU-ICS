package com.cpt202g33.meetingbooking.aop;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.model.enums.UsersRoleEnum;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.service.UsersService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Aspect
@Component
public class AuthInterceptor {

    @Resource
    private UsersService userService;

    /**
     * 执行拦截
     *
     * @param joinPoint 切入点
     * @param authCheck 权限校验注解
     */
    @Around("@annotation(authCheck)")
    public Object doInterceptor(ProceedingJoinPoint joinPoint, AuthCheck authCheck) throws Throwable {
        String mustRole = authCheck.mustRole();
        RequestAttributes requestAttributes = RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = ((ServletRequestAttributes) requestAttributes).getRequest();
        // 获取当前登录用户
        Users loginUser = userService.getLoginUser(request);
        UsersRoleEnum mustRoleEnum = UsersRoleEnum.getEnumByValue(mustRole);
        // 如果不需要权限，放行
        if (mustRoleEnum == null) {
            return joinPoint.proceed();
        }
        // 以下的代码：必须有权限，才会通过
        UsersRoleEnum usersRoleEnum = UsersRoleEnum.getEnumByValue(loginUser.getRole());
        if (usersRoleEnum == null) {
            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
        }
        
        // 管理员可以访问任何接口，直接放行
        if (UsersRoleEnum.ADMIN.equals(usersRoleEnum)) {
            return joinPoint.proceed();
        }
        
        // 要求管理员权限，但用户不是管理员，拒绝
        if (UsersRoleEnum.ADMIN.equals(mustRoleEnum)) {
            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
        }
        
        // 普通用户访问用户权限接口，放行
        if (UsersRoleEnum.USER.equals(mustRoleEnum) && UsersRoleEnum.USER.equals(usersRoleEnum)) {
            return joinPoint.proceed();
        }
        
        // 其他情况拒绝访问
        throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
    }
}
