package com.cpt202g33.meetingbooking.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class EmailSender {

    @Value("${spring.mail.username}")
    private String sendFrom;

    @Value("${spring.mail.password}")
    private String password;

    @Value("${spring.mail.host}")
    private String host;

    @Value("${spring.mail.port}")
    private int port;

    @Value("${spring.mail.protocol}")
    private String protocol;

    @Value("${spring.mail.properties.mail.smtp.auth}")
    private String auth;

    @Value("${spring.mail.properties.mail.smtp.ssl.enable}")
    private String sslEnable;

    /**
     * 发送纯文本信息给指定的邮箱
     * @param to 收件人邮箱
     * @param title 标题
     * @param content 内容
     */
    public void sendSimpleMail(String to, String title, String content) {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

        // 配置邮件服务器
        mailSender.setHost(host);
        mailSender.setPort(port);
        mailSender.setUsername(sendFrom);
        mailSender.setPassword(password);

        // 设置JavaMail的相关属性
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", auth);
        properties.put("mail.smtp.ssl.enable", sslEnable);  // 启用 SSL 加密
        mailSender.setJavaMailProperties(properties);

        // 创建邮件
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(sendFrom); // 发件人
        message.setTo(to);
        message.setSubject(title);
        message.setText(content);

        // 发送邮件
        mailSender.send(message);
    }

}
