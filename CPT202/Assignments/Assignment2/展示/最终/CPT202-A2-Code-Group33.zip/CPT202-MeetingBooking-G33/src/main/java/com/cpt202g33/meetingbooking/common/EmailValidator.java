package com.cpt202g33.meetingbooking.common;

import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

// 用来校验邮件格式的合法性
@Component
public class EmailValidator {

    // 正则表达式：符合 RFC 5322 标准的邮箱格式
    private static final String EMAIL_REGEX =
            "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@([A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\\.)+[A-Za-z]{2,}$";

    // 编译正则表达式（提升性能）
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile(EMAIL_REGEX);

     /**
     * * 校验邮箱格式是否合法
     * @param email 待校验的邮箱地址
     * @return true=合法，false=非法
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email).matches();
    }
}