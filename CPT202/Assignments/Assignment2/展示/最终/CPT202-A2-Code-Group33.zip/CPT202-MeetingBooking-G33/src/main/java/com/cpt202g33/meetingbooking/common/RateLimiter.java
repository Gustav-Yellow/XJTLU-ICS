package com.cpt202g33.meetingbooking.common;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

// 控制验证码请求的校验器，确保每个用户每分钟只能请求一次验证码
@Component
public class RateLimiter {

    // 缓存：key=用户标识（IP或邮箱），value=最后一次请求时间戳
    // 记录用户请求验证码的时间，用来做对比
    private final Cache<String, Long> requestCache = Caffeine.newBuilder()
            .expireAfterWrite(1, TimeUnit.MINUTES) // 1分钟后自动清理
            .maximumSize(10_000)
            .build();

    /**
     * 判断是否允许请求
     * @param key 这里是通过获取到的 ip 地址来当做请求校验的键
     * @return
     */
    public boolean allowRequest(String key) {
        // 看本地缓存中是否存在当前给定 ip 的一分钟以内的请求记录
        Long lastRequestTime = requestCache.getIfPresent(key);
        // 获取当前的时间
        long currentTime = System.currentTimeMillis();

        // 如果没有找到请求记录，或者记录的时间大于一分钟，则向缓存中添加一个验证码记录记录，然后允许请求验证码
        if (lastRequestTime == null || currentTime - lastRequestTime >= 60_000) {
            requestCache.put(key, currentTime); // 更新最后一次请求时间
            return true;
        }
        return false;
    }


}
