package com.cpt202g33.meetingbooking.common;

import com.cpt202g33.meetingbooking.exception.ErrorCode;

/**
 * 响应工具类
 */
public class ResultUtils {

    /**
     * 成功
     *
     * @param data 数据
     * @param <T>  数据类型
     * @return 响应
     */
    public static <T> BaseResponse<T> success(T data) {
        return new BaseResponse<>(200, data, "ok");
    }

    /**
     * 失败
     *
     * @param errorCode 错误码
     * @return 响应
     */
    public static BaseResponse<?> error(ErrorCode errorCode) {
        return new BaseResponse<>(errorCode);
    }

    /**
     * 失败
     *
     * @param code    错误码
     * @param message 错误信息
     * @return 响应
     */
    public static BaseResponse<?> error(int code, String message) {
        return new BaseResponse<>(code, null, message);
    }

    /**
     * 返回带data的错误信息
     * @param errorCode 错误码
     * @param data 错误操作之后数据库返回的查询结果
     * @param message 错误信息
     * @return BaseResponse
     * @param <T> 泛型
     */
    public static <T> BaseResponse<T> error(ErrorCode errorCode, T data, String message) {
        return new BaseResponse<>(errorCode.getCode(), data, message);
    };

    /**
     * 失败
     *
     * @param errorCode 错误码
     * @return 响应
     */
    public static BaseResponse<?> error(ErrorCode errorCode, String message) {
        return new BaseResponse<>(errorCode.getCode(), null, message);
    }
}
