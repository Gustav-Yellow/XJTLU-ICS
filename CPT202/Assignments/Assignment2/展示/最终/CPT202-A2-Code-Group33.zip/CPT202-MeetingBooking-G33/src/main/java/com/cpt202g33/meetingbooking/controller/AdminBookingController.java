package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.model.dto.BookingModifyRequest;
import com.cpt202g33.meetingbooking.model.dto.BookingApplicationRequest;
import com.cpt202g33.meetingbooking.model.dto.BookingQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.BookingDetailVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListWithNameVO;
import com.cpt202g33.meetingbooking.service.BookingService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/admin/bookings")
public class AdminBookingController {
    @Resource
    private BookingService bookingService;

    /**
     * 管理员获取所有预订记录（支持状态筛选和排序）
     *
     * @param status 状态筛选（可选：all, pending, approved, rejected）
     * @return 所有符合条件的预订记录
     */
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @PostMapping("/list")
    public BaseResponse<List<BookingListWithNameVO>> getAllBookingList(
            @RequestParam(value = "status", required = false, defaultValue = "all") String status) {
        List<BookingListWithNameVO> bookingListWithName = bookingService.getAllBookingList(status);

        return ResultUtils.success(bookingListWithName);
    }
    
    /**
     * 管理员获取预订记录，支持多条件筛选
     *
     * @param queryRequest 筛选条件，包括用户、时间、房间和状态等
     * @return 符合筛选条件的预订记录列表
     */
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @PostMapping("/query")
    public BaseResponse<List<BookingListWithNameVO>> queryBookings(@RequestBody BookingQueryRequest queryRequest) {
        List<BookingListWithNameVO> bookingList = bookingService.queryBookings(queryRequest);
        return ResultUtils.success(bookingList);
    }

    /**
     * 管理员根据预定ID查看单条预定详情
     *
     * @param bookingId 预约记录的ID
     * @return 对应ID的详细预约内容
     */
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @GetMapping("/{bookingId}")
    public BaseResponse<BookingListWithNameVO> getBookingWithNameByBookingID(
            @PathVariable Integer bookingId) {
        BookingListWithNameVO bookingListWithName = bookingService.getBookingWithNameByBookingID(bookingId);

        return ResultUtils.success(bookingListWithName);
    }

    /**
     * 管理员批准某预定ID的申请
     *
     * @param bookingId 预约申请的ID
     * @param adminReply 管理员的审批回复，可选填
     * @return 200或6001
     */
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @PostMapping("/{bookingId}/approve")
    public BaseResponse<?> approveBooking(
            @PathVariable Integer bookingId,
            @RequestParam(value = "adminReply",required = false, defaultValue = "") String adminReply,
            HttpServletRequest request) {

        // 从会话中获取登录用户信息
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        Integer adminId = loginUser.getUser_id();
        LocalDateTime approveTime = LocalDateTime.now();
        // 执行
        Boolean result = bookingService.approveBooking(bookingId, adminReply, adminId, approveTime);

        if (!result) return ResultUtils.error(6001, "Access denied");
        return ResultUtils.success(result);
    }

    /**
     * 管理员拒绝某预定ID的申请
     *
     * @param bookingId 预约申请的ID
     * @param adminReply 管理员的拒绝原因，必填
     * @return 200或6001
     */
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @PostMapping("/{bookingId}/reject")
    public BaseResponse<?> rejectBooking(
            @PathVariable Integer bookingId,
            @RequestParam(value = "adminReply", defaultValue = "") String adminReply,
            HttpServletRequest request) {

        // 从会话中获取登录用户信息
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        Integer adminId = loginUser.getUser_id();
        LocalDateTime approveTime = LocalDateTime.now();
        // 执行
        Boolean result = bookingService.rejectBooking(bookingId, adminReply, adminId, approveTime);
        if (!result) return ResultUtils.error(6001, "Access denied");
        return ResultUtils.success(result);
    }
}
