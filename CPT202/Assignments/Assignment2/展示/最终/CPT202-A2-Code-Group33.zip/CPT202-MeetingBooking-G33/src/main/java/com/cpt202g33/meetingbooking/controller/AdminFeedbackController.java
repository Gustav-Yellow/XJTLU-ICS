package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.cpt202g33.meetingbooking.model.dto.FeedbackReplyRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.FeedbackListVO;
import com.cpt202g33.meetingbooking.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping("admin/feedback")
public class AdminFeedbackController {
    @Autowired
    private FeedbackService feedbackService;


    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @GetMapping("/allResolved")
    public BaseResponse<List<FeedbackListVO>> getAllResolvedFeedbacks() {
        List<FeedbackListVO> feedbackList = feedbackService.adminListAllResolvedFeedbacks();
        return ResultUtils.success(feedbackList);
    }

    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @GetMapping("/allPending")
    public BaseResponse<List<FeedbackListVO>> getAllPendingFeedbacks() {
        List<FeedbackListVO> feedbackList = feedbackService.adminListAllPendingFeedbacks();
        return ResultUtils.success(feedbackList);
    }


    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @PostMapping("/{feedbackId}/reply")
    public BaseResponse<Boolean> replyFeedback(@PathVariable("feedbackId") Integer feedbackId,
                                               @RequestBody FeedbackReplyRequest feedbackReplyRequest,
                                               HttpServletRequest request) {


        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        Integer user_id = loginUser.getUser_id();

        ThrowUtils.throwIf(feedbackId == null || feedbackReplyRequest.getReply() == null || user_id == null,
                ErrorCode.PARAMS_ERROR, "Bad request");


        boolean result = feedbackService.replyFeedback(feedbackId, feedbackReplyRequest,user_id);
        if (!result) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Wrong operation, please try again");
        }

        return ResultUtils.success(result);
    }



}
