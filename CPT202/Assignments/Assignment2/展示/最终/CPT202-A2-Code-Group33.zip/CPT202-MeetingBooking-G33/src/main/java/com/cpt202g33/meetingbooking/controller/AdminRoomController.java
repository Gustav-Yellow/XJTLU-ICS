package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.alibaba.fastjson.JSON;
import javax.servlet.http.HttpServletRequest;

import com.cpt202g33.meetingbooking.model.dto.RoomRequest;
import com.cpt202g33.meetingbooking.service.QiniuService;
import com.cpt202g33.meetingbooking.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/admin/rooms")
public class AdminRoomController {

    @Autowired
    private RoomService roomService;

    @Autowired
    private QiniuService qiniuService;
    /**
     * 更新会议室信息接口，只有管理员才能访问。
     * @param roomId               需要更新的会议室ID
     * @param roomRequest    包含更新数据的请求对象
     * @param request              HTTP请求对象，提供请求上下文
     * @return BaseResponse<Boolean> 更新操作的结果，返回成功或失败状态
     * @throws BusinessException  如果更新失败，则抛出此异常，包含失败信息
     */
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)  // 鉴权，只有管理员能访问
    @PostMapping("/{roomId}/edit")
    public BaseResponse<Boolean> updateRoom(
            @PathVariable("roomId") Integer roomId,
            @RequestBody RoomRequest roomRequest,
            HttpServletRequest request) {
        ThrowUtils.throwIf(roomRequest == null, ErrorCode.PARAMS_ERROR);
        ThrowUtils.throwIf(roomId == null, ErrorCode.PARAMS_ERROR);
        boolean result = roomService.updateRoomInfo(roomId, roomRequest);
        if (!result) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Modification failed.");
        }
        return ResultUtils.success(null);
    }


    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)  // 鉴权，只有管理员能访问
    @PostMapping("/add")
    public BaseResponse<Boolean> createRoom(@ModelAttribute RoomRequest roomRequest,
                                            @RequestParam(required = false) MultipartFile roomImage) {
        // 调用房间服务进行房间创建，并处理文件上传
        boolean result = roomService.createRoom(roomRequest, roomImage);

        if (!result) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Modification failed.");
        }

        return ResultUtils.success(true);
    }

    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)  // 鉴权，只有管理员能访问
    @GetMapping("/delete/{roomId}")
    public BaseResponse<Boolean> deleteRoom(@PathVariable("roomId") Integer roomId) {

        // 调用房间服务进行房间删除
        boolean result = roomService.deleteRoom(roomId);

        if (!result) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Failed to delete room.");
        }

        return ResultUtils.success(true);
    }




    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @PostMapping(value = "/{roomId}/changeImage", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public BaseResponse<Boolean> updateRoomImage(@PathVariable("roomId") Integer roomId,
                                                 @RequestPart("image") MultipartFile imageFile) {

        // 参数校验
        ThrowUtils.throwIf(roomId == null || imageFile == null || imageFile.isEmpty(),
                ErrorCode.PARAMS_ERROR, "roomId 或 image 文件为空");

        // 上传新图片并获取 URL
        String url = qiniuService.uploadRoomImage(imageFile, roomId);

        // 更新数据库中的 image_url 字段
        boolean result = roomService.changeRoomImage(roomId, url);

        return ResultUtils.success(result);
    }







}
