package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.cpt202g33.meetingbooking.model.dto.AdminUserAddUserRequest;
import com.cpt202g33.meetingbooking.model.dto.AdminUserGetListRequest;
import com.cpt202g33.meetingbooking.model.vo.user.UserBookingVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import com.cpt202g33.meetingbooking.service.impl.AdminUserServiceImpl;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/admin/users")
public class AdminUserController {
    @Resource
    AdminUserServiceImpl adminUserService;

    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @GetMapping("/userlist")
    public BaseResponse<List<UserVO>> getUsersList() {
        return ResultUtils.success(adminUserService.getUserLists());
    }


    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @GetMapping("/{userId}")
    public BaseResponse<UserBookingVO> getUserInfo(@PathVariable Integer userId) {
        ThrowUtils.throwIf(userId == null, ErrorCode.PARAMS_ERROR);
        UserBookingVO userBookingVO = adminUserService.getUser(userId);
        return ResultUtils.success(userBookingVO);
    }

    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @GetMapping("/lock")
    public BaseResponse<?> lockUser(Integer userId) {
        ThrowUtils.throwIf(userId == null, ErrorCode.PARAMS_ERROR);
        adminUserService.lockUser(userId);
        return ResultUtils.success(null);
    }

    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @GetMapping("/unlock")
    public BaseResponse<?> unlockUser(Integer userId) {
        ThrowUtils.throwIf(userId == null, ErrorCode.PARAMS_ERROR);
        adminUserService.unlockUser(userId);
        return ResultUtils.success(null);
    }

    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @GetMapping("/delete")
    public BaseResponse<?> deleteUser(Integer userId) {
        ThrowUtils.throwIf(userId == null, ErrorCode.PARAMS_ERROR);
        adminUserService.deleteUser(userId);
        return ResultUtils.success(null);
    }

    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @PostMapping("/addUser")
    public BaseResponse<?> addUser(@RequestBody AdminUserAddUserRequest addUserRequest) {
        ThrowUtils.throwIf(addUserRequest == null, ErrorCode.PARAMS_ERROR);
        adminUserService.addUser(addUserRequest);
        return ResultUtils.success(null);
    }
}
