package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.model.dto.BookingModifyRequest;
import com.cpt202g33.meetingbooking.model.dto.BookingApplicationRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.BookingDetailVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListWithNameVO;
import com.cpt202g33.meetingbooking.service.BookingService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 预订控制器
 */
@RestController
@RequestMapping("/bookings")
public class BookingController {
    
    @Resource
    private BookingService bookingService;
    
    /**
     * 获取当前用户的未来预订记录
     * 只返回当前时间之后的预订
     */
    @AuthCheck(mustRole = UserConstant.DEFAULT_ROLE)
    @GetMapping("/list")
    public BaseResponse<List<BookingListVO>> listBookings(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        Integer user_id = loginUser.getUser_id();
        List<BookingListVO> bookingList = bookingService.getFutureBookingsByUserId(user_id);
        return ResultUtils.success(bookingList);
    }

    /**
     * 获取当前用户的历史预订记录
     * 只返回当前时间之前的预订
     */
    @AuthCheck(mustRole = UserConstant.DEFAULT_ROLE)
    @GetMapping("/history")
    public BaseResponse<List<BookingListVO>> historyBookings(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        Integer user_id = loginUser.getUser_id();
        List<BookingListVO> bookingList = bookingService.getHistoryBookingsByUserId(user_id);
        return ResultUtils.success(bookingList);
    }

    /**
     * 取消预订
     * 普通用户只能取消自己的预订，管理员可以取消任何人的预订
     *
     * @param booking_id 预订ID
     * @param request HTTP请求
     * @return 操作结果
     */
    @AuthCheck(mustRole = UserConstant.DEFAULT_ROLE)
    @GetMapping("/{booking_id}/cancel")
    public BaseResponse<Void> cancelBooking(@PathVariable Integer booking_id, HttpServletRequest request) {
        // 从会话中获取登录用户信息
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        Integer user_id = loginUser.getUser_id();
        String role = loginUser.getRole(); // 获取用户角色
        
        // 执行取消预订操作，传入用户角色信息
        boolean result = bookingService.cancelBooking(booking_id, user_id, role);
        
        if (!result) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Fail to cancel the booking");
        }
        
        return ResultUtils.success(null);
    }
    
    /**
     * 获取会议详情
     * - 管理员可以查看所有会议详情
     * - 普通用户只能查看自己创建的会议详情
     *
     * @param booking_id 会议ID
     * @param request HTTP请求
     * @return 会议详情
     */
    @AuthCheck(mustRole = UserConstant.DEFAULT_ROLE)
    @GetMapping("/{booking_id}")
    public BaseResponse<BookingDetailVO> getBookingDetail(@PathVariable("booking_id") Integer booking_id, 
                                                   HttpServletRequest request) {
        // 从会话中获取登录用户信息
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }

        Integer userId = loginUser.getUser_id();
        String role = loginUser.getRole();
        
        // 获取会议详情，传入用户ID和角色进行权限控制
        BookingDetailVO bookingDetailVO = bookingService.getBookingById(booking_id, userId, role);
        
        return ResultUtils.success(bookingDetailVO);
    }
    
    /**
     * 修改预定时间和地点
     * - 管理员可以修改所有预定
     * - 普通用户只能修改自己创建的预定
     * - 修改后状态会重置为待审核（对于普通用户）
     *
     * @param booking_id 预定ID
     * @param modifyRequest 修改请求
     * @param request HTTP请求
     * @return 操作结果
     */
    @AuthCheck(mustRole = UserConstant.DEFAULT_ROLE)
    @PostMapping("/{booking_id}/modify")
    public BaseResponse<Boolean> modifyBooking(
            @PathVariable("booking_id") Integer booking_id,
            @RequestBody BookingModifyRequest modifyRequest,
            HttpServletRequest request) {
        
        // 从会话中获取登录用户信息
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        
        Integer userId = loginUser.getUser_id();
        String role = loginUser.getRole();
        if(loginUser.getIs_locked() == 1){
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR,"You have been locked, please contact the administrator.");
        }

        // 执行修改预定操作
        boolean result = bookingService.modifyBooking(booking_id, modifyRequest, userId, role);
        
        return ResultUtils.success(result);
    }

    /**
     * 会议申请接口
     * @param applicationRequest 申请参数
     * @param request HTTP请求
     * @return 操作结果
     */
    @AuthCheck(mustRole = UserConstant.DEFAULT_ROLE)
    @PostMapping("/application")
    public BaseResponse<Boolean> applyBooking(@RequestBody BookingApplicationRequest applicationRequest, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        Integer userId = loginUser.getUser_id();
        String role = loginUser.getRole();
        if(loginUser.getIs_locked() == 1){
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR,"You have been locked, please contact the administrator.");
        }
        boolean result = bookingService.applyBooking(applicationRequest, userId, role);
        return ResultUtils.success(result);
    }
}
