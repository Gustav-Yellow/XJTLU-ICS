package com.cpt202g33.meetingbooking.controller;


import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.cpt202g33.meetingbooking.model.dto.FeedbackCreateRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.FeedbackDetailVO;
import com.cpt202g33.meetingbooking.model.vo.FeedbackListVO;
import com.cpt202g33.meetingbooking.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping("/feedback")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    @AuthCheck(mustRole = UserConstant.DEFAULT_ROLE)
    @PostMapping("/add")
    public BaseResponse<Boolean> addFeedback(@RequestBody FeedbackCreateRequest feedbackCreateRequest,
                                             HttpServletRequest request) {
        ThrowUtils.throwIf(feedbackCreateRequest == null, ErrorCode.PARAMS_ERROR);
        ThrowUtils.throwIf(feedbackCreateRequest.getContent() == null, ErrorCode.PARAMS_ERROR);
        HttpSession session = request.getSession();

        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        Integer user_id = loginUser.getUser_id();

        boolean saveResult = feedbackService.save(feedbackCreateRequest, user_id);
        if (!saveResult) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        return ResultUtils.success(saveResult);
    }



    @AuthCheck(mustRole = UserConstant.DEFAULT_ROLE)
    @GetMapping("/allResolved")
    public BaseResponse<List<FeedbackListVO>> getAllResolvedFeedbacks(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        Integer user_id = loginUser.getUser_id();

        List<FeedbackListVO> feedbackList = feedbackService.listAllResolvedFeedbacks(user_id);
        return ResultUtils.success(feedbackList);
    }


    @AuthCheck(mustRole = UserConstant.DEFAULT_ROLE)
    @GetMapping("/allPending")
    public BaseResponse<List<FeedbackListVO>> getAllPendingFeedbacks(HttpServletRequest request) {
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        Integer user_id = loginUser.getUser_id();

        List<FeedbackListVO> feedbackList = feedbackService.listAllPendingFeedbacks(user_id);
        return ResultUtils.success(feedbackList);
    }


    @GetMapping("/{feedbackId}")
    public BaseResponse<FeedbackDetailVO> getFeedbackById(@PathVariable("feedbackId") Integer feedbackId,
                                                          HttpServletRequest request) {
        // 鉴权（示例）- 如果你有登录检查逻辑
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }

        FeedbackDetailVO feedbackDetail = feedbackService.getFeedbackDetailById(feedbackId);
        return ResultUtils.success(feedbackDetail);
    }



}
