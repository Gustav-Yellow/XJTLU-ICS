package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.PictureVO;
import com.cpt202g33.meetingbooking.service.QiniuService;
import com.cpt202g33.meetingbooking.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.Objects;

@RestController
@RequestMapping("/qiniu")
public class QiniuTestController {

    @Autowired
    private QiniuService qiniuService;

    @Resource
    private UsersService usersService;

    @Resource
    private UsersMapper usersMapper;

    // @Value("${qiniu.admin}")
    private String url_domain = "http://sulthbbxs.hd-bkt.clouddn.com";

    // 上传和更新图片
    @PostMapping("/upload-avatar")
    public BaseResponse<PictureVO> uploadAvatar(@RequestParam("file") MultipartFile file,
                                                @RequestParam("user_id") Integer user_id,
                                                HttpServletRequest request) {
        // 判断当前用户是否登录
        Users loginUser = usersService.getLoginUser(request);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR, "Please login first");
        }

        // 判断当前请求中的 user_id 是否和登录的用户相同
        if (!Objects.equals(loginUser.getUser_id(), user_id)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Wrong user id");
        }

        try {
            String url = qiniuService.uploadUserAvatar(file, user_id);
            PictureVO pictureUploadVO = new PictureVO();
            pictureUploadVO.setAvatar_url(url);
            return ResultUtils.success(pictureUploadVO);
        } catch (BusinessException e) {
            // 如果存在错误，则直接把默认头像赋值给用户的avatar_url
            PictureVO pictureUploadVO = new PictureVO();
            pictureUploadVO.setAvatar_url(url_domain + "/avatars/default.jpg");
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, pictureUploadVO, "BusinessException + 图片上传失败");
        } catch (Exception e) {
            e.printStackTrace();
            // 如果存在错误，则直接把默认头像赋值给avatar_url
            PictureVO pictureUploadVO = new PictureVO();
            pictureUploadVO.setAvatar_url(url_domain + "/avatars/default.jpg");
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, pictureUploadVO, "图片上传失败");
        }
    }

    /**
     * 删除用户头像
     * @param avatarUrl
     * @return
     */
    @PostMapping("/delete-avatar")
    public BaseResponse<String> deleteAvatar(@RequestParam("avatarUrl") String avatarUrl, HttpServletRequest request) {
        ThrowUtils.throwIf(request == null, ErrorCode.PARAMS_ERROR);

        Users loginUser = usersService.getLoginUser(request);

        // 如果不是管理员则不允许删除图片
        if (!Objects.equals(loginUser.getRole(), "admin")) {
            throw new BusinessException(ErrorCode.FORBIDDEN_ERROR, "You don not have right to delete picture.");
        }

        // 判断传回来的链接是否为空，以及路径中有没有包含 avatars/
        if (avatarUrl == null || !avatarUrl.contains("avatars/")) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "图像链接错误");
        }

        // 提取 key，例如从 http://xxx/avatars/xxx.jpg 提取出 avatars/xxx.jpg
        String key = avatarUrl.substring(avatarUrl.indexOf("avatars/"));
        boolean success = qiniuService.deleteAvatar(key);

        // 如果图片删除成功，则需要将数据库中用户图片的内容更改为默认图片
        if (success) {
            // 将头像更新为默认头像
            usersMapper.updateAvatarUrl(loginUser.getUser_id(), "/avatars/default.jpg");
            return ResultUtils.success("Success");
        } else {
            // 删除失败
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "Fail to delete the picture");
        }
    }

}
