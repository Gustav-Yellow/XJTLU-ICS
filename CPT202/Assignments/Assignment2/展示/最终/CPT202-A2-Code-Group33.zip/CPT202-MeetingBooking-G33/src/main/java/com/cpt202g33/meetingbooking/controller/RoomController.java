package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.cpt202g33.meetingbooking.model.dto.RoomQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.Building;
import com.cpt202g33.meetingbooking.model.entity.Room;
import com.cpt202g33.meetingbooking.model.entity.RoomType;
import com.cpt202g33.meetingbooking.model.vo.*;
import com.cpt202g33.meetingbooking.service.RoomService;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 会议室控制器
 */
@RestController
@RequestMapping("/rooms")
public class RoomController {
    
    @Resource
    private RoomService roomService;
    
    /**
     * 获取所有会议室列表
     * @return 会议室列表
     */
    @GetMapping("/list")
    public BaseResponse<List<RoomVO>> listRooms() {
        List<RoomVO> roomList = roomService.listAllRooms();
        return ResultUtils.success(roomList);
    }

    /**
     * 查询筛选过后的房间结果
     * @param roomQueryRequest
     * @return
     */
    @PostMapping("/query-list")
    public BaseResponse<List<RoomQueryResponse>> queryListRooms(@RequestBody RoomQueryRequest roomQueryRequest) {
        List<RoomQueryResponse> queryRoomList;
        // 查询条件为空，默认返回所有的房间信息

        queryRoomList = roomService.queryListRooms(roomQueryRequest);
        return ResultUtils.success(queryRoomList);
    }
    
    /**
     * 获取会议室详情，包括最近的会议记录
     * @param room_id 会议室ID
     * @return 会议室详情
     */
    @GetMapping("/{room_id}")
    public BaseResponse<RoomDetailVO> getRoomDetail(@PathVariable("room_id") Integer room_id) {
        RoomDetailVO detailedRoomVO = roomService.getRoomDetail(room_id);
        return ResultUtils.success(detailedRoomVO);
    }
    
    /**
     * 获取所有房间类型
     * @return 房间类型列表
     */
    @GetMapping("/types")
    public BaseResponse<List<RoomTypeVO>> listRoomTypes() {
        List<RoomType> roomTypes = roomService.listAllRoomTypes();
        // 将实体转为视图对象
        List<RoomTypeVO> roomTypeVOs = roomTypes.stream().map(type -> {
            RoomTypeVO vo = new RoomTypeVO();
            // 映射ID和名称为前端需要的格式
            vo.setId(type.getType_id());
            vo.setLabel(type.getType_name());
            vo.setDescription(type.getDescription());
            vo.setCapacity(type.getCapacity());
            return vo;
        }).collect(Collectors.toList());
        return ResultUtils.success(roomTypeVOs);
    }
    
    /**
     * 获取所有建筑物
     * @return 建筑物列表
     */
    @GetMapping("/buildings")
    public BaseResponse<List<BuildingVO>> listBuildings() {
        List<Building> buildings = roomService.listAllBuildings();
        // 将实体转为视图对象
        List<BuildingVO> buildingVOs = buildings.stream().map(building -> {
            BuildingVO vo = new BuildingVO();
            // 映射ID和名称为前端需要的格式
            vo.setId(building.getBuilding_id());
            vo.setLabel(building.getName());
            return vo;
        }).collect(Collectors.toList());
        return ResultUtils.success(buildingVOs);
    }

}