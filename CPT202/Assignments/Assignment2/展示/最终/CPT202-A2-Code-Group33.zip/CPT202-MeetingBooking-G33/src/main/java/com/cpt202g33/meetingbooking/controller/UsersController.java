package com.cpt202g33.meetingbooking.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.EmailValidator;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.config.QiniuConfig;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.dto.user.*;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.PictureVO;
import com.cpt202g33.meetingbooking.model.vo.user.LoginUserVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import com.cpt202g33.meetingbooking.service.QiniuService;
import com.cpt202g33.meetingbooking.service.UsersService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

// Spring 会通过 @ResponseBody 或 @RestController 自动触发 JSON 转换
// 启动项目之后在浏览器打开 http://localhost:8080/api/doc.html#/home，可以直接查看当前项目中所有的接口，比 postman 要好用
@RestController
@RequestMapping("/user")
public class UsersController {

    @Resource
    UsersService usersService;

    @Resource
    QiniuService qiniuService;
    @Autowired
    private QiniuConfig qiniuConfig;
    @Resource
    UsersMapper usersMapper;

    /**
     * 用户注册
     * @param userRegisterRequest
     * @param file
     * @return
     * @throws Exception
     */
    @PostMapping("/register")
    public BaseResponse<UserVO> userRegister(@ModelAttribute UserRegisterRequest userRegisterRequest,
                                              @RequestParam(required = false) MultipartFile file) throws Exception {
        ThrowUtils.throwIf(userRegisterRequest == null, ErrorCode.PARAMS_ERROR);
        String username = userRegisterRequest.getUsername();
        String email = userRegisterRequest.getEmail();
        String password = userRegisterRequest.getPassword();
        String code = userRegisterRequest.getCode();

        // 不再需要在后端进行两次输入的密码是否相同的判断
        UserVO user = usersService.userRegister(username, password, email, code, file);
        return ResultUtils.success(user);
    }

    /**
     * 请求并发送验证码
     * @param email 邮箱
     * @param request 请求
     * @return 验证码
     */
    @GetMapping("/ask_code")
    public BaseResponse<String> askCode(@RequestParam String email, HttpServletRequest request) {
        ThrowUtils.throwIf(email == null, ErrorCode.PARAMS_ERROR);
        usersService.askCode(email, request.getRemoteAddr());
        return ResultUtils.success(checkCacheCode(email));
    }

    /**
     * 查看当前缓存中对应给定邮箱的验证码
     * @param email
     * @return
     */
    @GetMapping("/check_cache_code")
    public String checkCacheCode(@RequestParam String email) {
        return usersService.checkCacheCode(email);
    }

    /**
     * 用户登录
     * @param userLoginRequest
     * @param request
     * @return
     */
    @PostMapping("/login")
    public BaseResponse<LoginUserVO> userLogin(@RequestBody UserLoginRequest userLoginRequest, HttpServletRequest request) {
        ThrowUtils.throwIf(userLoginRequest == null, ErrorCode.PARAMS_ERROR);
        // 这里可以是 username 或者 email
        String userAccount = String.valueOf(userLoginRequest.getUser_account());
        String userPassword = userLoginRequest.getPassword();
        LoginUserVO loginUserVO = usersService.userLogin(userAccount, userPassword, request);
        return ResultUtils.success(loginUserVO);
    }

    /**
     * 获取当前登录的用户信息
     * @param request
     * @return
     */
    @GetMapping("/me")
    public BaseResponse<LoginUserVO> userInfo(HttpServletRequest request) {
        ThrowUtils.throwIf(request == null, ErrorCode.NOT_LOGIN_ERROR);
        Users user = usersService.getLoginUser(request);
        LoginUserVO loginUserVo = usersService.getLoginUserVO(user);
        return ResultUtils.success(loginUserVo);
    }

    /**
     * 用户注销
     * @param request
     * @return
     */
    @PostMapping("/logout")
    public BaseResponse<Boolean> userLogout(HttpServletRequest request) {
        ThrowUtils.throwIf(request == null, ErrorCode.PARAMS_ERROR);
        boolean result = usersService.userLogout(request);
        return ResultUtils.success(result);
    }

    /**
     *  根据路径中提供的用户id，搜索对应的用户信息
     * @param user_id
     * @return
     */
    @GetMapping("/get/{id}")
    public BaseResponse<Users> getUserById(@PathVariable("id") Integer user_id) {
        System.out.println(user_id);
        ThrowUtils.throwIf(user_id <= 0, ErrorCode.PARAMS_ERROR);
        Users user = usersService.getById(user_id);
        ThrowUtils.throwIf(user == null, ErrorCode.NOT_FOUND_ERROR);
        return ResultUtils.success(user);
    }

    /**
     * 整体更新用户的 username，email，avatar信息
     * @param userUpdateRequest
     * @return
     */
    @PostMapping("/update")
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<Boolean> updateUser(@RequestBody UserUpdateRequest userUpdateRequest) {
        // 1. 验证请求非空
        // 如果请求为空，抛异常
        if (userUpdateRequest == null || userUpdateRequest.getUser_id() == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }

        // 2. 将请求类型转换为原始的用户类型
        Users user = new Users();
        BeanUtils.copyProperties(userUpdateRequest, user);
        // 根据 user_id 更改用户信息
        boolean result = usersService.updateById(user);
        // 如果更改成功 result 应该是 true
        ThrowUtils.throwIf(!result, ErrorCode.OPERATION_ERROR);
        return ResultUtils.success(true);
    }


    /**
     * 分页获取用户封装列表（仅管理员）
     * @param userQueryRequest 用户查询请求
     * @return 按页查询出来的用户信息
     */
    @PostMapping("/list")
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<Page<UserVO>> listUserVOByPage(@RequestBody UserQueryRequest userQueryRequest) {
        ThrowUtils.throwIf(userQueryRequest == null, ErrorCode.PARAMS_ERROR);
        long current = userQueryRequest.getCurrent();
        long pageSize = userQueryRequest.getPageSize();

        // 这里使用自定义的 getQueryWrapper 方法实现范围搜索，根据前端传回来的表单信息来设置动态查询的条件
        // usersService.page() 是 MyBatis-Plus 的分页查询方法，返回 Page<Users> 对象（包含当前页的用户数据 records 和总条数 total）
        Page<Users> userPage = usersService.page(new Page<>(current, pageSize),
                usersService.getQueryWrapper(userQueryRequest));
        Page<UserVO> userVOPage = new Page<>(current, pageSize, userPage.getTotal());
        List<UserVO> userVOList = usersService.getUserVOList(userPage.getRecords());
        userVOPage.setRecords(userVOList);
        return ResultUtils.success(userVOPage);
    }

    /**
     * 单独修改用户名
     * @param usernameUpdateRequest
     * @param request
     * @return
     */
    @PostMapping("/change-username")
    public BaseResponse<UserVO> changeUsername(@RequestBody UsernameUpdateRequest usernameUpdateRequest,
                                               HttpServletRequest request) {
        ThrowUtils.throwIf(usernameUpdateRequest == null, ErrorCode.PARAMS_ERROR);
        // 获取新老用户名
        String oldUsername = usernameUpdateRequest.getOldUsername();
        String newUsername = usernameUpdateRequest.getNewUsername();
        UserVO user = usersService.changeUsername(oldUsername, newUsername, request);
        return ResultUtils.success(user);
    }

    /**
     * 更改邮箱
     * @param userEmailUpdateRequest
     * @param request
     * @return
     */
    @PostMapping("/change-email")
    public BaseResponse<UserVO> changeEmail(@RequestBody UserEmailUpdateRequest userEmailUpdateRequest,
                                            HttpServletRequest request) {
        ThrowUtils.throwIf(userEmailUpdateRequest == null, ErrorCode.PARAMS_ERROR);
        // 检查新输入的邮件格式，如果不正确就直接抛出异常
        if (!EmailValidator.isValidEmail(userEmailUpdateRequest.getNewEmail())) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Wrong email format");
        }
        // 获取未更改之前的邮箱
        String oldEmail = userEmailUpdateRequest.getOldEmail();
        String newEmail = userEmailUpdateRequest.getNewEmail();
        String code = userEmailUpdateRequest.getCode();
        UserVO user = usersService.changeEmail(oldEmail, newEmail, code, request);
        return ResultUtils.success(user);
    }

    /**
     * 修改密码
     * @param resetPasswordRequest
     * @param request
     * @return
     */
    @PostMapping("/reset-password")
    public BaseResponse<String> resetPassword(@RequestBody ResetPasswordRequest resetPasswordRequest, HttpServletRequest request) {
        ThrowUtils.throwIf(resetPasswordRequest == null, ErrorCode.PARAMS_ERROR);
        String newPassword = resetPasswordRequest.getNewPassword();
        String code = resetPasswordRequest.getCode();
        String email = resetPasswordRequest.getEmail();
        // 使用请求的邮箱来查找缓存当中的验证码信息
        String result = usersService.resetPassword(newPassword, code, email, request);
        if (!(result == null)) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Failed to change the password");
        }
        return ResultUtils.success("Password Reset Success");

    }


    @GetMapping("/delete")
    public BaseResponse<?> deleteUser(Integer userId, HttpServletRequest request) {
        ThrowUtils.throwIf(userId == null, ErrorCode.PARAMS_ERROR);
        usersService.deleteUser(userId, request);
        return ResultUtils.success(null);
    }



    @PostMapping("/upload-avatar")
    public BaseResponse<PictureVO> uploadAvatar(@RequestParam("file") MultipartFile file,
                                                @RequestParam("user_id") Integer user_id,
                                                HttpServletRequest request) {
        // 判断当前用户是否登录
        Users loginUser = usersService.getLoginUser(request);
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR, "Please login first");
        }

        // 判断当前请求中的 user_id 是否和登录的用户相同
        if (!Objects.equals(loginUser.getUser_id(), user_id)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Wrong user id");
        }

        try {
            String url = qiniuService.uploadUserAvatar(file, user_id);
            PictureVO pictureUploadVO = new PictureVO();
            pictureUploadVO.setAvatar_url(url);
            return ResultUtils.success(pictureUploadVO);
        } catch (BusinessException e) {
            // 如果存在错误，则直接把默认头像赋值给用户的avatar_url
            PictureVO pictureUploadVO = new PictureVO();
            pictureUploadVO.setAvatar_url("http://" + qiniuConfig.getDomain() + "/avatars/default.jpg");
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, pictureUploadVO, "BusinessException + 图片上传失败");
        } catch (Exception e) {
            e.printStackTrace();
            // 如果存在错误，则直接把默认头像赋值给avatar_url
            PictureVO pictureUploadVO = new PictureVO();
            pictureUploadVO.setAvatar_url("http://" + qiniuConfig.getDomain() + "/avatars/default.jpg");
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, pictureUploadVO, "图片上传失败");
        }
    }


    /**
     * 删除用户头像
     * @param avatarUrl
     * @return
     */
    @PostMapping("/delete-avatar")
    public BaseResponse<String> deleteAvatar(@RequestParam("avatarUrl") String avatarUrl, HttpServletRequest request) {
        ThrowUtils.throwIf(request == null, ErrorCode.PARAMS_ERROR);

        Users loginUser = usersService.getLoginUser(request);

        // 如果不是管理员则不允许删除图片
        if (!Objects.equals(loginUser.getRole(), "ADMIN")) {
            throw new BusinessException(ErrorCode.FORBIDDEN_ERROR, "You don not have right to delete picture.");
        }

        // 判断传回来的链接是否为空，以及路径中有没有包含 avatars/
        if (avatarUrl == null || !avatarUrl.contains("avatars/")) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Wrong Url");
        }

        // 提取 key，例如从 http://xxx/avatars/xxx.jpg 提取出 avatars/xxx.jpg
        String key = avatarUrl.substring(avatarUrl.indexOf("avatars/"));
        boolean success = qiniuService.deleteAvatar(key);

        // 如果图片删除成功，则需要将数据库中用户图片的内容更改为默认图片
        if (success) {
            // 将头像更新为默认头像
            usersMapper.updateAvatarUrl(loginUser.getUser_id(), "/avatars/default.jpg");
            return ResultUtils.success("Success");
        } else {
            // 删除失败
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "Fail to delete the picture");
        }
    }

}
