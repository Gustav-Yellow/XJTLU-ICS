package com.cpt202g33.meetingbooking.exception;

import lombok.Getter;

@Getter
public enum ErrorCode {

    SUCCESS(200, "Success"),
    PARAMS_ERROR(400, "Bad Request Parameters"),
    NOT_LOGIN_ERROR(400, "Not Logged In"),
    NO_AUTH_ERROR(400, "No Permission"),
    NOT_FOUND_ERROR(404, "Data Not Found"),
    FORBIDDEN_ERROR(403, "Forbidden"),
    SYSTEM_ERROR(500, "Internal Server Error"),
    OPERATION_ERROR(501, "Operation Failed");


    /**
     * 状态码
     */
    private final int code;

    /**
     * 信息
     */
    private final String message;

    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

}