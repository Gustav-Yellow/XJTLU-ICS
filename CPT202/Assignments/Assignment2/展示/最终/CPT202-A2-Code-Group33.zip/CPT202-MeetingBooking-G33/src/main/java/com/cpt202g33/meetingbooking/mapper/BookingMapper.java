package com.cpt202g33.meetingbooking.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cpt202g33.meetingbooking.model.dto.BookingConditionDTO;
import com.cpt202g33.meetingbooking.model.entity.Bookings;
import com.cpt202g33.meetingbooking.model.vo.BookingListWithNameVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 预订数据库操作接口
 */
@Mapper
public interface BookingMapper extends BaseMapper<Bookings> {
    /**
     * 根据用户ID查询预订记录
     * @param user_id 用户ID
     * @return 预订记录列表
     */
    List<Bookings> selectByUserId(@Param("user_id") Integer user_id);

    /**
     * 查询所有预订记录（包含用户名和房间名）
     */
    @Select("SELECT b.*, u.username, r.room_name " +
            "FROM bookings b " +
            "JOIN users u ON b.user_id = u.user_id " +
            "JOIN rooms r ON b.room_id = r.room_id")
    List<BookingListWithNameVO> selectBookingDetails();

    /**
     * 根据状态查询预订记录
     */
    @Select("SELECT b.*, u.username, r.room_name " +
            "FROM bookings b " +
            "JOIN users u ON b.user_id = u.user_id " +
            "JOIN rooms r ON b.room_id = r.room_id " +
            "WHERE b.status = #{status}")
    List<BookingListWithNameVO> selectBookingDetailsByStatus(@Param("status") String status);

    /**
     * 根据预订ID查询预订记录
     */
    @Select("SELECT b.*, u.username, r.room_name " +
            "FROM bookings b " +
            "JOIN users u ON b.user_id = u.user_id " +
            "JOIN rooms r ON b.room_id = r.room_id " +
            "WHERE b.booking_id = #{booking_id}")
    BookingListWithNameVO selectBookingDetailsByBookingID(@Param("booking_id") int booking_id);
    
    /**
     * 根据用户ID查询带有房间名称的预订详情
     */
    @Select("SELECT b.*, u.username, r.room_name " +
            "FROM bookings b " +
            "JOIN users u ON b.user_id = u.user_id " +
            "JOIN rooms r ON b.room_id = r.room_id " +
            "WHERE b.user_id = #{user_id}")
    List<BookingListWithNameVO> selectBookingDetailsForUser(@Param("user_id") Integer user_id);
    
    /**
     * 根据简单条件查询带分页功能（MyBatis-Plus增强版）
     */
    IPage<BookingListWithNameVO> selectBookingListWithConditions(Page<BookingListWithNameVO> page, @Param("status") String status);
    
    /**
     * 使用复杂条件查询（MyBatis-Plus增强版）- 支持综合筛选条件
     */
    IPage<BookingListWithNameVO> selectBookingsWithComplexConditions(Page<BookingListWithNameVO> page, @Param("condition") BookingConditionDTO condition);
}