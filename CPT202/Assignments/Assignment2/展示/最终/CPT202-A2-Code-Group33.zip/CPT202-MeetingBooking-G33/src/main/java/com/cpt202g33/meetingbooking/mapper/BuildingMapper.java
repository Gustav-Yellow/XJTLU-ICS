package com.cpt202g33.meetingbooking.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cpt202g33.meetingbooking.model.entity.Building;
import org.apache.ibatis.annotations.Mapper;

/**
 * 建筑数据库操作接口
 */
@Mapper
public interface BuildingMapper extends BaseMapper<Building> {
}