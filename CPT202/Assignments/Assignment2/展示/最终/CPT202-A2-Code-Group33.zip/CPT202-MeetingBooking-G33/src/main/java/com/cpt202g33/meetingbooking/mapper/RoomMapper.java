package com.cpt202g33.meetingbooking.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import com.cpt202g33.meetingbooking.model.dto.RoomQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.Room;
import com.cpt202g33.meetingbooking.model.vo.RoomQueryResponse;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * 会议室数据库操作接口
 */
@Mapper
public interface RoomMapper extends BaseMapper<Room> {


    /**
     * 根据条件查询会议室列表
     * @param req 查询条件
     * @return 会议室列表
     */
    List<RoomQueryResponse> querySelect(@Param("req") RoomQueryRequest req);

}