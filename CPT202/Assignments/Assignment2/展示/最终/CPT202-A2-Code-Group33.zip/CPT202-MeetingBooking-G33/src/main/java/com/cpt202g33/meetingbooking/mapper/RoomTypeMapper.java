package com.cpt202g33.meetingbooking.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cpt202g33.meetingbooking.model.entity.RoomType;
import org.apache.ibatis.annotations.Mapper;

/**
 * 会议室类型数据库操作接口
 */
@Mapper
public interface RoomTypeMapper extends BaseMapper<RoomType> {
}