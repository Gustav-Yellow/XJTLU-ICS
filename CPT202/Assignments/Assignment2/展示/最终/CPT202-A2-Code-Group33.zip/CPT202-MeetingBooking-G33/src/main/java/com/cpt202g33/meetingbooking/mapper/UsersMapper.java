package com.cpt202g33.meetingbooking.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;


@Mapper
public interface UsersMapper extends BaseMapper<Users> {

    // 更新头像
    @Update("UPDATE users SET avatar_url = #{avatar_url} WHERE user_id = #{user_id}")
    int updateAvatarUrl(@Param("user_id") Integer userId, @Param("avatar_url") String avatarUrl);


    @Select("SELECT u.*, COUNT(b.booking_id) AS meeting_count " +
            "FROM users u " +
            "LEFT JOIN bookings b ON u.user_id = b.user_id " +
            "WHERE u.is_deleted = 0 " +
            "GROUP BY u.user_id")
    List<UserVO> getUserWithBookingCount();

}