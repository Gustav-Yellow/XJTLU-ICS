package com.cpt202g33.meetingbooking.model.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class AdminUserAddUserRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    private String userName;

    private String email;

    private String password;

    private String role;

    private Integer id;

    private String avatar_url;
}
