package com.cpt202g33.meetingbooking.model.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class AdminUserGetListRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    private String keyword;

    private String sortBy;

    private String order;

    private Integer minBookings;


}
