package com.cpt202g33.meetingbooking.model.dto;

import lombok.Data;

/**
 * 会议申请请求DTO
 */
@Data
public class BookingApplicationRequest {
    /** 预订开始时间，ISO8601格式 */
    private String start_time;
    /** 预订结束时间，ISO8601格式 */
    private String end_time;
    /** 预定的会议室id */
    private Long room_id;
    /** 预定会议主题 */
    private String subject;
}
