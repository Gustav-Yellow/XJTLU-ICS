package com.cpt202g33.meetingbooking.model.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 会议预订查询条件封装类
 */
@Data
public class BookingConditionDTO {
    /**
     * 用户ID
     */
    private Integer userId;
    
    /**
     * 用户名
     */
    private String username;
    
    /**
     * 房间ID
     */
    private Integer roomId;
    
    /**
     * 房间名称
     */
    private String roomName;
    
    /**
     * 会议状态
     */
    private String status;
    
    /**
     * 开始时间范围（起始）
     */
    private LocalDateTime startTimeFrom;
    
    /**
     * 开始时间范围（结束）
     */
    private LocalDateTime startTimeTo;
    
    /**
     * 排序字段
     */
    private String sortField = "start_time";
    
    /**
     * 排序方向 asc/desc
     */
    private String sortOrder = "desc";
    
    /**
     * 当前页码
     */
    private Integer current = 1;
    
    /**
     * 每页大小
     */
    private Integer pageSize = 10;
}