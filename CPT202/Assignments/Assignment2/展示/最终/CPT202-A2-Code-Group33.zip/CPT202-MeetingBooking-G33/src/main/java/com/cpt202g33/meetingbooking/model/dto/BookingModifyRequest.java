package com.cpt202g33.meetingbooking.model.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 修改会议预定请求DTO
 */
@Data
public class BookingModifyRequest {
    
    /**
     * 新的会议室ID
     */
    private Integer room_id;
    
    /**
     * 新的开始时间
     */
    private LocalDateTime start_time;
    
    /**
     * 新的结束时间
     */
    private LocalDateTime end_time;
}