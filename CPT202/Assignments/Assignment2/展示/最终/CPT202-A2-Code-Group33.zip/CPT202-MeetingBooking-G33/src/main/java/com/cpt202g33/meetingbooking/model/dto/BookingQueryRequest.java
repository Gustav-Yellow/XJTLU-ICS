package com.cpt202g33.meetingbooking.model.dto;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 预订查询请求，封装筛选条件
 */
@Data
public class BookingQueryRequest implements Serializable {

    /**
     * 用户ID筛选
     */
    private Integer userId;
    
    /**
     * 用户名筛选
     */
    private String username;

    /**
     * 会议室ID筛选
     */
    private Integer roomId;
    
    /**
     * 会议室名称筛选
     */
    private String roomName;

    /**
     * 开始时间范围（起始）
     */
    private String startTimeFrom;

    /**
     * 开始时间范围（结束）
     */
    private String startTimeTo;

    /**
     * 状态筛选（pending, approved, rejected, cancelled）
     */
    private String status;

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 排序方向（asc, desc）
     */
    private String sortOrder;

    private static final long serialVersionUID = 1L;
}