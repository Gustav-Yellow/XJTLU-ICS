package com.cpt202g33.meetingbooking.model.dto;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class FeedbackCreateRequest {

    /**
     * 用户提交的反馈内容
     */
    private String content;

}
