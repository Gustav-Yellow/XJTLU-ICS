// FeedbackReplyRequest.java
package com.cpt202g33.meetingbooking.model.dto;

import lombok.Data;

@Data
public class FeedbackReplyRequest {
    private String reply;             // 回复内容，必填
    private String resolvedNotices;   // 备注，可选
}

