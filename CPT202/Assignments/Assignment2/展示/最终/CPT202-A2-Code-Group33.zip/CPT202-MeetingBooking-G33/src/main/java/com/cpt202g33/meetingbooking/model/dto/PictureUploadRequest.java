package com.cpt202g33.meetingbooking.model.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class PictureUploadRequest implements Serializable {

    private Integer user_id;

    private Integer room_id;

}
