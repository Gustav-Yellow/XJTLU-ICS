package com.cpt202g33.meetingbooking.model.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class RoomQueryRequest implements Serializable {

    private Integer capacityMin;

    private Integer capacityMax;

    private String room_name;

    private String facility;

    private Integer building_id;

}
