package com.cpt202g33.meetingbooking.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 更新会议室信息请求体
 */
@Data
public class RoomRequest {

    /**
     * 房间名称
     */
    private String room_name;

    /**
     * 房间类型名称
     */
    private String type_name;

    /**
     * 房间类型容量
     * 创建新类型时使用
     */
    private Integer capacity;

    /**
     * 楼栋名称
     */
    private String building_name;

    /**
     * 房间配备的设施列表
     */
    private List<String> facilities;

}
