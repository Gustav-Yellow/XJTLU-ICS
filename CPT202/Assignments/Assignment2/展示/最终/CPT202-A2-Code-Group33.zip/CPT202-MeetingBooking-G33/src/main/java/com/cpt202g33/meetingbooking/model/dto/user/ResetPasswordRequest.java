package com.cpt202g33.meetingbooking.model.dto.user;

import lombok.Data;

import java.io.Serializable;

/**
 * 修改密码的请求
 */
@Data
public class ResetPasswordRequest implements Serializable {

    /**
     * 新密码
     */
    private String newPassword;

    /**
     * 用户输入的验证码
     */
    private String code;

    /**
     * 用户的邮箱
     */
    private String Email;


}
