package com.cpt202g33.meetingbooking.model.dto.user;

import lombok.Data;

import java.io.Serializable;
@Data
public class UserEmailUpdateRequest implements Serializable {

    private String code;

    private String oldEmail;

    private String newEmail;

}
