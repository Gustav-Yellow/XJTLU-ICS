package com.cpt202g33.meetingbooking.model.dto.user;

import lombok.Data;

import java.io.Serializable;

@Data
public class UsernameUpdateRequest implements Serializable {

    private String oldUsername;

    private String newUsername;

}
