package com.cpt202g33.meetingbooking.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

/**
 * 建筑实体类
 */
@Data
@Entity
@TableName("buildings")
public class Building {
    /**
     * 建筑ID
     */
    @Id
    @TableId(type = IdType.AUTO)
    private Integer building_id;
    
    /**
     * 建筑名称
     */
    private String name;
    
    /**
     * 是否删除
     */
    @TableLogic
    private Integer is_deleted;
    
    /**
     * 创建时间
     */
    private Date created_at;
    
    /**
     * 更新时间
     */
    private Date updated_at;
}