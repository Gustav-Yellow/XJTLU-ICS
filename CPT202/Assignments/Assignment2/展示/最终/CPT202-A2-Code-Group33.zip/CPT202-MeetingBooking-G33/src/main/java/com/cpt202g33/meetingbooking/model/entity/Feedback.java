package com.cpt202g33.meetingbooking.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

/**
 * 反馈实体类
 */
@Data
@Entity
@TableName("feedback")
public class Feedback {

    /**
     * 反馈ID
     */
    @Id
    @TableId(type = IdType.AUTO)
    private Integer feedback_id;

    /**
     * 用户ID
     */
    private Integer user_id;


    /**
     * 反馈内容
     */
    private String content;

    /**
     * 管理员回复内容
     */
    private String reply;

    /**
     * 反馈创建时间
     */
    private Date create_time;

    /**
     * 管理员回复时间
     */
    private Date reply_time;

    /**
     * 反馈状态（pending：待解决，resolved：已解决）
     */
    private String status;

    /**
     * 管理员ID（如果已解决）
     */
    private Integer admin_id;

    /**
     * 管理员处理备注
     */
    private String resolved_notices;
}
