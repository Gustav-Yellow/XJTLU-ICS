package com.cpt202g33.meetingbooking.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import com.vladmihalcea.hibernate.type.json.JsonType;
import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;
import java.util.List;

/**
 * 会议室实体类
 */
@Data
@Entity
@TableName(value = "rooms", autoResultMap = true)
@TypeDef(name = "json", typeClass = JsonType.class)
public class Room {
    /**
     * 会议室ID
     */
    @Id
    @TableId(type = IdType.AUTO)
    private Integer room_id;
    
    /**
     * 会议室名称
     */
    private String room_name;
    
    /**
     * 会议室类型ID
     */
    private Integer type_id;
    
    /**
     * 建筑ID
     */
    private Integer building_id;
    
    /**
     * 设施列表，使用JSON格式存储
     * 使用JacksonTypeHandler进行MyBatis-Plus的类型转换
     * 使用Hibernate的@Type注解提供JPA支持
     */
    @Type(type = "json")
    @Column(columnDefinition = "json")
    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<String> facilities;
    
    /**
     * 图片URL
     */
    private String image_url;
    
    /**
     * 创建时间
     */
    private Date created_at;
    
    /**
     * 更新时间
     */
    private Date updated_at;
    
    /**
     * 是否删除
     */
    @TableLogic
    private Integer is_deleted;
}