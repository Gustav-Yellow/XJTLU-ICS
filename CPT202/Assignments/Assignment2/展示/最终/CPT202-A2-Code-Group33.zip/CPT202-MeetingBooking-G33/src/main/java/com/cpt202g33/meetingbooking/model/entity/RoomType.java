package com.cpt202g33.meetingbooking.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

/**
 * 会议室类型实体类
 */
@Data
@Entity
@TableName("room_types")
public class RoomType {
    /**
     * 类型ID
     */
    @Id
    @TableId(type = IdType.AUTO)
    private Integer type_id;
    
    /**
     * 类型名称
     */
    private String type_name;
    
    /**
     * 类型描述
     */
    private String description;
    
    /**
     * 容量
     */
    private Integer capacity;
    
    /**
     * 是否删除
     */
    @TableLogic
    private Integer is_deleted;
    
    /**
     * 创建时间
     */
    private Date created_at;
    
    /**
     * 更新时间
     */
    private Date updated_at;
}