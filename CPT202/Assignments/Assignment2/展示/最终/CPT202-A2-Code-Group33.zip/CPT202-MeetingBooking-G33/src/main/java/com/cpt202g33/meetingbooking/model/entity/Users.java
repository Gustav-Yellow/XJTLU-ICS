package com.cpt202g33.meetingbooking.model.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
@TableName("users")
public class Users implements Serializable {
    /**
     * 用户 id
     */
    @TableId(type = IdType.AUTO)
    private Integer user_id;

    /**
     * 用户名
     */
    private String username;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 密码
     */
    private String password;

    /**
     * 角色
     */
    private String role;

    /**
     * 头像地址
     */
    private String avatar_url;

    /**
     * 创建时间
     */
    private Date created_at;

    /**
     * 修改时间
     */
    private Date updated_at;

    /**
     * 是否删除，逻辑删除
     */
    @TableLogic
    private Integer is_deleted;

    /**
     * 是否锁定
     */
    private Integer is_locked;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

}
