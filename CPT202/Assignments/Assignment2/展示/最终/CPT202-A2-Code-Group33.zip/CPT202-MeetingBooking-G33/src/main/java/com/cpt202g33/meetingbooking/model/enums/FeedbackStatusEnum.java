package com.cpt202g33.meetingbooking.model.enums;

import lombok.Getter;

@Getter
public enum FeedbackStatusEnum {

    PENDING("pending", "待处理"),
    RESOLVED("resolved", "已解决");

    private final String value;
    private final String text;

    FeedbackStatusEnum(String value, String text) {
        this.value = value;
        this.text = text;
    }

    public static FeedbackStatusEnum getEnumByValue(String value) {
        if (value == null) return null;
        for (FeedbackStatusEnum status : FeedbackStatusEnum.values()) {
            if (status.getValue().equals(value)) {
                return status;
            }
        }
        return null;
    }
}
