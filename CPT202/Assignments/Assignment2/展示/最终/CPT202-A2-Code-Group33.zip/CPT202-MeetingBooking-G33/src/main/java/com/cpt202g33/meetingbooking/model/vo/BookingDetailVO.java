package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 会议详情视图对象
 * 包含所有会议相关信息，用于详情展示
 */
@Data
public class BookingDetailVO {
    /**
     * 预订ID
     */
    private Integer booking_id;
    
    /**
     * 用户ID
     */
    private Integer user_id;
    
    /**
     * 房间ID
     */
    private Integer room_id;
    
    /**
     * 房间名称
     */
    private String room_name;
    
    /**
     * 开始时间
     */
    private LocalDateTime start_time;
    
    /**
     * 结束时间
     */
    private LocalDateTime end_time;
    
    /**
     * 预订主题
     */
    private String subject;
    
    /**
     * 预订原因
     */
    private String reason;
    
    /**
     * 预订状态（approved, pending等）
     */
    private String status;
    
    /**
     * 审核人ID
     */
    private Integer reviewer_id;
    
    /**
     * 审核时间
     */
    private LocalDateTime review_time;
    
    /**
     * 管理员回复
     */
    private String admin_reply;
    
    /**
     * 是否删除
     */
    private Integer is_deleted;
    
    /**
     * 创建时间
     */
    private LocalDateTime created_at;
    
    /**
     * 更新时间
     */
    private LocalDateTime updated_at;
}