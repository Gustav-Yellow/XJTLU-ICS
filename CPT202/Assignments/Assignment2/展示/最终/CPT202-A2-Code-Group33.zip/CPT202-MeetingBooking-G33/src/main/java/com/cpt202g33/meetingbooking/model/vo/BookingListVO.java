package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 会议列表视图对象
 * 仅包含在列表页面展示的必要信息
 */
@Data
public class BookingListVO {
    /**
     * 预订ID
     */
    private Integer booking_id;
    
    /**
     * 房间名称
     */
    private String room_name;
    
    /**
     * 开始时间
     */
    private LocalDateTime start_time;
    
    /**
     * 结束时间
     */
    private LocalDateTime end_time;
    
    /**
     * 预订状态（approved,pending,rejected,cancelled）
     */
    private String status;
}