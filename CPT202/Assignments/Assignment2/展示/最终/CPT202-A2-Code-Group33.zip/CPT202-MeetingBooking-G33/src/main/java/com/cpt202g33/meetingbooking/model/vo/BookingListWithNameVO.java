package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

/**
 * 管理员会议列表视图对象
 * 相比 BookingListVO 多了用户名，审核人名，房间名
 */
@Data
public class BookingListWithNameVO extends BookingDetailVO{
    //联查 users 表
    /**
     * 用户昵称 查询 user_id
     */
    private String username;
    /**
     * 邮箱 查询 user_id
     */
    private String email;
    /**
     * 审核人 查询 reviewer_id
     */
    private String reviewer_name;

    //联查 rooms 表
    /**
     * 会议室名称 查询 room_id
     */
    private String room_name;
}
