package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

/**
 * 建筑物视图对象
 * 用于返回建筑物信息给前端
 */
@Data
public class BuildingVO {
    /**
     * 建筑物ID
     */
    private Integer id;
    
    /**
     * 建筑物名称
     */
    private String label;
}