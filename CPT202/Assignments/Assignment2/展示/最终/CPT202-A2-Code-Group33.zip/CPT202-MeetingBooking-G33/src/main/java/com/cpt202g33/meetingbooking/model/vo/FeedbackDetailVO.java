package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

import java.util.Date;

/**
 * 反馈返回对象
 */
@Data
public class FeedbackDetailVO {

    /**
     * 反馈的唯一标识符
     */
    private Integer feedback_id;

    /**
     * 提交反馈的用户ID
     */
    private Integer user_id;

    /**
     * 用户名（用于展示）
     */
    private String username;

    /**
     * 反馈状态：pending（待解决）或 resolved（已解决）
     */
    private String status;

    /**
     * 管理员id
     */
    private Integer admin_id;

    /**
     * 用户提交的反馈内容
     */
    private String content;

    /**
     * 管理员回复的内容
     */
    private String reply;

    /**
     * 反馈提交的时间
     */
    private Date create_time;

    /**
     * 管理员回复的时间
     */
    private Date reply_time;

}
