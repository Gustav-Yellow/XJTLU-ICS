package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

import java.util.Date;

/**
 * 反馈返回对象
 */
@Data
public class FeedbackListVO {

    /**
     * 反馈的唯一标识符
     */
    private Integer feedback_id;

    /**
     * 反馈状态：pending（待解决）或 resolved（已解决）
     */
    private String status;


    /**
     * 用户提交的反馈内容
     */
    private String content;

}
