package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class PictureVO implements Serializable {

    private String avatar_url;

}
