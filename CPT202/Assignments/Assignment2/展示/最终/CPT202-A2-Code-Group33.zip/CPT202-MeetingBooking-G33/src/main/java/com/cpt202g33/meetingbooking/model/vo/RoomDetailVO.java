package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 会议室详情视图对象
 * 包含会议室的详细信息及最近的会议
 */
@Data
public class RoomDetailVO {
    /**
     * 会议室ID
     */
    private Integer room_id;
    
    /**
     * 会议室名称
     */
    private String room_name;
    
    /**
     * 会议室类型ID
     */
    private Integer type_id;
    
    /**
     * 会议室类型名称
     */
    private String type_name;
    
    /**
     * 会议室容量
     */
    private Integer capacity;
    
    /**
     * 建筑ID
     */
    private Integer building_id;
    
    /**
     * 建筑名称
     */
    private String building_name;
    
    /**
     * 设施列表
     */
    private List<String> facilities;
    
    /**
     * 图片URL
     */
    private String image_url;
    
    /**
     * 创建时间
     */
    private Date created_at;
    
    /**
     * 更新时间
     */
    private Date updated_at;
    
    /**
     * 会议室最近的预订会议
     */
    private List<BookingListVO> recent_bookings;
}