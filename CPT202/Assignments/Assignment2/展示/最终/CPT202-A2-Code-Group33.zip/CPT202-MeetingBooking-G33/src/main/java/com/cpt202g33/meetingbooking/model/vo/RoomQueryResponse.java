package com.cpt202g33.meetingbooking.model.vo;

import com.cpt202g33.meetingbooking.model.entity.Room;
import lombok.Data;

import java.io.Serializable;

@Data
public class RoomQueryResponse extends RoomVO implements Serializable {

    private String facilities_string;

    private String building_name;

    private Integer capacity;

    private String room_type_description;

}
