package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

/**
 * 房间类型视图对象
 * 用于返回房间类型信息给前端
 */
@Data
public class RoomTypeVO {
    /**
     * 类型ID
     */
    private Integer id;
    
    /**
     * 类型名称
     */
    private String label;
    
    /**
     * 类型描述
     */
    private String description;
    
    /**
     * 容量
     */
    private Integer capacity;
}