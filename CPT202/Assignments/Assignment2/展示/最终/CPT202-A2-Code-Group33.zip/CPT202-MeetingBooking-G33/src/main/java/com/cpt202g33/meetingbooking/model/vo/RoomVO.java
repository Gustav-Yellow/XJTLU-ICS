package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

import java.util.List;

/**
 * 会议室视图对象
 * 用于返回给前端的会议室数据
 */
@Data
public class RoomVO {
    /**
     * 会议室ID
     */
    private Integer room_id;
    
    /**
     * 会议室名称
     */
    private String room_name;
    
    /**
     * 会议室类型名称(不是typeid)
     */
    private String type_name;
    
    /**
     * 建筑名称
     */
    private String building_name;
    
    /**
     * 设施列表
     */
    private List<String> facilities;
    
    /**
     * 图片URL
     */
    private String image_url;
}