package com.cpt202g33.meetingbooking.model.vo.user;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * 已登录用户视图（脱敏，去除敏感信息）
 */
@Data
public class LoginUserVO implements Serializable {

    /**
     * id
     */
    private Integer user_id;

    /**
     * 用户昵称
     */
    private String username;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 用户头像
     */
    private String avatar_url;

//    /**
//     * 用户简介
//     */
//    private String userProfile;

    /**
     * 用户角色：user/admin
     */
    private String role;

    /**
     * 用户是否被锁定
     */
    private Boolean Is_locked;

    /**
     * 创建时间
     */
    private LocalDateTime created_at;

    /**
     * 更新时间
     */
    private LocalDateTime updated_at;

    private static final long serialVersionUID = 1L;

}
