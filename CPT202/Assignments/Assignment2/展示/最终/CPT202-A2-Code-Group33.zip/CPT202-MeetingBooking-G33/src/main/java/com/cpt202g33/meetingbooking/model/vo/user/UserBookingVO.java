package com.cpt202g33.meetingbooking.model.vo.user;

import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import lombok.Data;

import java.util.List;

/**
 * 详细用户信息，用户信息+用户的booking list
 */
@Data
public class UserBookingVO extends UserVO {
//    /**
//     * 用户视图
//     */
//    private UserVO user_info;

    /**
     * 该用户的booking list视图
     */

    /**
     * 用户是否被锁定
     * 变量不要含有is否则导致getter错误框架找不到变量，但是下次改吧
     */
    private boolean Is_Locked;


    private List<BookingListVO> booking_history;
}
