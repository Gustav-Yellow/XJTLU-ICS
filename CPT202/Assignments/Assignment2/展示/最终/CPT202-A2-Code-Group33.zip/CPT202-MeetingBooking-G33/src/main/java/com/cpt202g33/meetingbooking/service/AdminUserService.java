package com.cpt202g33.meetingbooking.service;

import com.cpt202g33.meetingbooking.model.dto.AdminUserAddUserRequest;
import com.cpt202g33.meetingbooking.model.vo.user.UserBookingVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;

import java.util.List;

public interface AdminUserService {
    /**
     * 根据请求获取用户列表
     *
     * @return 用户列表
     */
    List<UserVO> getUserLists();

    /**
     * 获取用户详细信息
     *
     * @param userId 用户id
     * @return
     */
    UserBookingVO getUser(Integer userId);

    /**
     * 锁定用户
     * @param userId 用户id
     */
    void lockUser(Integer userId);

    /**
     * 解锁用户
     * @param userId 用户id
     */
    void unlockUser(Integer userId);

    /**
     * 删除用户
     * @param userId 用户id
     */
    void deleteUser(Integer userId);

    /**
     * 添加用户
     *
     * @param request 请求参数，id等
     */
    void addUser(AdminUserAddUserRequest request);
}
