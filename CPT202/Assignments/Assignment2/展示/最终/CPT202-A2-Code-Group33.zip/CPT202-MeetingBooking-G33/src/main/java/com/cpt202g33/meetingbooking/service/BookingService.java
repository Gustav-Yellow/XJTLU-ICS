package com.cpt202g33.meetingbooking.service;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.model.dto.BookingModifyRequest;
import com.cpt202g33.meetingbooking.model.dto.BookingApplicationRequest;
import com.cpt202g33.meetingbooking.model.dto.BookingQueryRequest;
import com.cpt202g33.meetingbooking.model.vo.BookingDetailVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListWithNameVO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 预订服务接口
 */
public interface BookingService {
    /**
     * 根据用户ID获取预订记录
     * @param user_id 用户ID
     * @return 用户预订记录列表
     */
    List<BookingListVO> getBookingsByUserId(Integer user_id);

    /**
     * 获取所有预定记录 默认all，时间，降序
     * @param status 获取何种状态的预定记录（all, pending, approved, rejected）
     * @return 所有符合要求的预定记录列表
     */
    List<BookingListWithNameVO> getAllBookingList(String status);
    
    /**
     * 根据筛选条件查询预订记录
     * @param queryRequest 查询条件
     * @return 符合条件的预订记录列表
     */
    List<BookingListWithNameVO> queryBookings(BookingQueryRequest queryRequest);

    /**
     * 取消预订
     * @param booking_id 预订ID
     * @param user_id 用户ID
     * @param role 用户角色
     * @return 是否成功
     */
    boolean cancelBooking(Integer booking_id, Integer user_id, String role);
    
    /**
     * 获取会议详情
     * @param booking_id 会议ID
     * @param user_id 当前用户ID
     * @param role 用户角色
     * @return 会议详情
     */
    BookingDetailVO getBookingById(Integer booking_id, Integer user_id, String role);

    /**
     * 管理员根据预定ID查看单条预定详情
     *
     * @param bookingId 预约记录的ID
     * @return 对应ID的详细预约内容
     */
    BookingListWithNameVO getBookingWithNameByBookingID(Integer bookingId);

    /**
     * 管理员批准某预定ID的申请
     *
     * @param bookingId 预约申请的ID
     * @param adminReply 管理员的审批回复，可选填
     * @return True或False 成功失败
     */
     Boolean approveBooking(Integer bookingId, String adminReply, Integer adminId, LocalDateTime approveTime);

    /**
     * 管理员拒绝某预定ID的申请
     *
     * @param bookingId 预约申请的ID
     * @param adminReply 管理员的拒绝原因，必填
     * @return 200或6001
     */
    Boolean rejectBooking(Integer bookingId, String adminReply, Integer adminId, LocalDateTime approveTime);

    /**
     * 修改预定时间和地点
     * @param booking_id 预定ID
     * @param modifyRequest 修改请求
     * @param user_id 当前用户ID
     * @param role 用户角色
     * @return 是否修改成功
     */
    boolean modifyBooking(Integer booking_id, BookingModifyRequest modifyRequest, Integer user_id, String role);

    /**
     * 会议申请接口
     * @param applicationRequest 申请参数
     * @param userId 用户ID
     * @return 是否申请成功
     */
    boolean applyBooking(BookingApplicationRequest applicationRequest, Integer userId, String role);

    /**
     * 获取用户未来的预订记录（开始时间在当前时间之后）
     * @param user_id 用户ID
     * @return 预订记录列表
     */
    List<BookingListVO> getFutureBookingsByUserId(Integer user_id);

    /**
     * 获取用户历史的预订记录（结束时间在当前时间之前）
     * @param user_id 用户ID
     * @return 预订记录列表
     */
    List<BookingListVO> getHistoryBookingsByUserId(Integer user_id);


}