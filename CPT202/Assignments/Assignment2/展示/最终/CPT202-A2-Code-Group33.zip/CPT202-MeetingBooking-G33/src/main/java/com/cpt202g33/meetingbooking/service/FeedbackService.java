package com.cpt202g33.meetingbooking.service;

import com.cpt202g33.meetingbooking.model.dto.FeedbackCreateRequest;
import com.cpt202g33.meetingbooking.model.dto.FeedbackReplyRequest;
import com.cpt202g33.meetingbooking.model.vo.FeedbackDetailVO;
import com.cpt202g33.meetingbooking.model.vo.FeedbackListVO;

import java.util.List;

public interface FeedbackService {


    boolean save(FeedbackCreateRequest feedbackCreateRequest, Integer userId);


    boolean replyFeedback(Integer feedbackId, FeedbackReplyRequest request, Integer user_id);

    List<FeedbackListVO> listAllResolvedFeedbacks(Integer userId);

    List<FeedbackListVO> listAllPendingFeedbacks(Integer userId);

    List<FeedbackListVO> adminListAllResolvedFeedbacks();

    List<FeedbackListVO> adminListAllPendingFeedbacks();

    FeedbackDetailVO getFeedbackDetailById(Integer feedbackId);
}
