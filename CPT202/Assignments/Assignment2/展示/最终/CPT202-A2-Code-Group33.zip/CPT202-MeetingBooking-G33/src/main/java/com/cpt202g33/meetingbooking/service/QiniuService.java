package com.cpt202g33.meetingbooking.service;

import com.qiniu.common.QiniuException;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.Region;
import com.qiniu.storage.UploadManager;
import com.qiniu.util.Auth;
import com.qiniu.http.Response;
import com.cpt202g33.meetingbooking.config.QiniuConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

@Service
public interface QiniuService {


    /**
     * 上传头像流到七牛云
     * @param inputStream 上传文件流
     * @param key 保存到七牛的文件名（带路径）
     * @return 文件访问地址
     * @throws QiniuException 上传失败抛出异常
     */
     String uploadAvatar(InputStream inputStream, String key) throws QiniuException;

    /**
     * 上传图片至七牛云对象存储
     * @param file 前端传过来的邮件
     * @param user_id 用户ID
     * @return
     * @throws Exception
     */
    String uploadUserAvatar(MultipartFile file, Integer user_id) throws Exception;

    /**
     * 删除头像
     * @param key
     * @return
     */
    boolean deleteAvatar(String key);

    /**
     * 校验图片
     * @param inputSource
     */
    void validPicture(Object inputSource);


    String uploadRoomImage(MultipartFile file, Integer roomId);
}
