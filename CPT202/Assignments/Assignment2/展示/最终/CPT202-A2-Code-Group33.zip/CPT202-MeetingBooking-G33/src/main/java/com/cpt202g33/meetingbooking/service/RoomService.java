package com.cpt202g33.meetingbooking.service;

import com.cpt202g33.meetingbooking.model.dto.RoomQueryRequest;
import com.cpt202g33.meetingbooking.model.vo.RoomDetailVO;
import com.cpt202g33.meetingbooking.model.vo.RoomQueryResponse;
import com.cpt202g33.meetingbooking.model.vo.RoomVO;
import com.cpt202g33.meetingbooking.model.dto.RoomRequest;
import com.cpt202g33.meetingbooking.model.entity.Building;
import com.cpt202g33.meetingbooking.model.entity.RoomType;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 会议室服务接口
 */
public interface RoomService {
    
    /**
     * 获取所有会议室列表
     * @return 会议室列表
     */
    List<RoomVO> listAllRooms();

    /**
     * 返回根据筛选条件得到的结果
     * @return
     */
    List<RoomQueryResponse> queryListRooms(RoomQueryRequest roomQueryRequest);
    
    /**
     * 获取会议室详情，包括最近的会议记录
     * @param room_id 会议室ID
     * @return 会议室详情
     */
    RoomDetailVO getRoomDetail(Integer room_id);
  
    /**
     * 更新会议室信息
     * @param roomId 会议室ID
     * @param request 更新请求对象
     * @return 是否成功
     */
    boolean updateRoomInfo(Integer roomId, RoomRequest request);
    
    /**
     * 创建新的会议室
     * @param request 创建请求对象
     * @return 是否成功
     */
    boolean createRoom(RoomRequest request, MultipartFile file);
    
    /**
     * 获取所有房间类型
     * @return 房间类型列表
     */
    List<RoomType> listAllRoomTypes();
    
    /**
     * 获取所有建筑物
     * @return 建筑物列表
     */
    List<Building> listAllBuildings();


    /**
     * 更新建筑物图片
     * @return 是否成功
     */
    boolean updateRoomImageUrl(Integer roomId, String url);

    boolean changeRoomImage(Integer roomId, String url);

    boolean deleteRoom(Integer roomId);
}

