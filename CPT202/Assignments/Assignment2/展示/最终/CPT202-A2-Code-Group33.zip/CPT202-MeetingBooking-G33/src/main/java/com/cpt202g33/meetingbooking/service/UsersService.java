package com.cpt202g33.meetingbooking.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cpt202g33.meetingbooking.model.dto.user.UserQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.user.LoginUserVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserBookingVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

public interface UsersService extends IService<Users> {

    /**
     * 用户注册
     *
     * @param username   用户账户
     * @param password  用户密码
     * @return 新用户 id
     */
    UserVO userRegister(String username, String password, String email, String code, MultipartFile file) throws Exception;


    /**
     * 获取加密后的密码
     *
     * @param password
     * @return
     */
    String getEncryptPassword(String password);

    /**
     * 用户登录
     *
     * @param username  用户账户
     * @param password 用户密码
     * @param request
     * @return 脱敏后的用户信息
     */
    LoginUserVO userLogin(String username, String password, HttpServletRequest request);

    /**
     * 用户注销
     *
     * @param request
     * @return
     */
    boolean userLogout(HttpServletRequest request);

    /**
     * 获取当前登录用户
     *
     * @param request
     * @return
     */
    Users getLoginUser(HttpServletRequest request);

    /**
     * 获得脱敏后的登录用户信息
     *
     * @param user
     * @return
     */
    LoginUserVO getLoginUserVO(Users user);

    /**
     * 获得脱敏后的用户信息
     *
     * @param user
     * @return
     */
    UserVO getUserVO(Users user);

    /**
     * 获得脱敏后的用户信息列表
     *
     * @param userList
     * @return 脱敏后的用户列表
     */
    List<UserVO> getUserVOList(List<Users> userList);

    /**
     * 获取查询条件
     * @param userQueryRequest
     * @return
     */
    QueryWrapper<Users> getQueryWrapper(UserQueryRequest userQueryRequest);

    /**
     * 请求并发送验证码
     * @param email
     * @param ip
     */
    void askCode(String email, String ip);

    /**
     * 检查本地缓存中的验证码
     * @param email
     * @return
     */
    String checkCacheCode(String email);

    /**
     * 修改密码
     * @param newPassword
     * @param code
     * @param email
     * @return
     */
    String resetPassword(String newPassword, String code, String email, HttpServletRequest request);

    /**
     * 修改用户名
     * @param newUsername
     * @return
     */
    UserVO changeUsername(String oldUsername, String newUsername, HttpServletRequest request);

    /**
     * 修改邮箱地址
     * @param oldEmail
     * @param newEmail
     * @param request
     * @return
     */
    UserVO changeEmail(String oldEmail, String newEmail, String code, HttpServletRequest request);

    void deleteUser(Integer userId, HttpServletRequest request);
}
