package com.cpt202g33.meetingbooking.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cpt202g33.meetingbooking.config.QiniuConfig;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.mapper.BookingMapper;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.mapper.RoomMapper;
import com.cpt202g33.meetingbooking.model.dto.AdminUserAddUserRequest;
import com.cpt202g33.meetingbooking.model.entity.Bookings;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.entity.Room;
import com.cpt202g33.meetingbooking.model.vo.BookingDetailVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListWithNameVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserBookingVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import com.cpt202g33.meetingbooking.service.AdminUserService;
import com.cpt202g33.meetingbooking.service.BookingService;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service
public class AdminUserServiceImpl implements AdminUserService {
    @Resource
    private UsersMapper usersMapper;

    @Resource
    private BookingMapper bookingMapper;
    
    @Resource
    private RoomMapper roomMapper;
    
    // 注入BookingService
    @Resource
    private BookingService bookingService;
    @Autowired
    private QiniuConfig qiniuConfig;

    @Override
    public List<UserVO> getUserLists() {
        List<UserVO> userVOs = usersMapper.getUserWithBookingCount();
        for (UserVO userVO : userVOs) {
            String key = userVO.getAvatar_url();
            String url = "http://" + qiniuConfig.getDomain() + key;
            userVO.setAvatar_url(url);
        }
        return userVOs;
    }

    @Override
    public UserBookingVO getUser(Integer userId) {
        Users user = validateAndGetUser(userId);
        UserBookingVO userBookingVO = new UserBookingVO();
        BeanUtils.copyProperties(user, userBookingVO);
        if(user.getIs_locked() == 0){
            userBookingVO.setIs_Locked(false);
        }
        else{
            userBookingVO.setIs_Locked(true);
        }
        String key = user.getAvatar_url();
        String url = "http://" + qiniuConfig.getDomain() + key;
        userBookingVO.setAvatar_url(url);
        // 直接使用 BookingService 获取用户未来的预定会议
        userBookingVO.setBooking_history(bookingService.getFutureBookingsByUserId(userId));

        return userBookingVO;
    }

    @Override
    public void lockUser(Integer userId) {
        Users user = validateAndGetUser(userId);
        if (user.getIs_locked() == 1) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "User is already locked.");
        }
        user.setIs_locked(1);
        usersMapper.updateById(user);
    }

    @Override
    public void unlockUser(Integer userId) {
        Users user = validateAndGetUser(userId);
        if (user.getIs_locked() == 0) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "User is already unlocked.");
        }
        user.setIs_locked(0);
        usersMapper.updateById(user);
    }

    @Override
    public void deleteUser(Integer userId) {
        if (!validateUserId(userId)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "User not found.");
        }
        usersMapper.deleteById(userId);
    }

    @Override
    public void addUser(AdminUserAddUserRequest request) {
        String username = request.getUserName();
        String password = request.getPassword();
        String email = request.getEmail();
        String role = request.getRole();
        Integer id = request.getId(); //todo 决定一下是否需要学号？
        String avatarUrl = request.getAvatar_url();

        // 用户名密码邮箱校验
        if (StrUtil.hasBlank(username, password, email)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Blanks in username, password or email.");
        }
        if (password.length() < 8) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Password too short.");
        }

        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        queryWrapper
                .eq("username", username)
                .or()
                .eq("email", email);
        if (usersMapper.selectCount(queryWrapper) > 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "User already exist.");
        }

        String encryptedPassword = new UsersServiceImpl().getEncryptPassword(password);
        Users user = new Users();
        user.setUsername(username);
        user.setPassword(encryptedPassword);
        user.setEmail(email);
        user.setRole(role);
//        user.setId();
        user.setAvatar_url(avatarUrl);

        if (usersMapper.insert(user) == 0) {
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "Error happened when adding user.");
        }
    }

    private Users validateAndGetUser(Integer userId) {
        if (!validateUserId(userId)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "User not found.");
        }

        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        Users user = usersMapper.selectOne(queryWrapper);
        if (user == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "User not found.");
        }

        return user;
    }

    private boolean validateUserId(Integer userId) {
        if (userId == null || userId < 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Invalid user id.");
        }
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);

        return usersMapper.selectCount(queryWrapper) > 0;
    }
}
