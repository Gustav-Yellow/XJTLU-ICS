package com.cpt202g33.meetingbooking.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.mapper.BookingMapper;
import com.cpt202g33.meetingbooking.mapper.RoomMapper;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.dto.BookingModifyRequest;
import com.cpt202g33.meetingbooking.model.dto.BookingApplicationRequest;
import com.cpt202g33.meetingbooking.model.dto.BookingConditionDTO;
import com.cpt202g33.meetingbooking.model.dto.BookingQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.Bookings;
import com.cpt202g33.meetingbooking.model.entity.Room;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.enums.UsersRoleEnum;
import com.cpt202g33.meetingbooking.model.vo.BookingDetailVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListWithNameVO;
import com.cpt202g33.meetingbooking.service.BookingService;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 预订服务实现类
 */
@Service
public class BookingServiceImpl implements BookingService {
    
    @Resource
    private BookingMapper bookingMapper;
    
    @Resource
    private RoomMapper roomMapper;
    
    @Resource
    private UsersMapper usersMapper;
    
    /**
     * 获取用户未来的预订记录（开始时间在当前时间之后）
     */
    @Override
    public List<BookingListVO> getFutureBookingsByUserId(Integer user_id) {
        QueryWrapper<Bookings> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", user_id);
        queryWrapper.ge("start_time", LocalDateTime.now());
        queryWrapper.orderByAsc("start_time");
        List<Bookings> bookings = bookingMapper.selectList(queryWrapper);
        List<BookingListVO> bookingListVOList = new ArrayList<>();
        for (Bookings booking : bookings) {
            BookingListVO bookingListVO = new BookingListVO();
            BeanUtils.copyProperties(booking, bookingListVO);
            Room room = roomMapper.selectById(booking.getRoom_id());
            bookingListVO.setRoom_name(room != null ? room.getRoom_name() : "未知会议室");
            bookingListVOList.add(bookingListVO);
        }
        return bookingListVOList;
    }

    /**
     * 获取用户历史的预订记录（结束时间在当前时间之前）
     */
    @Override
    public List<BookingListVO> getHistoryBookingsByUserId(Integer user_id) {
        QueryWrapper<Bookings> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", user_id);
        queryWrapper.lt("end_time", LocalDateTime.now());
        queryWrapper.orderByDesc("start_time");
        List<Bookings> bookings = bookingMapper.selectList(queryWrapper);
        List<BookingListVO> bookingListVOList = new ArrayList<>();
        for (Bookings booking : bookings) {
            BookingListVO bookingListVO = new BookingListVO();
            BeanUtils.copyProperties(booking, bookingListVO);
            Room room = roomMapper.selectById(booking.getRoom_id());
            bookingListVO.setRoom_name(room != null ? room.getRoom_name() : "未知会议室");
            bookingListVOList.add(bookingListVO);
        }
        return bookingListVOList;
    }

    /**
     * 获取用户历史的预订记录（结束时间在当前时间之前）
     */
    @Override
    public List<BookingListVO> getBookingsByUserId(Integer user_id) {
        QueryWrapper<Bookings> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", user_id);
        List<Bookings> bookings = bookingMapper.selectList(queryWrapper);
        
        List<BookingListVO> bookingListVOList = new ArrayList<>();
        
        for (Bookings booking : bookings) {
            BookingListVO bookingListVO = new BookingListVO();
            BeanUtils.copyProperties(booking, bookingListVO);
            bookingListVOList.add(bookingListVO);
        }
        
        return bookingListVOList;
    }

    /**
     * 获取所有预定详细记录 默认all，时间，降序
     * @param status 获取何种状态的预定记录（all, pending, approved, rejected）
     * @return 所有符合要求的预定记录列表
     */
    @Override
    public List<BookingListWithNameVO> getAllBookingList(String status) {
        // 筛选对应status的会议预约
        List<BookingListWithNameVO> bookingsWithName;
        if (status != null && !"all".equalsIgnoreCase(status)) {
            bookingsWithName = bookingMapper.selectBookingDetailsByStatus(status);
        } else bookingsWithName = bookingMapper.selectBookingDetails();

        return bookingsWithName;
    }

    /**
     * 管理员根据预定ID查看单条预定详情
     *
     * @param bookingId 预约记录的ID
     * @return 对应ID的详细预约内容
     */
    @Override
    public BookingListWithNameVO getBookingWithNameByBookingID(Integer bookingId) {
        return bookingMapper.selectBookingDetailsByBookingID(bookingId);
    }

    /**
     * 管理员批准某预定ID的申请
     *
     * @param bookingId 预约申请的ID
     * @param adminReply 管理员的审批回复，可选填
     * @return True或False 成功失败
     */
    public Boolean approveBooking(Integer bookingId, String adminReply, Integer adminId, LocalDateTime approveTime){
        // 查询预订记录
        Bookings booking = bookingMapper.selectById(bookingId);
        if (booking == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "预约记录不存在");
        }
        // 如果不是 pending 状态，拒绝审批
        if (!"pending".equalsIgnoreCase(booking.getStatus())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "该预约已审批，无法重复操作");
        }
        // 更新数据
        UpdateWrapper<Bookings> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("booking_id", bookingId)
                .set("status", "approved")
                .set("reviewer_id", adminId)
                .set("review_time", approveTime)
                .set("admin_reply", adminReply);
        int rows = bookingMapper.update(null, updateWrapper);
        return rows == 1;
    }

    /**
     * 管理员拒绝某预定ID的申请
     *
     * @param bookingId 预约申请的ID
     * @param adminReply 管理员的拒绝原因，必填
     * @return 200或6001
     */
    public Boolean rejectBooking(Integer bookingId, String adminReply, Integer adminId, LocalDateTime approveTime){
        // 查询预订记录
        Bookings booking = bookingMapper.selectById(bookingId);
        if (booking == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "预约记录不存在");
        }
        // 如果不是 pending 状态，拒绝审批
        if (!"pending".equalsIgnoreCase(booking.getStatus())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "该预约已审批，无法重复操作");
        }
        // 更新数据
        UpdateWrapper<Bookings> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("booking_id", bookingId)
                .set("status", "rejected")
                .set("reviewer_id", adminId)
                .set("review_time", approveTime)
                .set("admin_reply", adminReply);

        int rows = bookingMapper.update(null, updateWrapper);
        return rows == 1;
    }

    /**
     * 取消预订
     * @param booking_id 预订ID
     * @param user_id 用户ID
     * @param role 用户角色
     * @return 是否成功
     */
    @Override
    public boolean cancelBooking(Integer booking_id, Integer user_id, String role) {
        // 1. 验证预订是否存在
        Bookings booking = bookingMapper.selectById(booking_id);
        if (booking == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "预订不存在");
        }
        
        // 2. 验证是否有权限取消预订
        // 如果不是管理员，则只能取消自己的预订
        if (!UsersRoleEnum.ADMIN.getValue().equals(role) && !booking.getUser_id().equals(user_id)) {
            throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "无权限取消他人的预订");
        }
        
        // 3. 执行逻辑删除操作
        UpdateWrapper<Bookings> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("booking_id", booking_id);
        updateWrapper.set("status", "cancelled"); // 更新状态为已取消
        
        int result = bookingMapper.update(null, updateWrapper);
        return result > 0;
    }
    
    /**
     * 根据会议ID获取会议详情
     * 只有会议创建者和管理员可以查看会议详情
     *
     * @param booking_id 会议ID
     * @param user_id 当前用户ID
     * @param role 用户角色
     * @return 会议详情
     */
    @Override
    public BookingDetailVO getBookingById(Integer booking_id, Integer user_id, String role) {
        // 1. 验证会议是否存在
        Bookings booking = bookingMapper.selectById(booking_id);
        if (booking == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "会议不存在");
        }
        
        // 2. 验证权限：只有会议创建者和管理员可以查看会议详情
        boolean isAdmin = UsersRoleEnum.ADMIN.getValue().equals(role);
        boolean isCreator = booking.getUser_id().equals(user_id);
        
        if (!isAdmin && !isCreator) {
            throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "无权限查看该会议详情");
        }
        
        // 3. 封装返回结果
        BookingDetailVO bookingDetailVO = new BookingDetailVO();
        BeanUtils.copyProperties(booking, bookingDetailVO);
        
        // 4. 查询并设置房间名称
        if (booking.getRoom_id() != null) {
            Room room = roomMapper.selectById(booking.getRoom_id());
            if (room != null) {
                bookingDetailVO.setRoom_name(room.getRoom_name());
            } else {
                bookingDetailVO.setRoom_name("未知会议室");
            }
        } else {
            bookingDetailVO.setRoom_name("未分配会议室");
        }
        
        return bookingDetailVO;
    }
    
    /**
     * 修改预定时间和地点
     * @param booking_id 预定ID
     * @param modifyRequest 修改请求
     * @param user_id 当前用户ID
     * @param role 用户角色
     * @return 是否修改成功
     */
    @Override
    @Transactional
    public boolean modifyBooking(Integer booking_id, BookingModifyRequest modifyRequest, Integer user_id, String role) {
        // 1. 验证预定是否存在
        Bookings booking = bookingMapper.selectById(booking_id);
        if (booking == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "预定不存在");
        }
        
        // 2. 验证权限
        boolean isAdmin = role.equals(UserConstant.ADMIN_ROLE);
        boolean isOwner = booking.getUser_id().equals(user_id);
        
        if (!isAdmin && !isOwner) {
            throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "无权限修改该预定");
        }
        
        // 3. 验证状态，只允许修改待审核或已批准的预定
        if ("cancelled".equals(booking.getStatus()) || "rejected".equals(booking.getStatus())) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "已取消或被拒绝的预定不能修改");
        }
        
        // 4. 参数验证
        if (modifyRequest.getStart_time() != null && modifyRequest.getEnd_time() != null) {
            // 验证时间有效性
            if (modifyRequest.getStart_time().isAfter(modifyRequest.getEnd_time())) {
                throw new BusinessException(ErrorCode.PARAMS_ERROR, "开始时间不能晚于结束时间");
            }
            
            // 验证修改后的时间是否已过期
            if (modifyRequest.getStart_time().isBefore(LocalDateTime.now())) {
                throw new BusinessException(ErrorCode.PARAMS_ERROR, "不能修改为过去的时间");
            }
        }
        
        if (modifyRequest.getRoom_id() != null) {
            // 验证会议室是否存在
            Room room = roomMapper.selectById(modifyRequest.getRoom_id());
            if (room == null) {
                throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "会议室不存在");
            }
            
            // 验证新时间和会议室是否有冲突
            if (modifyRequest.getStart_time() != null && modifyRequest.getEnd_time() != null) {
                QueryWrapper<Bookings> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("room_id", modifyRequest.getRoom_id());
                queryWrapper.ne("booking_id", booking_id); // 排除当前正在修改的预定
                queryWrapper.ne("status", "cancelled"); // 排除已取消的预定
                queryWrapper.ne("status", "rejected"); // 排除被拒绝的预定
                
                // 检查是否与其他会议时间重叠
                // (start1 <= end2) AND (end1 >= start2)
                queryWrapper.le("start_time", modifyRequest.getEnd_time());
                queryWrapper.ge("end_time", modifyRequest.getStart_time());
                
                Long conflictCount = bookingMapper.selectCount(queryWrapper);
                if (conflictCount > 0) {
                    throw new BusinessException(ErrorCode.PARAMS_ERROR, "所选时间段与其他会议冲突");
                }
            }
        }
        
        // 5. 应用修改
        UpdateWrapper<Bookings> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("booking_id", booking_id);
        
        boolean needUpdate = false;
        
        if (modifyRequest.getRoom_id() != null && !modifyRequest.getRoom_id().equals(booking.getRoom_id())) {
            updateWrapper.set("room_id", modifyRequest.getRoom_id());
            needUpdate = true;
        }
        
        if (modifyRequest.getStart_time() != null && !modifyRequest.getStart_time().equals(booking.getStart_time())) {
            updateWrapper.set("start_time", modifyRequest.getStart_time());
            needUpdate = true;
        }
        
        if (modifyRequest.getEnd_time() != null && !modifyRequest.getEnd_time().equals(booking.getEnd_time())) {
            updateWrapper.set("end_time", modifyRequest.getEnd_time());
            needUpdate = true;
        }
        
        // 如果是普通用户修改，将状态重置为待审核
        if (!isAdmin && needUpdate) {
            updateWrapper.set("status", "pending");
            updateWrapper.set("review_time", null);
            updateWrapper.set("reviewer_id", null);
            updateWrapper.set("admin_reply", null);
        }
        
        // 6. 更新数据库
        if (needUpdate) {
            int result = bookingMapper.update(null, updateWrapper);
            return result > 0;
        }
        
        return true; // 无需更新也视为成功
    }

    /**
     * 申请会议预订
     * @param applicationRequest 申请请求
     * @param userId 当前用户ID
     * @return 是否申请成功
     */
    @Override
    @Transactional
    public boolean applyBooking(BookingApplicationRequest applicationRequest, Integer userId, String role) {
        // 参数校验
        if (applicationRequest == null || applicationRequest.getRoom_id() == null
                || applicationRequest.getStart_time() == null || applicationRequest.getEnd_time() == null
                || applicationRequest.getSubject() == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "参数不完整");
        }
        // 解析时间
        LocalDateTime startTime;
        LocalDateTime endTime;
        try {
            startTime = LocalDateTime.parse(applicationRequest.getStart_time());
            endTime = LocalDateTime.parse(applicationRequest.getEnd_time());
        } catch (Exception e) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "时间格式错误，应为ISO8601格式");
        }
        if (startTime.isAfter(endTime) || startTime.isBefore(LocalDateTime.now())) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "时间区间不合法");
        }
        // 检查会议室是否存在
        Room room = roomMapper.selectById(applicationRequest.getRoom_id());
        if (room == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "会议室不存在");
        }
        // 检查时间冲突
        QueryWrapper<Bookings> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("room_id", applicationRequest.getRoom_id());
        queryWrapper.ne("status", "cancelled");
        queryWrapper.ne("status", "rejected");
        queryWrapper.le("start_time", endTime);
        queryWrapper.ge("end_time", startTime);
        Long conflictCount = bookingMapper.selectCount(queryWrapper);
        if (conflictCount > 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "所选时间段与其他会议冲突");
        }
        // 创建预订
        Bookings booking = new Bookings();
        booking.setUser_id(userId);
        booking.setRoom_id(applicationRequest.getRoom_id() == null ? null : applicationRequest.getRoom_id().intValue());
        booking.setStart_time(startTime);
        booking.setEnd_time(endTime);
        booking.setSubject(applicationRequest.getSubject());
        // 判断是否当前登录的用户身份是管理员，如果是管理员则不需要等待预定确认
        if (role.equals(UserConstant.ADMIN_ROLE)) {
            booking.setStatus("approved");
        } else {
            booking.setStatus("pending"); // 默认待审核
        }
        int result = bookingMapper.insert(booking);
        return result > 0;
    }

    /**
     * 根据筛选条件查询预订记录
     * 使用MyBatis-Plus进行条件查询
     * @param queryRequest 查询条件请求对象
     * @return 符合条件的预订记录列表
     */
    @Override
    public List<BookingListWithNameVO> queryBookings(BookingQueryRequest queryRequest) {
        // 如果查询条件为空，则返回所有预订记录
        if (queryRequest == null) {
            return getAllBookingList("all");
        }
        
        // 构建查询条件对象
        BookingConditionDTO condition = new BookingConditionDTO();
        
        // 设置用户ID条件
        if (queryRequest.getUserId() != null) {
            condition.setUserId(queryRequest.getUserId());
        }
        
        // 设置用户名条件
        if (StringUtils.hasText(queryRequest.getUsername())) {
            condition.setUsername(queryRequest.getUsername());
        }
        
        // 设置房间ID条件
        if (queryRequest.getRoomId() != null) {
            condition.setRoomId(queryRequest.getRoomId());
        }
        
        // 设置房间名称条件
        if (StringUtils.hasText(queryRequest.getRoomName())) {
            condition.setRoomName(queryRequest.getRoomName());
        }
        
        // 设置状态条件
        if (StringUtils.hasText(queryRequest.getStatus())) {
            condition.setStatus(queryRequest.getStatus());
        }
        
        // 设置时间范围条件
        if (StringUtils.hasText(queryRequest.getStartTimeFrom())) {
            try {
                LocalDateTime startTimeFrom = LocalDateTime.parse(queryRequest.getStartTimeFrom());
                condition.setStartTimeFrom(startTimeFrom);
            } catch (DateTimeParseException e) {
                throw new BusinessException(ErrorCode.PARAMS_ERROR, "开始时间格式错误，应为ISO8601格式");
            }
        }
        
        if (StringUtils.hasText(queryRequest.getStartTimeTo())) {
            try {
                LocalDateTime startTimeTo = LocalDateTime.parse(queryRequest.getStartTimeTo());
                condition.setStartTimeTo(startTimeTo);
            } catch (DateTimeParseException e) {
                throw new BusinessException(ErrorCode.PARAMS_ERROR, "结束时间格式错误，应为ISO8601格式");
            }
        }
        
        // 设置排序条件
        if (StringUtils.hasText(queryRequest.getSortField())) {
            condition.setSortField(queryRequest.getSortField());
        }
        
        if (StringUtils.hasText(queryRequest.getSortOrder())) {
            condition.setSortOrder(queryRequest.getSortOrder());
        }
        
        // 创建分页对象
        Page<BookingListWithNameVO> page = new Page<>(1, 100); // 默认一次返回100条
        
        // 执行查询
        IPage<BookingListWithNameVO> bookingPage = bookingMapper.selectBookingsWithComplexConditions(page, condition);
        
        // 返回查询结果
        return bookingPage.getRecords();
    }
}