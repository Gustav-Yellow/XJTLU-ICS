package com.cpt202g33.meetingbooking.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.mapper.FeedbackMapper;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.dto.FeedbackCreateRequest;
import com.cpt202g33.meetingbooking.model.dto.FeedbackReplyRequest;
import com.cpt202g33.meetingbooking.model.entity.Feedback;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.enums.FeedbackStatusEnum;

import com.cpt202g33.meetingbooking.model.vo.FeedbackDetailVO;
import com.cpt202g33.meetingbooking.model.vo.FeedbackListVO;
import com.cpt202g33.meetingbooking.service.FeedbackService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    private FeedbackMapper feedbackMapper;

    @Autowired
    private UsersMapper usersMapper;

    @Override
    public boolean save(FeedbackCreateRequest feedbackCreateRequest, Integer userId) {
        log.info("创建用户反馈：userId={}, content={}", userId, feedbackCreateRequest != null ? feedbackCreateRequest.getContent() : "null");

        // 1. 空值校验
        if (feedbackCreateRequest == null || userId == null) {
            log.error("请求参数或用户 ID 为空，feedbackCreateRequest={}, userId={}", feedbackCreateRequest, userId);
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Bad request");
        }

        String content = feedbackCreateRequest.getContent();
        if (content == null || content.trim().isEmpty()) {
            log.error("反馈内容为空");
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "The content is empty");
        }

        // 2. 查询用户信息
        Users user = usersMapper.selectById(userId);
        if (user == null) {
            log.error("用户不存在，userId={}", userId);
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "用户不存在");
        }

        // 3. 构造反馈对象
        Feedback feedback = new Feedback();
        feedback.setUser_id(userId);
        feedback.setContent(content.trim());
        feedback.setCreate_time(new Date());
        feedback.setStatus(FeedbackStatusEnum.PENDING.getValue());

        // 4. 插入数据库
        int insertResult = feedbackMapper.insert(feedback);
        log.info("反馈保存结果：{}", insertResult > 0 ? "成功" : "失败");
        return insertResult > 0;
    }





    @Override
    public boolean replyFeedback(Integer feedbackId, FeedbackReplyRequest request, Integer user_id) {
        Feedback feedback = feedbackMapper.selectById(feedbackId);
        if (feedback == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "Feedback not found");
        }
        if(feedback.getStatus().equals(FeedbackStatusEnum.RESOLVED.getValue())){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Feedback is already resolved");

        }
        feedback.setReply(request.getReply());
        feedback.setReply_time(new Date());
        feedback.setAdmin_id(user_id);
        feedback.setStatus(FeedbackStatusEnum.RESOLVED.getValue());
        if (request.getResolvedNotices() != null) {
            feedback.setResolved_notices(request.getResolvedNotices());
        }

        return feedbackMapper.updateById(feedback) > 0;
    }

    @Override
    public List<FeedbackListVO> listAllResolvedFeedbacks(Integer userId) {
        log.info("查询用户已解决反馈开始，userId = {}", userId);
        if (userId == null) {
            log.error("已解决反馈查询失败：userId 为空");
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "User ID is null");
        }

        QueryWrapper<Feedback> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId)
                .eq("status", FeedbackStatusEnum.RESOLVED.getValue());

        List<Feedback> feedbackEntities = feedbackMapper.selectList(queryWrapper);
        if (feedbackEntities == null || feedbackEntities.isEmpty()) {
            log.info("无已解决反馈记录，userId = {}", userId);
            return Collections.emptyList();
        }


        return feedbackEntities.stream().map(feedback -> {
            FeedbackListVO vo = new FeedbackListVO();
            vo.setFeedback_id(feedback.getFeedback_id());
            vo.setStatus(feedback.getStatus());
            vo.setContent(feedback.getContent());
            return vo;
        }).collect(Collectors.toList());
    }

    @Override
    public List<FeedbackListVO> listAllPendingFeedbacks(Integer userId) {
        log.info("查询用户未解决反馈开始，userId = {}", userId);
        if (userId == null) {
            log.error("未解决反馈查询失败：userId 为空");
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "User ID is null");
        }

        QueryWrapper<Feedback> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId)
                .eq("status", FeedbackStatusEnum.PENDING.getValue());

        List<Feedback> feedbackEntities = feedbackMapper.selectList(queryWrapper);
        if (feedbackEntities == null || feedbackEntities.isEmpty()) {
            log.info("无未解决反馈记录，userId = {}", userId);
            return Collections.emptyList();
        }

        return feedbackEntities.stream().map(feedback -> {
            FeedbackListVO vo = new FeedbackListVO();
            vo.setFeedback_id(feedback.getFeedback_id());
            vo.setStatus(feedback.getStatus());
            vo.setContent(feedback.getContent());
            return vo;
        }).collect(Collectors.toList());
    }

    @Override
    public List<FeedbackListVO> adminListAllResolvedFeedbacks() {
        log.info("管理员查看已解决反馈开始");

        // 1. 构造查询条件：只查 resolved 状态
        QueryWrapper<Feedback> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", FeedbackStatusEnum.RESOLVED.getValue()); // 或者使用枚举值

        List<Feedback> feedbackEntities = feedbackMapper.selectList(queryWrapper);

        if (feedbackEntities.isEmpty()) {
            log.info("没有已解决反馈");
            return Collections.emptyList();
        }

        // 3. 封装 VO 返回
        return feedbackEntities.stream().map(feedback -> {
            FeedbackListVO vo = new FeedbackListVO();
            vo.setFeedback_id(feedback.getFeedback_id());
            vo.setStatus(feedback.getStatus());
            vo.setContent(feedback.getContent());
            return vo;
        }).collect(Collectors.toList());
    }

    @Override
    public List<FeedbackListVO> adminListAllPendingFeedbacks() {
        log.info("管理员查看已解决反馈开始");

        // 1. 构造查询条件：只查 resolved 状态
        QueryWrapper<Feedback> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", FeedbackStatusEnum.PENDING.getValue()); // 或者使用枚举值

        List<Feedback> feedbackEntities = feedbackMapper.selectList(queryWrapper);

        if (feedbackEntities.isEmpty()) {
            log.info("没有已解决反馈");
            return Collections.emptyList();
        }

        // 3. 封装 VO 返回
        return feedbackEntities.stream().map(feedback -> {
            FeedbackListVO vo = new FeedbackListVO();
            vo.setFeedback_id(feedback.getFeedback_id());
            vo.setStatus(feedback.getStatus());
            vo.setContent(feedback.getContent());
            return vo;
        }).collect(Collectors.toList());
    }

    @Override
    public FeedbackDetailVO getFeedbackDetailById(Integer feedbackId) {
        if (feedbackId == null || feedbackId <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "No feedback ID provided");
        }

        log.info("开始查询反馈详情，feedbackId = {}", feedbackId);
        Feedback feedback = feedbackMapper.selectById(feedbackId);
        if (feedback == null) {
            log.warn("未找到反馈，ID = {}", feedbackId);
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "Feedback not found");
        }

        // 安全获取用户信息
        Users user = usersMapper.selectById(feedback.getUser_id());
        String username = (user != null && user.getUsername() != null) ? user.getUsername() : "未知用户";

        FeedbackDetailVO vo = new FeedbackDetailVO();
        vo.setFeedback_id(feedback.getFeedback_id());
        vo.setUser_id(feedback.getUser_id());
        vo.setUsername(username);
        vo.setStatus(feedback.getStatus());
        vo.setContent(feedback.getContent() != null ? feedback.getContent() : ""); // 避免 null
        vo.setReply(feedback.getReply() != null ? feedback.getReply() : "");
        vo.setCreate_time(feedback.getCreate_time());
        vo.setReply_time(feedback.getReply_time());

        log.info("反馈详情查询成功");

        return vo;
    }



}
