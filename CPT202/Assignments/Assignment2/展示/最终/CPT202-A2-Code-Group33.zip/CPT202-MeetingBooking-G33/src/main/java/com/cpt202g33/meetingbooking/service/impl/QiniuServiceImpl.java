package com.cpt202g33.meetingbooking.service.impl;

import cn.hutool.core.io.FileUtil;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.service.QiniuService;
import com.cpt202g33.meetingbooking.service.RoomService;
import com.cpt202g33.meetingbooking.service.UsersService;
import com.qiniu.common.QiniuException;
import com.qiniu.storage.BucketManager;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.Region;
import com.qiniu.storage.UploadManager;
import com.qiniu.util.Auth;
import com.qiniu.http.Response;
import com.cpt202g33.meetingbooking.config.QiniuConfig;
import com.qiniu.util.StringMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
public class QiniuServiceImpl implements QiniuService {

    @Autowired
    private QiniuConfig qiniuConfig;

    @Resource
    private UsersMapper usersMapper;


    /**
     * 上传头像流到七牛云
     * @param inputStream 上传文件流
     * @param key 保存到七牛的文件名（带路径）
     * @return 文件访问地址
     * @throws QiniuException 上传失败抛出异常
     */
    public String uploadAvatar(InputStream inputStream, String key) throws QiniuException {
        Configuration config = new Configuration(Region.autoRegion()); // 根据区域选
        config.resumableUploadAPIVersion = Configuration.ResumableUploadAPIVersion.V2;
        UploadManager uploadManager = new UploadManager(config);

        Auth auth = Auth.create(qiniuConfig.getAccessKey(), qiniuConfig.getSecretKey());
        StringMap policy = new StringMap().put("insertOnly", 0); // 允许覆盖上传
        String upToken = auth.uploadToken(qiniuConfig.getBucket(), key, 3600, policy);

        Response response = uploadManager.put(inputStream, key, upToken, null, null);
        if (response.isOK()) {
            // 返回完整的对象存储中的图片链接
            log.info("上传的照片为：{}", "http://" + qiniuConfig.getDomain() + "/" + key);
            return "http://" + qiniuConfig.getDomain() + "/" + key;
        } else {
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "Fail to upload avatar.");
        }
    }


    /**
     * 根据前端传回的二进制图片文件，上传到对象存储
     * @param file 前端传过来的文件
     * @param user_id 用户ID
     * @return
     * @throws Exception
     */
    public String uploadUserAvatar(MultipartFile file, Integer user_id) throws Exception {
        // 判断文件是否为空
        if (file == null || file.isEmpty()) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "上传失败：文件为空");
        }
        // 校验图片是否合规，如果不合规在校验的过程中会抛出异常
        this.validPicture(file);
        // 获取到当前图片的格式后缀
        String suffix = getFileSuffix(file.getOriginalFilename());
        // 根据 user_id_时间戳 的形式，生成存储的图片名
        String key = "avatars/" +  System.currentTimeMillis() + suffix;

        // 转换成输入流上传
        try (InputStream inputStream = file.getInputStream()) {
            // 查找对应用户，将图片地址更改为新上传的图片
            usersMapper.updateAvatarUrl(user_id, "/" + key);
            return this.uploadAvatar(inputStream, key);
        }
    }

    /**
     * 获取文件的格式后缀
     * @param fileName
     * @return
     */
    private String getFileSuffix(String fileName) {
        // 如果文件名不为空，以及包含格式后缀
        if (fileName != null && fileName.contains(".")) {
            // 返回传入的文件的格式后缀
            return fileName.substring(fileName.lastIndexOf("."));
        }
        return ".jpg"; // 默认后缀是.jpg
    }

    /**
     * 删除云对象存储中的图片
     * @param key 图片在对象存储中的路径
     * @return
     */
    @Override
    public boolean deleteAvatar(String key) {
        Configuration config = new Configuration(Region.autoRegion());
        Auth auth = Auth.create(qiniuConfig.getAccessKey(), qiniuConfig.getSecretKey());
        BucketManager bucketManager = new BucketManager(auth, config);

        try {
            // 删除指定桶中路径下的图片
            // 如果没有对应的图片，则删除的时候也会报异常
            bucketManager.delete(qiniuConfig.getBucket(), key);
            return true;
        } catch (QiniuException e) {
            // 删除失败
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "Fail to delete avatar.");
        }
    }

    /**
     * 校验图片
     * @param inputSource
     */
    public void validPicture(Object inputSource) {
        MultipartFile multipartFile = (MultipartFile) inputSource;
        ThrowUtils.throwIf(multipartFile == null, ErrorCode.PARAMS_ERROR, "文件不能为空");
        // 1. 校验文件大小
        long fileSize = multipartFile.getSize();
        final long ONE_M = 1024 * 1024;
        ThrowUtils.throwIf(fileSize > 2 * ONE_M, ErrorCode.PARAMS_ERROR, "文件大小不能超过 2MB");
        // 2. 校验文件后缀
        String fileSuffix = FileUtil.getSuffix(multipartFile.getOriginalFilename());
        // 允许上传的文件后缀列表（或者集合）
        final List<String> ALLOW_FORMAT_LIST = Arrays.asList("jpeg", "png", "jpg", "webp", "JPG", "WEBP", "PNG", "JPEG");
        ThrowUtils.throwIf(!ALLOW_FORMAT_LIST.contains(fileSuffix), ErrorCode.PARAMS_ERROR, "文件类型错误");
    }

    @Override
    public String uploadRoomImage(MultipartFile file, Integer roomId) {
        // 判断文件是否为空
        if (file == null || file.isEmpty()) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "上传失败：文件为空");
        }
        // 校验图片是否合规，如果不合规在校验的过程中会抛出异常
        this.validPicture(file);
        // 获取到当前图片的格式后缀
        String suffix = getFileSuffix(file.getOriginalFilename());
        // 根据 user_id_时间戳 的形式，生成存储的图片名
        String key = "rooms/" + System.currentTimeMillis() + suffix;

        // 转换成输入流上传
        try (InputStream inputStream = file.getInputStream()) {
            // 查找对应用户，将图片地址更改为新上传的图片

            return this.uploadAvatar(inputStream, key);
        } catch (IOException e) {
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "Fail to upload room image.");
        }


    }


}
