package com.cpt202g33.meetingbooking.service.impl;

import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.mutable.Mutable;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.cpt202g33.meetingbooking.config.QiniuConfig;
import com.cpt202g33.meetingbooking.model.dto.RoomQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.*;
import com.cpt202g33.meetingbooking.model.vo.RoomQueryResponse;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import com.cpt202g33.meetingbooking.service.QiniuService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.mapper.BookingMapper;
import com.cpt202g33.meetingbooking.mapper.BuildingMapper;
import com.cpt202g33.meetingbooking.mapper.RoomMapper;
import com.cpt202g33.meetingbooking.mapper.RoomTypeMapper;
import com.cpt202g33.meetingbooking.model.dto.RoomRequest;
import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import com.cpt202g33.meetingbooking.model.vo.RoomDetailVO;
import com.cpt202g33.meetingbooking.model.vo.RoomVO;
import com.cpt202g33.meetingbooking.service.RoomService;

import cn.hutool.core.util.StrUtil;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

/**
 * 会议室服务实现类
 */
@Slf4j
@Service
public class RoomServiceImpl implements RoomService {
    
    @Resource
    private RoomMapper roomMapper;
    
    @Resource
    private RoomTypeMapper roomTypeMapper;
    
    @Resource
    private BuildingMapper buildingMapper;
    
    @Resource
    private BookingMapper bookingMapper;

    @Resource
    private QiniuService qiniuService;
    @Autowired
    private QiniuConfig qiniuConfig;

    /**
     * 获取所有会议室列表
     * @return 会议室列表
     */
    @Override
    public List<RoomVO> listAllRooms() {
        // 1. 获取所有未删除的会议室
        QueryWrapper<Room> queryWrapper = new QueryWrapper<>();
        List<Room> roomList = roomMapper.selectList(queryWrapper);

        // 如果当前没有房间，就返回空的列表
        if (roomList.isEmpty()) {
            return new ArrayList<>();
        }
        
        // 2. 获取所有类型id并查询类型信息
        List<Integer> typeIdList = roomList.stream()
                .map(Room::getType_id)
                .distinct()
                .collect(Collectors.toList());
        
        QueryWrapper<RoomType> typeQueryWrapper = new QueryWrapper<>();
        typeQueryWrapper.in("type_id", typeIdList);
        List<RoomType> roomTypeList = roomTypeMapper.selectList(typeQueryWrapper);
        
        // 将类型ID和类型名称映射
        Map<Integer, String> typeMap = new HashMap<>();
        for (RoomType roomType : roomTypeList) {
            typeMap.put(roomType.getType_id(), roomType.getType_name());
        }
        
        // 3. 获取所有建筑id并查询建筑信息
        List<Integer> buildingIdList = roomList.stream()
                .map(Room::getBuilding_id)
                .distinct()
                .collect(Collectors.toList());
        
        QueryWrapper<Building> buildingQueryWrapper = new QueryWrapper<>();
        buildingQueryWrapper.in("building_id", buildingIdList);
        List<Building> buildingList = buildingMapper.selectList(buildingQueryWrapper);
        
        // 将建筑ID和建筑名称映射
        Map<Integer, String> buildingMap = new HashMap<>();
        for (Building building : buildingList) {
            buildingMap.put(building.getBuilding_id(), building.getName());
        }
        
        // 4. 构建返回数据
        return roomList.stream().map(room -> {
            RoomVO roomVO = new RoomVO();
            // 复制room对象中的相同属性到roomVO
            BeanUtils.copyProperties(room, roomVO);
            String key = room.getImage_url();
            String url = "http://" + qiniuConfig.getDomain() + key;
            roomVO.setImage_url(url);
            // 设置额外需要的属性
            roomVO.setType_name(typeMap.getOrDefault(room.getType_id(), "未知类型"));
            roomVO.setBuilding_name(buildingMap.getOrDefault(room.getBuilding_id(), "未知建筑"));
            return roomVO;
        }).collect(Collectors.toList());
    }

    /**
     * 获取根据筛选条件的搭配的房间信息
     */
    @Override
    public List<RoomQueryResponse> queryListRooms(RoomQueryRequest req) {
        List<RoomQueryResponse> roomQueryResponse = roomMapper.querySelect(req);

        // 将 facilities 字段的 JSON 字符串转换为 List<String>
        for (RoomQueryResponse response : roomQueryResponse) {
            // 将 JSON 字符串转换为 List<String>
            String facilitiesJson = response.getFacilities_string();  // 假设 facilities 是一个 JSON 字符串
            if (facilitiesJson != null && !facilitiesJson.isEmpty()) {
                List<String> facilitiesList = JSON.parseObject(facilitiesJson, new TypeReference<List<String>>() {});
                response.setFacilities(facilitiesList);
            }
        }

        return roomQueryResponse;
    }

    /**
     * 获取会议室详情，包括最近的会议记录
     * @param room_id 会议室ID
     * @return 会议室详情
     */
    @Override
    public RoomDetailVO getRoomDetail(Integer room_id) {
        // 1. 获取会议室信息
        Room room = roomMapper.selectById(room_id);
        if (room == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "会议室不存在");
        }
        
        RoomDetailVO detailedRoomVO = new RoomDetailVO();
        BeanUtils.copyProperties(room, detailedRoomVO);
        
        // 2. 获取会议室类型信息
        RoomType roomType = roomTypeMapper.selectById(room.getType_id());
        if (roomType != null) {
            detailedRoomVO.setType_name(roomType.getType_name());
            // 设置会议室容量信息
            detailedRoomVO.setCapacity(roomType.getCapacity());
        } else {
            detailedRoomVO.setType_name("未知类型");
            detailedRoomVO.setCapacity(0); // 默认值
        }
        
        // 3. 获取建筑信息
        Building building = buildingMapper.selectById(room.getBuilding_id());
        if (building != null) {
            detailedRoomVO.setBuilding_name(building.getName());
        } else {
            detailedRoomVO.setBuilding_name("未知建筑");
        }
        
        // 4. 查询该会议室最近的预订会议（当前时间之后的5个会议）
        QueryWrapper<Bookings> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("room_id", room_id);
        queryWrapper.in("status", "pending", "approved"); // 查询状态为pending或approved的预定
        queryWrapper.between("start_time", LocalDateTime.now(), LocalDateTime.now().plusDays(7)); // 查询七天内的预定
        queryWrapper.orderByAsc("start_time"); // 按开始时间升序排列
        
        List<Bookings> bookings = bookingMapper.selectList(queryWrapper);
        
        // 5. 将Bookings转换为BookingListVO
        List<BookingListVO> recentBookings = bookings.stream().map(booking -> {
            BookingListVO bookingListVO = new BookingListVO();
            BeanUtils.copyProperties(booking, bookingListVO);
            return bookingListVO;
        }).collect(Collectors.toList());
        String key = room.getImage_url();
        String url = "http://" +  qiniuConfig.getDomain() + key;
        detailedRoomVO.setImage_url(url);
        detailedRoomVO.setRecent_bookings(recentBookings);

        return detailedRoomVO;
    }
  
  
    @Override
    public boolean updateRoomInfo(Integer roomId, RoomRequest roomRequest) {
        // 检查房间 ID 是否有效
        if (roomId == null || roomId <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Invalid room ID.");
        }

        // 检查请求体是否为空
        if (roomRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "No update information provided.");
        }

        // 使用 QueryWrapper 查询指定房间 ID 的房间，并且逻辑未删除
        QueryWrapper<Room> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("room_id", roomId)
                .eq("is_deleted", 0);  // 只查没有被逻辑删除的房间

        Room oldRoom = roomMapper.selectOne(queryWrapper);
        // 检查查询结果
        if (oldRoom == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "Room not found.");
        }

        // 校验房间名称是否为空
        String roomName = roomRequest.getRoom_name();
        if (StrUtil.isBlank(roomRequest.getRoom_name())) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Room name cannot be empty.");
        }
        
        // 如果房间名更改了，检查新名称是否已存在
        if (!roomName.equals(oldRoom.getRoom_name())) {
            checkDuplicatedRoom(roomName);
        }

        // 处理房间类型 - 使用type_name
        String typeName = roomRequest.getType_name();
        if (StrUtil.isBlank(typeName)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Room type name cannot be empty.");
        }
        
        // 获取房间类型ID
        Integer roomTypeId = getRoomTypeId(typeName, roomRequest.getCapacity());
        
        // 处理建筑 - 使用building_name
        String buildingName = roomRequest.getBuilding_name();
        if (StrUtil.isBlank(buildingName)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Building name cannot be empty.");
        }
        
        // 获取建筑ID
        Integer buildingId = getBuildingId(buildingName);

        // 创建新的房间实体，并将请求参数拷贝到实体中
        Room newRoom = new Room();
        BeanUtils.copyProperties(roomRequest, newRoom);
        
        // 设置房间ID、类型ID、建筑ID和更新时间
        newRoom.setRoom_id(roomId);
        newRoom.setType_id(roomTypeId);
        newRoom.setBuilding_id(buildingId);
        newRoom.setUpdated_at(new Date());
        
        // 确保facilities不为空，如果为空则提供一个空列表
        if (roomRequest.getFacilities() == null) {
            newRoom.setFacilities(new ArrayList<>());
        } else {
            newRoom.setFacilities(roomRequest.getFacilities());
        }

        // 执行更新操作
        int updateResult = roomMapper.updateById(newRoom);

        // 检查更新结果，保证操作成功
        if (updateResult <= 0) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Failed to update room information.");
        }
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean createRoom(RoomRequest roomRequest, MultipartFile file) {
        // 检查请求体是否为空
        if (roomRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "No room information provided.");
        }

        // 校验房间名称是否为空
        String roomName = roomRequest.getRoom_name();
        if (StrUtil.isBlank(roomRequest.getRoom_name())) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Room name cannot be empty.");
        }
        checkDuplicatedRoom(roomName);

        // 处理房间类型 - 使用type_name
        String typeName = roomRequest.getType_name();
        if (StrUtil.isBlank(typeName)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Room type name cannot be empty.");
        }
        
        // 获取房间类型ID
        Integer roomTypeId = getRoomTypeId(typeName, roomRequest.getCapacity());
        
        // 处理建筑 - 使用building_name
        String buildingName = roomRequest.getBuilding_name();
        if (StrUtil.isBlank(buildingName)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Building name cannot be empty.");
        }
        
        // 获取建筑ID
        Integer buildingId = getBuildingId(buildingName);

        // 创建新的房间实体
        Room newRoom = new Room();
        BeanUtils.copyProperties(roomRequest, newRoom);

        // 设置房间类型ID和建筑ID
        newRoom.setType_id(roomTypeId);
        newRoom.setBuilding_id(buildingId);

        // 处理设施列表
        if (roomRequest.getFacilities() == null) {
            newRoom.setFacilities(new ArrayList<>());
        } else {
            newRoom.setFacilities(roomRequest.getFacilities());
        }

        // 处理图片上传
        if (file == null || file.isEmpty()) {
            String default_avatar = "/rooms/default.jpg";
            newRoom.setImage_url(default_avatar);
        } else {
            // 获取到当前图片的格式后缀
            String suffix = "." + FileUtil.getSuffix(file.getOriginalFilename());
            System.out.println("获取到的图片名字格式后缀是: " + suffix);
            // 根据 user_id_时间戳 的形式，生成存储的图片名
            String key = "/rooms/" + System.currentTimeMillis() + suffix;

            try (InputStream inputStream = file.getInputStream()) {
                // 查找对应用户，将图片地址更改为新上传的图片
                if (key.startsWith("/")) {
                    key = key.substring(1); // 去掉第一个反斜杠
                }
                String url = qiniuService.uploadAvatar(inputStream, key);
                key = "/" + key;
                newRoom.setImage_url(key);
            } catch (Exception e) {
                throw new BusinessException(ErrorCode.PARAMS_ERROR, "Failed to upload avatar.");
            }
        }

        // 设置默认的时间字段
        newRoom.setCreated_at(new Date());
        newRoom.setUpdated_at(new Date());

        // 执行插入操作
        int insertResult = roomMapper.insert(newRoom);

        // 检查插入结果，保证操作成功
        if (insertResult <= 0) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Failed to create room.");
        }

        return true;
    }
    
    /**
     * 根据类型名称获取类型ID，如果不存在则创建新类型
     * @param typeName 类型名称
     * @param capacity 容量（新建类型时使用）
     * @return 类型ID
     */
    private Integer getRoomTypeId(String typeName, Integer capacity) {
        // 根据类型名称查找是否存在
        QueryWrapper<RoomType> typeQueryWrapper = new QueryWrapper<>();
        typeQueryWrapper.eq("type_name", typeName)
                       .eq("is_deleted", 0);
        RoomType existingType = roomTypeMapper.selectOne(typeQueryWrapper);
        
        if (existingType != null) {
            // 如果类型已存在，使用其ID
            return existingType.getType_id();
        } else {
            // 如果类型不存在，创建新类型
            RoomType newType = new RoomType();
            newType.setType_name(typeName);
            
            // 如果提供了容量，则设置容量
            if (capacity != null) {
                newType.setCapacity(capacity);
            } else {
                newType.setCapacity(10); // 设置默认容量
            }
            
            newType.setCreated_at(new Date());
            newType.setUpdated_at(new Date());
            
            // 插入新类型
            roomTypeMapper.insert(newType);
            return newType.getType_id();
        }
    }
    
    /**
     * 根据建筑名称获取建筑ID，如果不存在则创建新建筑
     * @param buildingName 建筑名称
     * @return 建筑ID
     */
    private Integer getBuildingId(String buildingName) {
        // 根据建筑名称查找是否存在
        QueryWrapper<Building> buildingQueryWrapper = new QueryWrapper<>();
        buildingQueryWrapper.eq("name", buildingName)
                          .eq("is_deleted", 0);
        Building existingBuilding = buildingMapper.selectOne(buildingQueryWrapper);
        
        if (existingBuilding != null) {
            // 如果建筑已存在，使用其ID
            return existingBuilding.getBuilding_id();
        } else {
            // 如果建筑不存在，创建新建筑
            Building newBuilding = new Building();
            newBuilding.setName(buildingName);
            newBuilding.setCreated_at(new Date());
            newBuilding.setUpdated_at(new Date());
            
            // 插入新建筑
            buildingMapper.insert(newBuilding);
            return newBuilding.getBuilding_id();
        }
    }
    
    /**
     * 获取所有房间类型
     * @return 房间类型列表
     */
    @Override
    public List<RoomType> listAllRoomTypes() {
        // 查询所有未删除的会议室类型
        QueryWrapper<RoomType> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_deleted", 0);
        queryWrapper.orderByAsc("type_id");
        
        return roomTypeMapper.selectList(queryWrapper);
    }
    
    /**
     * 获取所有建筑物
     * @return 建筑物列表
     */
    @Override
    public List<Building> listAllBuildings() {
        // 查询所有未删除的建筑物
        QueryWrapper<Building> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_deleted", 0);
        queryWrapper.orderByAsc("building_id");
        
        return buildingMapper.selectList(queryWrapper);
    }

    @Override
    public boolean updateRoomImageUrl(Integer roomId, String key) {
        // 检查房间 ID 是否有效
        if (roomId == null || roomId <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Invalid room ID.");
        }

        // 创建更新包装器
        UpdateWrapper<Room> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("room_id", roomId)
                .set("image_url", key);

        // 执行更新操作
        int updateResult = roomMapper.update(null, updateWrapper);

        // 检查更新结果，保证操作成功
        if (updateResult <= 0) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Failed to update room image URL.");
        }
        return true;

    }

    @Override
    public boolean changeRoomImage(Integer roomId, String url) {
        // 参数校验
        if (roomId == null || StrUtil.isBlank(url)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "roomId 或 url 不能为空");
        }

        // 1. 查询原来的房间记录
        Room room = roomMapper.selectById(roomId);
        if (room == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND_ERROR, "房间不存在");
        }

        String oldKey = room.getImage_url();
        if (!oldKey.equals("/rooms/default.jpg")) {
            if (oldKey.startsWith("/")) {
                oldKey = oldKey.substring(1); // 去掉开头的 /
            }
            qiniuService.deleteAvatar(oldKey);

        }

        if (url != null && url.contains("/")) {
            URI uri = null;
            try {
                uri = new URI(url);
            } catch (URISyntaxException e) {
                throw new BusinessException(ErrorCode.SYSTEM_ERROR, "Invalid image URL.");
            }
            String key = uri.getPath();
            this.updateRoomImageUrl(roomId, key);
        }else {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Failed to upload image file.");
        }

        return true;
    }

    @Override
    public boolean deleteRoom(Integer roomId) {
        // 1. 检查房间是否存在
        Room room = roomMapper.selectById(roomId);
        if (room == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Room not found.");
        }

        // 2. 查询与该房间有关联且已经结束的预定记录
        List<Bookings> bookings = bookingMapper.selectList(new QueryWrapper<Bookings>()
                .eq("room_id", roomId) // 查找该房间的预定
                .gt("end_time", LocalDateTime.now()) // 查找已结束的预定
                .eq("is_deleted", 0)); // 确保预定没有被删除

        // 如果有已结束的预定，则不能删除房间
        if (!bookings.isEmpty()) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Cannot delete room because there are bookings that haven't done.");
        }

        // 3. 删除房间
        int result = roomMapper.deleteById(roomId);

        // 检查删除是否成功
        if (result <= 0) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "Failed to delete room.");
        }

        return true;
    }


    private void checkDuplicatedRoom(String roomName) {

        // 查询数据库，检查是否已经存在同名房间
        QueryWrapper<Room> roomQuery = new QueryWrapper<>();
        roomQuery.eq("room_name", roomName)
                .eq("is_deleted", 0);  // 只查未被删除的房间
        Room existingRoom = roomMapper.selectOne(roomQuery);

        // 如果存在同名房间，则抛出异常
        if (existingRoom != null) {
            String conflictInfo = String.format("room_id=%d, name=%s, building_id=%d",
                    existingRoom.getRoom_id(),
                    existingRoom.getRoom_name(),
                    existingRoom.getBuilding_id());

            log.warn("Room name conflict: {}", conflictInfo);
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Room name already exists");
        }
    }

    // 校验房间类型和楼栋是否有效
    private void validateRoomTypeAndBuilding(Integer roomTypeId, Integer buildingId) {
        // 验证房间类型
        QueryWrapper<RoomType> roomTypeQuery = new QueryWrapper<>();
        roomTypeQuery.eq("type_id", roomTypeId);
        RoomType roomType = roomTypeMapper.selectOne(roomTypeQuery);
        if (roomType == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Invalid room type.");
        }

        // 验证楼栋
        QueryWrapper<Building> buildingQuery = new QueryWrapper<>();
        buildingQuery.eq("building_id", buildingId);
        Building building = buildingMapper.selectOne(buildingQuery);
        if (building == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Invalid building.");
        }
    }
}
