package com.cpt202g33.meetingbooking.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.EmailSender;
import com.cpt202g33.meetingbooking.common.RateLimiter;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.config.QiniuConfig;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.dto.user.UserQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.enums.UsersRoleEnum;
import com.cpt202g33.meetingbooking.model.vo.BookingDetailVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import com.cpt202g33.meetingbooking.model.vo.user.LoginUserVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserBookingVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import com.cpt202g33.meetingbooking.service.BookingService;
import com.cpt202g33.meetingbooking.service.QiniuService;
import com.cpt202g33.meetingbooking.service.UsersService;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
@Slf4j
public class UsersServiceImpl extends ServiceImpl<UsersMapper, Users>
        implements UsersService {

    @Resource
    UsersMapper usersMapper;

    // 邮件发送
    @Resource
    EmailSender sender;

    // 验证码请求频率校验
    @Resource
    RateLimiter rateLimiter;

    // 七牛图片处理
    @Resource
    QiniuService qiniuService;
    
    // 注入BookingService
    @Resource
    BookingService bookingService;

    // 使用 Caffeine 缓存验证码（key=邮箱，value=验证码，3分钟过期）
    private final Cache<String, String> LOCAL_CACHE = Caffeine.newBuilder()
            .expireAfterWrite(3, TimeUnit.MINUTES)
            .maximumSize(10_000) // 防止内存溢出
            .build();
    @Autowired
    private QiniuConfig qiniuConfig;

    /**
     * 用户注册
     * @param username   用户账户
     * @param password  用户密码
     * @param email
     * @param code
     * @param file
     * @return
     */
    // 如果你想对该方法加权限校验可以直接写一个注解
    // @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @Override
    public UserVO userRegister(String username, String password, String email, String code, MultipartFile file) throws Exception {
        // 校验参数
        if (StrUtil.hasBlank(username, password, email, code)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Missing inputs");
        }

        // 密码长度小于8，丢异常
        if (password.length() < 8 ) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户密码过短");
        }

        // 验证码校验
        boolean verifyCode = this.verifyEmailCode(email, code);
        if (!verifyCode) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "验证码错误");
        }

        // 检查用户账号是否和数据库中已有的重复
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        // 不允许有重复的用户名，用户账号或者邮箱存在重复
        queryWrapper
                .eq("username", username)
                .or()
                .eq("email", email);
        long count = this.baseMapper.selectCount(queryWrapper);
        // 如果此时数据库中已经有了该对象的信息
        if (count > 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "账号/邮箱重复");
        }
        // 密码一定要加密
        String encryptPassword = getEncryptPassword(password);

        // 插入数据到数据库中
        Users user = new Users();
        user.setUsername(username);
        user.setPassword(encryptPassword);
        user.setEmail(email);
        user.setRole(UsersRoleEnum.USER.getValue());
        int result = usersMapper.insert(user);
        // 如果插入失败，result 会是 0
        if (result == 0) {
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "注册失败，数据库错误");
        }

        // 从数据库中重新将当前用户查询出来
        QueryWrapper<Users> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("username", username);
        Users currentRegisterUser = this.baseMapper.selectOne(queryWrapper1);
        // 获取当前新注册用户的 id
        int user_id = currentRegisterUser.getUser_id();

        // 判断图片是否为空，如果用户没有在注册的时候选择上传头像，则直接使用默认头像
        if (file == null || file.isEmpty()) {
            // 注册成功之后删除缓存的验证码
            LOCAL_CACHE.invalidate(email);
            String default_avatar = "/avatars/default.jpg";
            currentRegisterUser.setAvatar_url(default_avatar);
            // 返回脱敏后的用户信息
            UserVO returnUser = new UserVO();
            BeanUtil.copyProperties(currentRegisterUser, returnUser);
            // 返回对应的用户id
            return returnUser;
        }

        // 获取到当前图片的格式后缀
        String suffix = "." + FileUtil.getSuffix(file.getOriginalFilename());
        System.out.println("获取到的图片名字格式后缀是: " + suffix);
        // 根据 user_id_时间戳 的形式，生成存储的图片名
        String key = "/avatars/" + System.currentTimeMillis() + suffix;
        // 将图片上传到对象存储
        String url = qiniuService.uploadUserAvatar(file, user_id);
        // 将图片在云存储中的信息更新给当前注册的用户
        usersMapper.updateAvatarUrl(user_id, key);

        // 注册成功之后删除缓存的验证码
        LOCAL_CACHE.invalidate(email);
        // 返回脱敏后的用户信息
        UserVO returnUser = new UserVO();
        BeanUtil.copyProperties(currentRegisterUser, returnUser);
        returnUser.setAvatar_url(url);
        // 返回对应的用户信息
        return returnUser;
    }

    /**
     * 请求并发送验证码
     * @param email 邮箱
     * @param ip 当前请求发送的 ip
     */
    public void askCode(String email, String ip) {

        // 验证是不是一分钟内请求了多次，通过记录ip地址请求的次数来限制
        if (!rateLimiter.allowRequest(ip)) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "请求过于频繁");
        }

        // 生成6位随机验证码
        Random random = new Random();
        int code = random.nextInt(899999) + 100000;

        // 直接发送邮件
        sendEmail(email, String.valueOf(code));

        // 存入 Caffeine 缓存（3分钟过期）
        LOCAL_CACHE.put(email, String.valueOf(code));

    }

    /**
     * 直接向目标邮箱发信
     * @param email 邮箱
     * @param code 验证码
     */
    private void sendEmail(String email, String code) {
        String subject = "Online Meeting Room Booking System Captcha";
        String content = String.format("Your current Captcha is: %s (This Captcha is valid for three minutes!)", code);
        // 实际发送邮件的逻辑
        sender.sendSimpleMail(email, subject, content);
        log.info("Email has been send to {}: {}", email, content);
    }

    /**
     * 验证前端传回的请求中的验证码是否和本地缓存中的相同
     * @param email
     * @param userInputCode
     * @return
     */
    private boolean verifyEmailCode(String email, String userInputCode) {
        // 检查本地存储中是否有对应邮箱的验证码
        String storedCode = checkCacheCode(email);
        // 没有在本地缓存中找到提供的邮箱对应的验证码
        if (storedCode == null) {
            return false; // 验证码不存在或已过期
        }
        // 检查是否和输入的验证码相同
        return storedCode.equals(userInputCode);
    }

    /**
     * 测试用的，看当前本地缓存里有没有对应的验证码
     * @param email
     * @return 缓存的验证码
     */
    @Override
    public String checkCacheCode(String email) {
        return LOCAL_CACHE.getIfPresent(email);
    }

    /**
     * 用户登录，可以是 username 或者 email
     * @param userAccount  用户可以用 username 登录或者用 email 登录
     * @param password 用户密码
     * @param request
     * @return
     */
    @Override
    public LoginUserVO userLogin(String userAccount, String password, HttpServletRequest request) {
        // 1. 校验
        if (StrUtil.hasBlank(userAccount, password)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "参数为空");
        }
        if (userAccount.length() < 4) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户账号错误");
        }
        if (password.length() < 8) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户密码错误");
        }

        // 对用户传递的密码进行加密
        String encryptPassword = getEncryptPassword(password);

        // 查询数据库中的用户是否存在
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        // 这里的 QueryWrapper 就是查询条件，这里的使用场景需要 username 和 password 同时对应数据库中的信息
        queryWrapper.eq("username", userAccount)
                .or()
                .eq("email", userAccount);
        // 根据提供的登录账户，在数据库中查找有没有 username 或者 email 相等的用户信息
        Users user = this.baseMapper.selectOne(queryWrapper);
        // 没有查到提供的 username 或者 email 的用户，则抛出异常
        if (user == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "username/email or password is incorrect");
        }
        // 验证密码（需加密比对）
        // 如果密码不相同，则抛出异常
        // 注意，这里不能直接说你的密码错了，可能用户只是猜测了一个账户。
        if (!encryptPassword.equals(user.getPassword())) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "username/email or password is incorrect");
        }

        // 保存用户的登录态
        // 检查现有会话
        // false表示不自动创建新Session
        HttpSession oldSession = request.getSession(false);
        if (oldSession != null) {
            // 使现有会话失效
            oldSession.invalidate();
        }
        
        // 创建新会话
        HttpSession session = request.getSession(true); // 确保创建新session
        session.setAttribute(UserConstant.USER_LOGIN_STATE, user);
        return this.getLoginUserVO(user);
    }

    /**
     * 用户注销
     * @param request
     * @return
     */
    @Override
    public boolean userLogout(HttpServletRequest request) {
        // 判断是否已经登录
        Object userObj = request.getSession().getAttribute(UserConstant.USER_LOGIN_STATE);
        if (userObj == null) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "未登录");
        }
        // 移除登录态
        request.getSession().removeAttribute(UserConstant.USER_LOGIN_STATE);
        return true;
    }

    /**
     * 盐值 + md5 加密密码
     * @param password
     * @return
     */
    @Override
    public String getEncryptPassword(String password) {
        // 加盐，混淆密码
        final String SALT = "group33";
        return DigestUtils.md5DigestAsHex((SALT + password).getBytes());
    }

    /**
     * 获取当前登录用户
     * @param request
     * @return
     */
    @Override
    public Users getLoginUser(HttpServletRequest request) {
        // 判断是否已经登录，从请求中检查session获取对应的信息
        Object userObj = request.getSession().getAttribute(UserConstant.USER_LOGIN_STATE);
        // 将取出的内容转换为 Users 类
        Users currentUser = (Users) userObj;
        if (currentUser == null || currentUser.getUser_id() == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        // 从数据库中查询（追求性能的话可以注释，直接返回上述结果）
        Integer userId = currentUser.getUser_id();
        currentUser = this.getById(userId);
        if (currentUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        return currentUser;
    }

    /**
     * 获取脱敏后的用户信息
     *
     * @param user 用户
     * @return 脱敏后的用户信息
     */
    @Override
    public LoginUserVO getLoginUserVO(Users user) {
        if (user == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "No user has been found");
        }

        // 判断当前的用户名是否没有在数据库中被注册
        QueryWrapper<Users> usernameExist = new QueryWrapper<>();
        usernameExist.eq("username", user.getUsername());
        long count = this.baseMapper.selectCount(usernameExist);

        if (count == 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "No user has been found");
        }

        LoginUserVO loginUserVO = new LoginUserVO();
        String key = user.getAvatar_url();
        String url = "http://" + qiniuConfig.getDomain() + key;
        user.setAvatar_url(url);
        if(user.getIs_locked() == 0){
            loginUserVO.setIs_locked(false);
        }else{
            loginUserVO.setIs_locked(true);
        }
        // 将传入的 User 中的信息，复制到 LoginUserVO 对象中，这中间会自动匹配对应的属性，对应不上的属性就会设置为空
        // 这样就不需要再单独一个一个设置相应的信息了
        BeanUtil.copyProperties(user, loginUserVO);
        return loginUserVO;
    }

    /**
     * 获得脱敏后的用于用户列表的用户信息
     *
     * @param user
     * @return
     */
    @Override
    public UserVO getUserVO(Users user) {
        if (user == null) {
            return null;
        }
        UserVO userVO = new UserVO();
        BeanUtil.copyProperties(user, userVO);
        return userVO;
    }

    /**
     * 获取脱敏后的用户列表
     *
     * @param userList
     * @return
     */
    @Override
    public List<UserVO> getUserVOList(List<Users> userList) {
        if (CollUtil.isEmpty(userList)) {
            return new ArrayList<>();
        }
        return userList.stream()
                .map(this::getUserVO)
                .collect(Collectors.toList());
    }


    /**
     * 按页查询用户，并且搭配模糊查询
     * @param userQueryRequest
     * @return
     */
    @Override
    public QueryWrapper<Users> getQueryWrapper(UserQueryRequest userQueryRequest) {
        if (userQueryRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "请求参数为空");
        }
        String username = userQueryRequest.getUsername();
        String email = userQueryRequest.getEmail();
        String role = userQueryRequest.getRole();
        String sort_field = userQueryRequest.getSort_field();
        String sort_order = userQueryRequest.getSort_order();
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        // like 模糊查询
        queryWrapper.like(StrUtil.isNotBlank(role), "role", role);
        queryWrapper.like(StrUtil.isNotBlank(username), "username", username);
        queryWrapper.like(StrUtil.isNotBlank(email), "email", email);
        /**
         *  boolean condition, 排序条件必须非空
         *  boolean isAsc, 是不是按照升序
         *  R column 按照哪一列的值进行排序
         */
        queryWrapper.orderBy(StrUtil.isNotEmpty(sort_field), sort_order.equals("ascend"), sort_field);
        return queryWrapper;
    }

    /**
     * 修改密码
     * @param newPassword
     * @param code
     */
    @Override
    public String resetPassword(String newPassword, String code, String email, HttpServletRequest request) {
        // 如果验证码不匹配，抛出异常
        if (!checkCacheCode(email).equals(code)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }

        // 修改密码
        // 通过邮箱查找对应的用户
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("email", email);
        Users user = this.baseMapper.selectOne(queryWrapper);
        // 没有查找到对应邮箱的用户，不能修改密码
        if (user == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "No corresponding user found");
        }

        // LLK: 用户忘记密码的情况下是没有登录的，并且已经验证过邮箱了，所以不需要判断当前登录的用户是否和要修改密码的用户是同一个人，因此注释掉了。
        // System.out.println("判断对错 " + !Objects.equals(user.getUsername(), this.getLoginUser(request).getUsername()));
        // // 如果登录的人不是当前的用户或者身份不是管理员的话，也不能修改密码
        // if (!Objects.equals(user.getUsername(), this.getLoginUser(request).getUsername())) {
        //     if (!user.getRole().equals(UserConstant.ADMIN_ROLE)) {
        //         throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "You are not allowed to change the password");
        //     }
        // }

        // 校验新密码是否和原密码相同，相同的话不能修改
        String encodedNewPassword = getEncryptPassword(newPassword);
        if (user.getPassword().equals(encodedNewPassword)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Same  with old password!");
        }

        // 只有在新密码与老密码不相同的时候才能修改
        boolean success = this.update().eq("email", email)
                .set("password", encodedNewPassword)
                .update();

        return success ? null : "Unknown error, please contact administrator";
    }

    /**
     * 更改名字
     * @param oldUsername
     * @param newUsername
     * @param request
     * @return 最终返回新的用户信息
     */
    @Override
    public UserVO changeUsername(String oldUsername, String newUsername, HttpServletRequest request) {
        // 获取到当前请求修改的用户的信息
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", oldUsername);
        Users user = this.baseMapper.selectOne(queryWrapper);
        // 获取当前登录的用户信息
        Users loginUser = this.getLoginUser(request);
        // 当前用户未登录
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR, "Please login first");
        }

        // 判断当前的用户名是否没有在数据库中被注册
        QueryWrapper<Users> usernameExist = new QueryWrapper<>();
        usernameExist.eq("username", newUsername);
        long count = this.baseMapper.selectCount(usernameExist);
        // 如果从 users 表中查到了该用户名的信息，则拒绝注册
        if (count > 0) {
            throw new BusinessException(ErrorCode.FORBIDDEN_ERROR, "The username has already been registered");
        }

        // 首先判断是不是管理员，如果不是管理员，则不能修改除了自己之外的人的名字
        if (!loginUser.getRole().equals("ADMIN")) {
            // 判断当前申请求改名字的人的名字是否和被修改的名字对应的用户是同一个人
            if (!Objects.equals(user.getUsername(), loginUser.getUsername())) {
                throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "You are not allowed to change the username");
            }
        } else {
            // 如果是管理员，只能更改自己以及所有非管理员的名字
            if (Objects.equals(user.getRole(), "ADMIN") && !user.getUsername().equals(loginUser.getUsername())) {
                throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "You are not allowed to change the username");
            }
        }

        // 条件允许，将新名字替换为旧名字
        user.setUsername(newUsername);
        // 根据 user_id 更改用户信息
        boolean result = this.updateById(user);
        // 如果更改成功 result 应该是 true
        ThrowUtils.throwIf(!result, ErrorCode.OPERATION_ERROR);
        UserVO returnUser = new UserVO();
        BeanUtil.copyProperties(user, returnUser);
        return returnUser;
    }

    /**
     * 修改邮箱密码
     * @param oldEmail
     * @param newEmail
     * @param code
     * @param request
     * @return
     */
    @Override
    public UserVO changeEmail(String oldEmail, String newEmail, String code, HttpServletRequest request) {
        // 获取当前登录的用户信息
        Users loginUser = this.getLoginUser(request);
        // 当前用户未登录
        if (loginUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR, "Please login first");
        }

        // 和新邮箱获取到的验证码匹配，如果不匹配抛出异常
        if (!checkCacheCode(newEmail).equals(code)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }

        // 通过修改前的邮箱获取到当前请求修改的用户的信息
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("email", oldEmail);
        Users user = this.baseMapper.selectOne(queryWrapper);


        // 判断新输入的邮箱是否没有在数据库中被注册
        QueryWrapper<Users> emailExist = new QueryWrapper<>();
        emailExist.eq("email", newEmail);
        long count = this.baseMapper.selectCount(emailExist);
        // 如果从 users 表中查到了该邮箱的信息，则拒绝注册
        if (count > 0) {
            throw new BusinessException(ErrorCode.FORBIDDEN_ERROR, "The email has already been registered");
        }


        // 首先判断是不是管理员，如果不是管理员，则不能修改除了自己之外的人的名字
        if (!loginUser.getRole().equals("ADMIN")) {
            // 判断当前申请求改名字的人的名字是否和被修改的名字对应的用户是同一个人
            if (!Objects.equals(user.getUsername(), loginUser.getUsername())) {
                throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "You are not allowed to change the username");
            }
        } else {
            // 如果是管理员，只能更改自己以及所有非管理员的名字
            if (Objects.equals(user.getRole(), "ADMIN") && !user.getUsername().equals(loginUser.getUsername())) {
                throw new BusinessException(ErrorCode.NO_AUTH_ERROR, "You are not allowed to change the username");
            }
        }

        // 条件允许，将新邮件替换旧邮箱
        user.setEmail(newEmail);
        // 根据 user 更改用户信息
        boolean result = this.updateById(user);
        // 如果更改成功 result 应该是 true
        ThrowUtils.throwIf(!result, ErrorCode.OPERATION_ERROR);
        UserVO returnUser = new UserVO();
        BeanUtil.copyProperties(user, returnUser);
        return returnUser;
    }

    @Override
    public void deleteUser(Integer userId, HttpServletRequest request) {
        Object currentUserObj = request.getSession().getAttribute(UserConstant.USER_LOGIN_STATE);
        Users currentUser = (Users) currentUserObj;
        Integer currentId = currentUser.getUser_id();
        if (!Objects.equals(userId, currentId)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "Invalid user id.");
        }
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);

        boolean isValid =  usersMapper.selectCount(queryWrapper) > 0;

        if (!isValid) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "User not found.");
        }
        usersMapper.deleteById(userId);
    }
}
