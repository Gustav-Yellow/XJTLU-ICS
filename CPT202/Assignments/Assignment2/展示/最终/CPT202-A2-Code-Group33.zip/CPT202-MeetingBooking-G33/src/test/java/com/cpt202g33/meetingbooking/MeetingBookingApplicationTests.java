package com.cpt202g33.meetingbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class MeetingBookingApplicationTests {

    @Test
    void contextLoads() {
    }

}
