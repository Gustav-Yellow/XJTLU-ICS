package com.cpt202g33.meetingbooking.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

class EmailValidatorTest {

    @Test
    void testValidEmails() {
        assertTrue(EmailValidator.isValidEmail("user@example.com"));
        assertTrue(EmailValidator.isValidEmail("user.name+tag+sorting@example.com"));
        assertTrue(EmailValidator.isValidEmail("x@example.co.uk"));
        assertTrue(EmailValidator.isValidEmail("customer/department=shipping@example.com"));
        assertTrue(EmailValidator.isValidEmail("user_name@example.travel"));
        assertTrue (EmailValidator.isValidEmail("user@sub-domain.example.com"));
    }

    @Test
    void testInvalidEmails() {
        assertFalse(EmailValidator.isValidEmail(null));            // null
        assertFalse(EmailValidator.isValidEmail(""));              // empty
        assertFalse(EmailValidator.isValidEmail("plainaddress"));  // missing @
        assertFalse(EmailValidator.isValidEmail("@no-local-part.com"));
        assertFalse(EmailValidator.isValidEmail("user@.invalid.com"));
        assertFalse(EmailValidator.isValidEmail("user@invalid..com"));
        assertFalse(EmailValidator.isValidEmail("user@@example.com"));
        assertFalse(EmailValidator.isValidEmail("user@ example.com")); // space
    }
}
