package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.aop.AuthInterceptor;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.BookingListWithNameVO;
import com.cpt202g33.meetingbooking.service.BookingService;
import com.cpt202g33.meetingbooking.service.UsersService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Collections;

import static com.cpt202g33.meetingbooking.constant.UserConstant.USER_LOGIN_STATE;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AdminBookingController.class)
@EnableAspectJAutoProxy
@Import({AuthInterceptor.class})
public class AdminBookingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookingService bookingService;

    @MockBean
    private UsersService usersService;

    // mock 掉 Mapper
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.BookingMapper bookingMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.BuildingMapper buildingMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.FeedbackMapper feedbackMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.RoomMapper roomMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.RoomTypeMapper roomTypeMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.UsersMapper usersMapper;

    @Test
    void testGetAllBookingList() throws Exception {
        BookingListWithNameVO vo = new BookingListWithNameVO();
        LocalDateTime now = LocalDateTime.now();

        vo.setRoom_id(123);
        vo.setRoom_name("TestRoom");
        vo.setBooking_id(123);
        vo.setUser_id(123);
        vo.setCreated_at(now);

        // mock 数据
        Mockito.when(bookingService.getAllBookingList("all"))
                .thenReturn(Collections.singletonList(vo));

        mockMvc.perform(post("/admin/bookings/list").param("status","all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data[0].booking_id").value(123))
                .andExpect(jsonPath("$.data[0].user_id").value(123))
                .andExpect(jsonPath("$.data[0].room_id").value(123))
                .andExpect(jsonPath("$.data[0].room_name").value("TestRoom"));
    }

    // helper to mock logged-in admin
    private MockHttpSession adminSession() {
        Users admin = new Users();
        admin.setUser_id(42);
        MockHttpSession session = new MockHttpSession();
        session.setAttribute(UserConstant.USER_LOGIN_STATE, admin);
        return session;
    }

    private MockHttpSession userSession() {
        Users user = new Users();
        user.setUser_id(66);
        MockHttpSession session = new MockHttpSession();
        session.setAttribute(UserConstant.USER_LOGIN_STATE, user);
        return session;
    }

    @Test
    void testGetBookingWithNameByBookingID() throws Exception {
        BookingListWithNameVO vo = new BookingListWithNameVO();
        vo.setBooking_id(123);
        vo.setRoom_name("Conf Room");
        Mockito.when(bookingService.getBookingWithNameByBookingID(123)).thenReturn(vo);

        mockMvc.perform(get("/admin/bookings/{bookingId}", 123)
                        .session(adminSession()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data.booking_id").value(123))
                .andExpect(jsonPath("$.data.room_name").value("Conf Room"));
    }

    @Test
    void testApproveBooking_success() throws Exception {
        Mockito.when(bookingService.approveBooking(
                Mockito.eq(1),
                Mockito.eq("OK"),
                Mockito.eq(42),
                Mockito.any(LocalDateTime.class))
        ).thenReturn(true);

        mockMvc.perform(post("/admin/bookings/{bookingId}/approve", 1)
                        .param("adminReply", "OK")
                        .session(adminSession()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data").value(true));
    }

    @Test
    void testRejectBooking_success() throws Exception {
        Mockito.when(bookingService.rejectBooking(Mockito.eq(2),
                        Mockito.eq("Nope"), Mockito.eq(42), Mockito.any(LocalDateTime.class)))
                .thenReturn(true);

        mockMvc.perform(post("/admin/bookings/{bookingId}/reject", 2)
                        .param("adminReply", "Nope")
                        .session(adminSession()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data").value(true));
    }

    @Test
    void testRejectBooking_accessDenied() throws Exception {
        Mockito.when(bookingService.rejectBooking(Mockito.eq(2),
                        Mockito.eq("Nope"), Mockito.eq(42), Mockito.any(LocalDateTime.class)))
                .thenReturn(false);

        mockMvc.perform(post("/admin/bookings/{bookingId}/reject", 2)
                        .param("adminReply", "Nope")
                        .session(adminSession()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(6001))
                .andExpect(jsonPath("$.message").value("Access denied"));
    }
}
