package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.model.dto.FeedbackReplyRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.FeedbackListVO;
import com.cpt202g33.meetingbooking.service.FeedbackService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AdminFeedbackController.class)
class AdminFeedbackControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper om;

    @MockBean FeedbackService feedbackService;

    // mock 掉 Mapper
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.BookingMapper bookingMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.BuildingMapper buildingMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.FeedbackMapper feedbackMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.RoomMapper roomMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.RoomTypeMapper roomTypeMapper;
    @MockBean
    private com.cpt202g33.meetingbooking.mapper.UsersMapper usersMapper;

    // 模拟登录的 Admin 用户
    private MockHttpSession adminSession() {
        Users u = new Users();
        u.setUser_id(99);
        u.setRole(UserConstant.ADMIN_ROLE);
        MockHttpSession s = new MockHttpSession();
        s.setAttribute(UserConstant.USER_LOGIN_STATE, u);
        return s;
    }

    @Test
    void testGetAllResolvedFeedbacks() throws Exception {
        FeedbackListVO vo = new FeedbackListVO();
        vo.setFeedback_id(1);
        Mockito.when(feedbackService.adminListAllResolvedFeedbacks())
                .thenReturn(Collections.singletonList(vo));

        mockMvc.perform(get("/admin/feedback/allResolved")
                        .session(adminSession()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data[0].feedback_id").value(1));
    }

    @Test
    void testGetAllPendingFeedbacks() throws Exception {
        FeedbackListVO vo = new FeedbackListVO();
        vo.setFeedback_id(2);
        Mockito.when(feedbackService.adminListAllPendingFeedbacks())
                .thenReturn(Collections.singletonList(vo));

        mockMvc.perform(get("/admin/feedback/allPending")
                        .session(adminSession()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data[0].feedback_id").value(2));
    }

    @Test
    void testReplyFeedback_success() throws Exception {
        FeedbackReplyRequest req = new FeedbackReplyRequest();
        req.setReply("OK");
        req.setResolvedNotices("Done");

        Mockito.when(feedbackService.replyFeedback(5, req, 99))
                .thenReturn(true);

        mockMvc.perform(post("/admin/feedback/{feedbackId}/reply", 5)
                        .session(adminSession())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(om.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data").value(true));
    }

    @Test
    void testReplyFeedback_badRequest() throws Exception {
        // missing reply field
        FeedbackReplyRequest req = new FeedbackReplyRequest();
        mockMvc.perform(post("/admin/feedback/{feedbackId}/reply", 5)
                        .session(adminSession())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(om.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(400))
                .andExpect(jsonPath("$.message").value("Bad request"));
    }
}
