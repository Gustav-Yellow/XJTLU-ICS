package com.cpt202g33.meetingbooking.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cpt202g33.meetingbooking.MeetingBookingApplication;
import com.cpt202g33.meetingbooking.config.QiniuConfig;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.mapper.BookingMapper;
import com.cpt202g33.meetingbooking.mapper.RoomMapper;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.dto.AdminUserAddUserRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.BookingDetailVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserBookingVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import com.cpt202g33.meetingbooking.service.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

//@SpringBootTest(classes = MeetingBookingApplication.class)
@ExtendWith(MockitoExtension.class)
public class AdminUserServiceImplTest {
    @InjectMocks
    private AdminUserServiceImpl adminUserService;

    @Mock
    private UsersMapper usersMapper;

    @Mock
    private BookingMapper bookingMapper;

    @Mock
    private RoomMapper roomMapper;

    @Mock
    private BookingService bookingService;
    @Mock
    private QiniuConfig qiniuConfig;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testLockUser_alreadyLocked() {
        Users user = new Users();
        user.setUser_id(1);
        user.setIs_locked(1);

        when(usersMapper.selectCount(any(QueryWrapper.class))).thenReturn(1L);
        when(usersMapper.selectOne(any(QueryWrapper.class))).thenReturn(user);

        BusinessException ex = assertThrows(BusinessException.class, () -> adminUserService.lockUser(1));
        assertTrue(ex.getMessage().contains("already locked"));
    }

    @Test
    void testUnlockUser_successUnlock() {
        Users user = new Users();
        user.setUser_id(1);
        user.setIs_locked(1);

        when(usersMapper.selectCount(any(QueryWrapper.class))).thenReturn(1L);
        when(usersMapper.selectOne(any(QueryWrapper.class))).thenReturn(user);

        adminUserService.unlockUser(1);

        assertEquals(0, user.getIs_locked());
        verify(usersMapper).updateById(user);
    }

    @Test
    void testGetUserLists_success() {
        // 准备模拟返回的用户数据
        UserVO userVO = new UserVO();
        userVO.setUsername("testUser");
        userVO.setAvatar_url("/avatar/test.png");  // 模拟数据库返回的是 key，不是完整 url

        // mock 方法行为
        when(usersMapper.getUserWithBookingCount()).thenReturn(Collections.singletonList(userVO));
        when(qiniuConfig.getDomain()).thenReturn("cdn.qiniu.com/");

        // 调用 service 方法
        List<UserVO> result = adminUserService.getUserLists();

        // 验证结果
        assertEquals(1, result.size());
        assertEquals("testUser", result.get(0).getUsername());
        assertEquals("http://cdn.qiniu.com//avatar/test.png", result.get(0).getAvatar_url());
    }

    @Test
    void testGetUser_success(){
        Integer userId = 1;

        // 模拟数据库中存在的用户
        Users user = new Users();
        user.setUser_id(userId);
        user.setUsername("testUser");
        user.setIs_locked(0);
        user.setAvatar_url("/avatar/test.png");

        // 模拟预定记录
        List<BookingListVO> bookingList = new ArrayList<>();
        BookingListVO booking = new BookingListVO();
        booking.setRoom_name("TestRoom");
        bookingList.add(booking);

        // mock 方法
        when(usersMapper.selectCount(any(QueryWrapper.class))).thenReturn(1L);
        when(usersMapper.selectOne(any(QueryWrapper.class))).thenReturn(user);
        when(qiniuConfig.getDomain()).thenReturn("cdn.qiniu.com/");
        when(bookingService.getFutureBookingsByUserId(userId)).thenReturn(bookingList);

        // 调用方法
        UserBookingVO result = adminUserService.getUser(userId);

        // 断言结果
        assertEquals("testUser", result.getUsername());
//        assertEquals(false, result.getIs_Locked());
        assertEquals("http://cdn.qiniu.com//avatar/test.png", result.getAvatar_url());
        assertEquals(1, result.getBooking_history().size());
        assertEquals("TestRoom", result.getBooking_history().get(0).getRoom_name());
    }

    @Test
    void testAddUser_success() {
        AdminUserAddUserRequest request = new AdminUserAddUserRequest();
        request.setUserName("newUser");
        request.setPassword("strongPass123");
        request.setEmail("new@example.com");
        request.setRole("user");
        request.setAvatar_url("/avatar.png");

        // 模拟用户不存在
        when(usersMapper.selectCount(any(QueryWrapper.class))).thenReturn(0L);
        // 模拟加密密码
        UsersServiceImpl usersService = mock(UsersServiceImpl.class);
        when(usersService.getEncryptPassword("strongPass123")).thenReturn("encryptedPass");
        // 模拟插入成功
        when(usersMapper.insert(any(Users.class))).thenReturn(1);

        // 替代实际调用的加密逻辑（new 的对象不好 mock，可以通过构造方式注入或反射注入）
        AdminUserServiceImpl service = new AdminUserServiceImpl() {
            @Override
            public void addUser(AdminUserAddUserRequest request) {
                String username = request.getUserName();
                String password = request.getPassword();
                String email = request.getEmail();
                String role = request.getRole();
                String avatarUrl = request.getAvatar_url();

                if (StrUtil.hasBlank(username, password, email)) {
                    throw new BusinessException(ErrorCode.PARAMS_ERROR, "Blanks in username, password or email.");
                }
                if (password.length() < 8) {
                    throw new BusinessException(ErrorCode.PARAMS_ERROR, "Password too short.");
                }

                QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
                queryWrapper
                        .eq("username", username)
                        .or()
                        .eq("email", email);
                if (usersMapper.selectCount(queryWrapper) > 0) {
                    throw new BusinessException(ErrorCode.PARAMS_ERROR, "User already exist.");
                }

                // mock 替代调用
                String encryptedPassword = usersService.getEncryptPassword(password);
                Users user = new Users();
                user.setUsername(username);
                user.setPassword(encryptedPassword);
                user.setEmail(email);
                user.setRole(role);
                user.setAvatar_url(avatarUrl);

                if (usersMapper.insert(user) == 0) {
                    throw new BusinessException(ErrorCode.SYSTEM_ERROR, "Error happened when adding user.");
                }
            }
        };

        // 注入 mock
        ReflectionTestUtils.setField(service, "usersMapper", usersMapper);

        // 执行
        service.addUser(request);

        // 验证插入
        verify(usersMapper).insert(any(Users.class));
    }

    // addUser的异常测试
    @Test
    void testAddUser_blankFields_shouldThrow() {
        AdminUserAddUserRequest request = new AdminUserAddUserRequest();
        request.setUserName(""); // 空用户名
        request.setPassword("12345678");
        request.setEmail("test@example.com");

        assertThrows(BusinessException.class, () -> adminUserService.addUser(request));
    }

    @Test
    void testAddUser_shortPassword_shouldThrow() {
        AdminUserAddUserRequest request = new AdminUserAddUserRequest();
        request.setUserName("newUser");
        request.setPassword("123"); // 密码过短
        request.setEmail("test@example.com");

        assertThrows(BusinessException.class, () -> adminUserService.addUser(request));
    }

    @Test
    void testAddUser_userAlreadyExists_shouldThrow() {
        AdminUserAddUserRequest request = new AdminUserAddUserRequest();
        request.setUserName("newUser");
        request.setPassword("12345678");
        request.setEmail("test@example.com");

        when(usersMapper.selectCount(any(QueryWrapper.class))).thenReturn(1L); // 已存在

        assertThrows(BusinessException.class, () -> adminUserService.addUser(request));
    }
}
