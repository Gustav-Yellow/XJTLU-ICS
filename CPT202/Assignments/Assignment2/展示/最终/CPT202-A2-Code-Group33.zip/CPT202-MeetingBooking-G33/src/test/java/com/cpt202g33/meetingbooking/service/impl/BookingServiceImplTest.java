package com.cpt202g33.meetingbooking.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.mapper.BookingMapper;
import com.cpt202g33.meetingbooking.mapper.RoomMapper;
import com.cpt202g33.meetingbooking.model.dto.BookingModifyRequest;
import com.cpt202g33.meetingbooking.model.entity.Bookings;
import com.cpt202g33.meetingbooking.model.entity.Room;
import com.cpt202g33.meetingbooking.model.enums.UsersRoleEnum;
import com.cpt202g33.meetingbooking.model.vo.BookingDetailVO;
import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import lombok.var;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookingServiceImplTest {

    private BookingServiceImpl bookingService;
    private BookingMapper bookingMapper;
    private RoomMapper roomMapper;

    @BeforeEach
    void setUp() {
        bookingMapper = mock(BookingMapper.class);
        roomMapper = mock(RoomMapper.class);
        bookingService = new BookingServiceImpl();

        // 使用反射注入资源字段（如果没有用构造函数注入）
        setField(bookingService, "bookingMapper", bookingMapper);
        setField(bookingService, "roomMapper", roomMapper);
    }

    void setField(Object target, String fieldName, Object value) {
        try {
            var field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testGetFutureBookingsByUserId() {
        int userId = 1;
        LocalDateTime now = LocalDateTime.now();

        Bookings mockBooking = new Bookings();
        mockBooking.setBooking_id(1);
        mockBooking.setUser_id(userId);
        mockBooking.setStart_time(now.plusDays(1));
        mockBooking.setRoom_id(101);

        when(bookingMapper.selectList(any(QueryWrapper.class)))
                .thenReturn(List.of(mockBooking));

        Room mockRoom = new Room();
        mockRoom.setRoom_id(101);
        mockRoom.setRoom_name("Room A");
        when(roomMapper.selectById(101)).thenReturn(mockRoom);

        List<BookingListVO> result = bookingService.getFutureBookingsByUserId(userId);
        assertEquals(1, result.size());
        assertEquals("Room A", result.get(0).getRoom_name());
    }

    @Test
    void testCancelBookingAsOwner() {
        Bookings booking = new Bookings();
        booking.setBooking_id(1);
        booking.setUser_id(123);
        booking.setStatus("approved");

        when(bookingMapper.selectById(1)).thenReturn(booking);
        when(bookingMapper.update(any(), any(UpdateWrapper.class))).thenReturn(1);

        boolean result = bookingService.cancelBooking(1, 123, UsersRoleEnum.USER.getValue());
        assertTrue(result);
    }

    @Test
    void testCancelBookingUnauthorized() {
        Bookings booking = new Bookings();
        booking.setBooking_id(1);
        booking.setUser_id(999);

        when(bookingMapper.selectById(1)).thenReturn(booking);

        assertThrows(BusinessException.class, () ->
                bookingService.cancelBooking(1, 123, UsersRoleEnum.USER.getValue()));
    }

    @Test
    void testGetBookingByIdAsAdmin() {
        Bookings booking = new Bookings();
        booking.setBooking_id(1);
        booking.setUser_id(123);
        booking.setRoom_id(101);
        booking.setStatus("approved");

        when(bookingMapper.selectById(1)).thenReturn(booking);
        when(roomMapper.selectById(101)).thenReturn(new Room() {{
            setRoom_name("Admin Room");
        }});

        BookingDetailVO result = bookingService.getBookingById(1, 999, UsersRoleEnum.ADMIN.getValue());
        assertEquals("Admin Room", result.getRoom_name());
    }

    @Test
    void testModifyBookingWithInvalidTime() {
        Bookings booking = new Bookings();
        booking.setBooking_id(1);
        booking.setUser_id(123);
        booking.setStatus("approved");

        when(bookingMapper.selectById(1)).thenReturn(booking);

        BookingModifyRequest modifyRequest = new BookingModifyRequest();
        modifyRequest.setStart_time(LocalDateTime.now().plusHours(2));
        modifyRequest.setEnd_time(LocalDateTime.now().plusHours(1)); // Invalid: start > end

        assertThrows(BusinessException.class, () -> {
            bookingService.modifyBooking(1, modifyRequest, 123, UsersRoleEnum.USER.getValue());
        });
    }
}

