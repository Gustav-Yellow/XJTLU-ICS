package com.cpt202g33.meetingbooking.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.mapper.FeedbackMapper;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.dto.FeedbackCreateRequest;
import com.cpt202g33.meetingbooking.model.dto.FeedbackReplyRequest;
import com.cpt202g33.meetingbooking.model.entity.Feedback;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.enums.FeedbackStatusEnum;
import com.cpt202g33.meetingbooking.model.vo.FeedbackDetailVO;
import com.cpt202g33.meetingbooking.model.vo.FeedbackListVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FeedbackServiceImplTest {

    @InjectMocks
    private FeedbackServiceImpl feedbackService;

    @Mock
    private FeedbackMapper feedbackMapper;

    @Mock
    private UsersMapper usersMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // 测试 save 正常情况
    @Test
    void testSaveFeedback_Success() {
        FeedbackCreateRequest request = new FeedbackCreateRequest();
        request.setContent("Test content");

        Users user = new Users();
        user.setUser_id(1);
        when(usersMapper.selectById(1)).thenReturn(user);
        when(feedbackMapper.insert(any(Feedback.class))).thenReturn(1);

        boolean result = feedbackService.save(request, 1);
        assertTrue(result);
        verify(feedbackMapper, times(1)).insert(any(Feedback.class));
    }

    // 测试 save 参数为空异常
    @Test
    void testSaveFeedback_NullRequest_ThrowsException() {
        assertThrows(BusinessException.class, () -> feedbackService.save(null, 1));
    }

    // 测试 reply 正常情况
    @Test
    void testReplyFeedback_Success() {
        FeedbackReplyRequest replyRequest = new FeedbackReplyRequest();
        replyRequest.setReply("Thanks!");
        replyRequest.setResolvedNotices("Solved.");

        Feedback feedback = new Feedback();
        feedback.setStatus(FeedbackStatusEnum.PENDING.getValue());
        when(feedbackMapper.selectById(1)).thenReturn(feedback);
        when(feedbackMapper.updateById(any(Feedback.class))).thenReturn(1);

        boolean result = feedbackService.replyFeedback(1, replyRequest, 1001);
        assertTrue(result);
    }

    // 测试 reply 时反馈已解决
    @Test
    void testReplyFeedback_AlreadyResolved_ThrowsException() {
        Feedback feedback = new Feedback();
        feedback.setStatus(FeedbackStatusEnum.RESOLVED.getValue());
        when(feedbackMapper.selectById(1)).thenReturn(feedback);

        FeedbackReplyRequest replyRequest = new FeedbackReplyRequest();
        assertThrows(BusinessException.class, () -> feedbackService.replyFeedback(1, replyRequest, 1001));
    }

    // 测试 getFeedbackDetailById 正常情况
    @Test
    void testGetFeedbackDetailById_Success() {
        Feedback feedback = new Feedback();
        feedback.setFeedback_id(1);
        feedback.setUser_id(2);
        feedback.setContent("Test");
        when(feedbackMapper.selectById(1)).thenReturn(feedback);

        Users user = new Users();
        user.setUsername("Alice");
        when(usersMapper.selectById(2)).thenReturn(user);

        FeedbackDetailVO vo = feedbackService.getFeedbackDetailById(1);
        assertEquals("Test", vo.getContent());
        assertEquals("Alice", vo.getUsername());
    }

    // 测试 getFeedbackDetailById 异常情况
    @Test
    void testGetFeedbackDetailById_NotFound() {
        when(feedbackMapper.selectById(99)).thenReturn(null);
        assertThrows(BusinessException.class, () -> feedbackService.getFeedbackDetailById(99));
    }

    // 你还可以继续添加以下测试：
    // - listAllResolvedFeedbacks
    // - listAllPendingFeedbacks
    // - adminListAllResolvedFeedbacks
    // - adminListAllPendingFeedbacks
}

