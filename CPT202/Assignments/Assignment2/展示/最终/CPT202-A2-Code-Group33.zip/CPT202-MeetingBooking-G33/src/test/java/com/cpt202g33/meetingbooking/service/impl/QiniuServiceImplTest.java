package com.cpt202g33.meetingbooking.service.impl;

import com.cpt202g33.meetingbooking.config.QiniuConfig;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.qiniu.common.QiniuException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class QiniuServiceImplTest {

    @InjectMocks
    private QiniuServiceImpl qiniuService;

    @Mock
    private QiniuConfig qiniuConfig;

    @Mock
    private UsersMapper usersMapper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        when(qiniuConfig.getAccessKey()).thenReturn("fakeAccessKey");
        when(qiniuConfig.getSecretKey()).thenReturn("fakeSecretKey");
        when(qiniuConfig.getBucket()).thenReturn("fakeBucket");
        when(qiniuConfig.getDomain()).thenReturn("fake.qiniu.com");
    }

    @Test
    public void testValidPicture_validFile_pass() {
        MultipartFile file = new MockMultipartFile("file", "avatar.jpg", "image/jpeg", new byte[1024]);
        assertDoesNotThrow(() -> qiniuService.validPicture(file));
    }

    @Test
    public void testValidPicture_largeFile_throwException() {
        byte[] largeFile = new byte[3 * 1024 * 1024]; // 3MB
        MultipartFile file = new MockMultipartFile("file", "avatar.jpg", "image/jpeg", largeFile);
        assertThrows(BusinessException.class, () -> qiniuService.validPicture(file));
    }

    @Test
    public void testValidPicture_invalidSuffix_throwException() {
        MultipartFile file = new MockMultipartFile("file", "avatar.exe", "application/octet-stream", new byte[1024]);
        assertThrows(BusinessException.class, () -> qiniuService.validPicture(file));
    }

    @Test
    public void testUploadUserAvatar_validFile_success() throws Exception {
        byte[] content = "fake image content".getBytes();
        MultipartFile file = new MockMultipartFile("file", "avatar.jpg", "image/jpeg", content);
        Integer userId = 1;

//        doNothing().when(usersMapper).updateAvatarUrl(anyInt(), anyString());

        QiniuServiceImpl spyService = Mockito.spy(qiniuService);
        doReturn("http://fake.qiniu.com/avatars/fake.jpg").when(spyService).uploadAvatar(any(InputStream.class), anyString());

        String result = spyService.uploadUserAvatar(file, userId);
        assertTrue(result.startsWith("http://fake.qiniu.com"));
        verify(usersMapper, times(1)).updateAvatarUrl(eq(userId), anyString());
    }

    @Test
    public void testUploadUserAvatar_emptyFile_throwException() {
        MultipartFile file = new MockMultipartFile("file", "avatar.jpg", "image/jpeg", new byte[0]);
        assertThrows(BusinessException.class, () -> qiniuService.uploadUserAvatar(file, 1));
    }

    @Test
    public void testDeleteAvatar_success() {
        // 因为 deleteAvatar 调用的是七牛 SDK，需要用集成测试或者 mock 七牛 BucketManager
        QiniuServiceImpl service = Mockito.spy(qiniuService);
        assertThrows(BusinessException.class, () -> service.deleteAvatar("non-exist.jpg"));
    }
}

