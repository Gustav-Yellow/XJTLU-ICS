package com.cpt202g33.meetingbooking.service.impl;

import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.mutable.Mutable;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.cpt202g33.meetingbooking.config.QiniuConfig;
import com.cpt202g33.meetingbooking.model.dto.RoomQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.*;
import com.cpt202g33.meetingbooking.model.vo.RoomQueryResponse;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import com.cpt202g33.meetingbooking.service.QiniuService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.mapper.BookingMapper;
import com.cpt202g33.meetingbooking.mapper.BuildingMapper;
import com.cpt202g33.meetingbooking.mapper.RoomMapper;
import com.cpt202g33.meetingbooking.mapper.RoomTypeMapper;
import com.cpt202g33.meetingbooking.model.dto.RoomRequest;
import com.cpt202g33.meetingbooking.model.vo.BookingListVO;
import com.cpt202g33.meetingbooking.model.vo.RoomDetailVO;
import com.cpt202g33.meetingbooking.model.vo.RoomVO;
import com.cpt202g33.meetingbooking.service.RoomService;

import cn.hutool.core.util.StrUtil;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RoomServiceImplTest {

    @Mock
    private RoomMapper roomMapper;

    @Mock
    private RoomTypeMapper roomTypeMapper;

    @Mock
    private BuildingMapper buildingMapper;

    @Mock
    private QiniuService qiniuService;

    @Mock
    private QiniuConfig qiniuConfig;

    @InjectMocks
    private RoomServiceImpl roomService;

    private Room mockRoom;

    @BeforeEach
    void setUp() {
        mockRoom = new Room();
        mockRoom.setRoom_id(1);
        mockRoom.setRoom_name("Room A");
        mockRoom.setBuilding_id(1);
        mockRoom.setCreated_at(new Date());
        mockRoom.setUpdated_at(new Date());
    }

    @Test
    void testListAllRooms() {
        List<Room> mockList = Arrays.asList(mockRoom);
        when(roomMapper.selectList(any())).thenReturn(mockList);
        when(buildingMapper.selectList(any())).thenReturn(new ArrayList<>());
        when(qiniuConfig.getDomain()).thenReturn("cdn.qiniu.com/");

        List<RoomVO> result = roomService.listAllRooms();

        assertEquals(1, result.size());
        assertEquals("Room A", result.get(0).getRoom_name());
        verify(roomMapper).selectList(any());
    }

}


