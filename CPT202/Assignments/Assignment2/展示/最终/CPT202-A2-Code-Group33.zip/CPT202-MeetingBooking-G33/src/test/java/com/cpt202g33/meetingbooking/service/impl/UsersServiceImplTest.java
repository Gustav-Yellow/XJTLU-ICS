package com.cpt202g33.meetingbooking.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cpt202g33.meetingbooking.common.EmailSender;
import com.cpt202g33.meetingbooking.common.RateLimiter;
import com.cpt202g33.meetingbooking.config.QiniuConfig;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.user.LoginUserVO;
import com.cpt202g33.meetingbooking.service.BookingService;
import com.cpt202g33.meetingbooking.service.QiniuService;
import lombok.var;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockHttpServletRequest;

import javax.servlet.http.HttpSession;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UsersServiceImplTest {

    @InjectMocks
    private UsersServiceImpl usersService;

    @Mock
    private UsersMapper usersMapper;

    @Mock
    private EmailSender emailSender;

    @Mock
    private RateLimiter rateLimiter;

    @Mock
    private QiniuService qiniuService;

    @Mock
    private BookingService bookingService;

    @Mock
    private QiniuConfig qiniuConfig;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // 示例测试：密码加密方法
    @Test
    void testGetEncryptPassword() {
        String password = "12345678";
        String encrypted = usersService.getEncryptPassword(password);
        assertNotNull(encrypted);
        assertNotEquals(password, encrypted);
    }

    // 示例测试：验证码生成请求限制
    @Test
    void testAskCode_shouldThrowWhenRateLimited() {
        when(rateLimiter.allowRequest("127.0.0.1")).thenReturn(false);
        assertThrows(BusinessException.class, () -> usersService.askCode("user@example.com", "127.0.0.1"));
    }

    @Test
    void testUserLogin_success() {
        Users user = new Users();
        user.setUsername("testuser");
        user.setPassword(usersService.getEncryptPassword("12345678"));
        user.setUser_id(1);
        user.setIs_locked(0);
        user.setAvatar_url("/avatar.png");

        when(usersMapper.selectOne(any(QueryWrapper.class))).thenReturn(user);
        when(usersMapper.selectCount(any(QueryWrapper.class))).thenReturn(1L); // Fix for getLoginUserVO

        MockHttpServletRequest request = new MockHttpServletRequest();

        LoginUserVO result = usersService.userLogin("testuser", "12345678", request);

        assertEquals("testuser", result.getUsername());
        assertFalse(result.getIs_locked());
        assertTrue(result.getAvatar_url().contains("http://")); // URL 被组装了
    }


    // 示例测试：注册用户名重复时抛异常
    @Test
    void testUserRegister_duplicateUsernameOrEmail() {
        when(usersMapper.selectCount(any())).thenReturn(1L);
        assertThrows(BusinessException.class, () -> {
            usersService.userRegister("user", "12345678", "email@test.com", "123456", null);
        });
    }
}

