-- 插入测试用户 密码都是12345678
INSERT INTO users (username, email, password, role, is_deleted, created_at, updated_at)
VALUES (
  'test', 
  'test@example.com', 
  'b5d78467840c9b1f7d5ec9199780379f', 
  'user', 
  0, 
  CURRENT_TIMESTAMP, 
  CURRENT_TIMESTAMP
);
INSERT INTO users (username, email, password, role, is_deleted, created_at, updated_at)
VALUES (
  'test_admin', 
  'test_admin@example.com', 
  'b5d78467840c9b1f7d5ec9199780379f', 
  'admin', 
  0, 
  CURRENT_TIMESTAMP, 
  CURRENT_TIMESTAMP
);

-- 插入一个建筑
INSERT INTO buildings (name)
VALUES ('Foundation Building');

-- 插入一个会议室类型
INSERT INTO room_types (type_name, description, capacity)
VALUES ('Meeting Room', 'Meeting Room', 20);

-- 插入一个会议室记录
INSERT INTO rooms (room_name, type_id, building_id, facilities)
VALUES ('FB114', 1, 1, 'Computer, White Board, Projector');

-- 插入booking记录
INSERT INTO bookings (
    user_id, 
    room_id, 
    start_time, 
    end_time, 
    subject, 
    reason, 
    status
) VALUES (
    1, -- user_id为1的用户
    1, -- room_id为1的会议室
    '2025-04-14 10:00:00', 
    '2025-04-14 12:00:00', 
    '项目启动会议', 
    '讨论新项目的启动计划和任务分配', 
    'pending'
);

INSERT INTO booking_participants (booking_id, user_id) VALUES (1, 2);
