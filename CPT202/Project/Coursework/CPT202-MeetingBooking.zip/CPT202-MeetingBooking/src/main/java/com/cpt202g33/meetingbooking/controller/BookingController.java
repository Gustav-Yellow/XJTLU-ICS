package com.cpt202g33.meetingbooking.controller;

import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.BookingVO;
import com.cpt202g33.meetingbooking.service.BookingService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 预订控制器
 */
@RestController
@RequestMapping("/bookings")
public class BookingController {
    
    @Resource
    private BookingService bookingService;
    
    /**
     * 获取当前用户的预订记录
     *
     * @param request HTTP请求
     * @return 预订记录列表
     */
    @AuthCheck(mustRole = "user")
    @GetMapping("/list")
    public BaseResponse<List<BookingVO>> listBookings(HttpServletRequest request) {
        // 从会话中获取登录用户信息
        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute(UserConstant.USER_LOGIN_STATE);
        Integer user_id = loginUser.getUser_id();
        
        List<BookingVO> bookingList = bookingService.getBookingsByUserId(user_id);
        return ResultUtils.success(bookingList);
    }
}
