package com.cpt202g33.meetingbooking.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cpt202g33.meetingbooking.annotation.AuthCheck;
import com.cpt202g33.meetingbooking.common.BaseResponse;
import com.cpt202g33.meetingbooking.common.ResultUtils;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.exception.ThrowUtils;
import com.cpt202g33.meetingbooking.model.dto.user.UserLoginRequest;
import com.cpt202g33.meetingbooking.model.dto.user.UserQueryRequest;
import com.cpt202g33.meetingbooking.model.dto.user.UserRegisterRequest;
import com.cpt202g33.meetingbooking.model.dto.user.UserUpdateRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.user.LoginUserVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import com.cpt202g33.meetingbooking.service.UsersService;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

// Spring 会通过 @ResponseBody 或 @RestController 自动触发 JSON 转换
// 启动项目之后在浏览器打开 http://localhost:8080/api/doc.html#/home，可以直接查看当前项目中所有的接口，比 postman 要好用
@RestController
@RequestMapping("/user")
public class UsersController {

    @Resource
    UsersService usersService;


    /**
     * 用户注册
     * @param userRegisterRequest
     * @return
     */
    // @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @PostMapping("/register")
    public BaseResponse<Integer> userRegister(@RequestBody UserRegisterRequest userRegisterRequest) {
        ThrowUtils.throwIf(userRegisterRequest == null, ErrorCode.PARAMS_ERROR);
        String username = userRegisterRequest.getUsername();
        Long account = userRegisterRequest.getAccount();
        String email = userRegisterRequest.getEmail();
        String userPassword = userRegisterRequest.getPassword();
        // 不再需要在后端进行两次输入的密码是否相同的判断
        // String checkPassword = userRegisterRequest.getCheckPassword();
        int result = usersService.userRegister(username, userPassword, account, email);
        return ResultUtils.success(result);
    }


    /**
     * 用户登录
     * @param userLoginRequest
     * @param request
     * @return
     */
    @PostMapping("/login")
    public BaseResponse<LoginUserVO> userLogin(@RequestBody UserLoginRequest userLoginRequest, HttpServletRequest request) {
        ThrowUtils.throwIf(userLoginRequest == null, ErrorCode.PARAMS_ERROR);
        // 这里的user account 可以是 account 或者 email
        String userAccount = String.valueOf(userLoginRequest.getUserAccount());
        String userPassword = userLoginRequest.getPassword();
        LoginUserVO loginUserVO = usersService.userLogin(userAccount, userPassword, request);
        return ResultUtils.success(loginUserVO);
    }

    /**
     * 获取当前登录的用户信息
     * @param request
     * @return
     */
    @GetMapping("/me")
    public BaseResponse<LoginUserVO> userInfo(HttpServletRequest request) {
        Users user = usersService.getLoginUser(request);
        LoginUserVO loginUserVo = usersService.getLoginUserVO(user);
        return ResultUtils.success(loginUserVo);
    }

    /**
     * 用户注销
     * @param request
     * @return
     */
    @PostMapping("/logout")
    public BaseResponse<Boolean> userLogout(HttpServletRequest request) {
        ThrowUtils.throwIf(request == null, ErrorCode.PARAMS_ERROR);
        boolean result = usersService.userLogout(request);
        return ResultUtils.success(result);
    }

    /**
     *  根据路径中提供的用户id，搜索对应的用户信息
     * @param user_id
     * @return
     */
    @GetMapping("/get/{id}")
    public BaseResponse<Users> getUserById(@PathVariable("id") Integer user_id) {
        System.out.println(user_id);
        ThrowUtils.throwIf(user_id <= 0, ErrorCode.PARAMS_ERROR);
        Users user = usersService.getById(user_id);
        ThrowUtils.throwIf(user == null, ErrorCode.NOT_FOUND_ERROR);
        return ResultUtils.success(user);
    }

    /**
     * 更新用户的 username，email，avatar信息
     * @param userUpdateRequest
     * @return
     */
    @PostMapping("/update")
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<Boolean> updateUser(@RequestBody UserUpdateRequest userUpdateRequest) {
        // 1. 验证请求非空
        // 如果请求为空，抛异常
        if (userUpdateRequest == null || userUpdateRequest.getUser_id() == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }

        // 2. 将请求类型转换为原始的用户类型
        Users user = new Users();
        BeanUtils.copyProperties(userUpdateRequest, user);
        // 根据 account 更改用户信息
        boolean result = usersService.updateById(user);
        // 如果更改成功 result 应该是 true
        ThrowUtils.throwIf(!result, ErrorCode.OPERATION_ERROR);
        return ResultUtils.success(true);
    }

    /**
     * 分页获取用户封装列表（仅管理员）
     *
     * @param userQueryRequest 查询请求参数
     */
    @PostMapping("/list")
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<Page<UserVO>> listUserVOByPage(@RequestBody UserQueryRequest userQueryRequest) {
        ThrowUtils.throwIf(userQueryRequest == null, ErrorCode.PARAMS_ERROR);
        long current = userQueryRequest.getCurrent();
        long pageSize = userQueryRequest.getPageSize();

        // 这里使用自定义的 getQueryWrapper 方法实现范围搜索，根据前端传回来的表单信息来设置动态查询的条件
        // usersService.page() 是 MyBatis-Plus 的分页查询方法，返回 Page<Users> 对象（包含当前页的用户数据 records 和总条数 total）
        Page<Users> userPage = usersService.page(new Page<>(current, pageSize),
                usersService.getQueryWrapper(userQueryRequest));
        Page<UserVO> userVOPage = new Page<>(current, pageSize, userPage.getTotal());
        List<UserVO> userVOList = usersService.getUserVOList(userPage.getRecords());
        userVOPage.setRecords(userVOList);
        return ResultUtils.success(userVOPage);
    }





}
