package com.cpt202g33.meetingbooking.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cpt202g33.meetingbooking.model.entity.Bookings;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 预订数据库操作接口
 */
@Mapper
public interface BookingMapper extends BaseMapper<Bookings> {
    /**
     * 根据用户ID查询预订记录
     * @param user_id 用户ID
     * @return 预订记录列表
     */
    List<Bookings> selectByUserId(@Param("user_id") Integer user_id);
}