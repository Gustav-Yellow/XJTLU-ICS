package com.cpt202g33.meetingbooking.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cpt202g33.meetingbooking.model.entity.Users;

public interface UsersMapper extends BaseMapper<Users> {

}