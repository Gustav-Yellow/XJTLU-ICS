package com.cpt202g33.meetingbooking.model.entity;

import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * 会议预订实体
 */
@Data
@Entity
@TableName("bookings")
public class Bookings {
    /**
     * 预订ID
     */
    @Id
    private Integer booking_id;
    
    /**
     * 用户ID（预订人）
     */
    private Integer user_id;
    
    /**
     * 预订主题
     */
    private String subject;
    
    /**
     * 预订状态（approved, pending等）
     */
    private String status;
    
    /**
     * 创建时间
     */
    private LocalDateTime created_at;
    
    /**
     * 更新时间
     */
    private LocalDateTime updated_at;
    
    /**
     * 是否删除
     */
    @TableLogic
    private Integer is_deleted;
}