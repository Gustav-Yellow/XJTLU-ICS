package com.cpt202g33.meetingbooking.model.vo;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 预订信息视图对象
 */
@Data
public class BookingVO {
    /**
     * 预订ID
     */
    private Integer booking_id;
    
    /**
     * 预订主题
     */
    private String subject;
    
    /**
     * 预订状态（approved, pending等）
     */
    private String status;
    
    /**
     * 创建时间
     */
    private LocalDateTime created_at;

    
}