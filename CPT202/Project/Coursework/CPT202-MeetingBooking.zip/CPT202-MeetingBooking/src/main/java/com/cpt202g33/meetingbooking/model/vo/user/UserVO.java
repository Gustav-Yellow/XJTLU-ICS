package com.cpt202g33.meetingbooking.model.vo.user;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class UserVO implements Serializable {


    /**
     * id
     */
    private Integer user_id;

    /**
     * 用户昵称
     */
    private String username;

    /**
     * 账户
     */
    private Long account;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 用户头像
     */
    private String avatar_url;

    /**
     * 用户角色：user/admin
     */
    private String role;

    /**
     * 创建时间
     */
    private Date created_at;

    /**
     * 更新时间
     */
    private Date updated_at;

}
