package com.cpt202g33.meetingbooking.service;

import com.cpt202g33.meetingbooking.model.vo.BookingVO;

import java.util.List;

/**
 * 预订服务接口
 */
public interface BookingService {
    
    /**
     * 根据用户ID获取预订记录
     * @param user_id 用户ID
     * @return 预订记录列表
     */
    List<BookingVO> getBookingsByUserId(Integer user_id);
}