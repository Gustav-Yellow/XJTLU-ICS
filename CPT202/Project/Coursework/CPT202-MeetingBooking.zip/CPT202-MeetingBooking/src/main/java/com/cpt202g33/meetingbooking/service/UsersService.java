package com.cpt202g33.meetingbooking.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cpt202g33.meetingbooking.model.dto.user.UserQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.vo.user.LoginUserVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface UsersService extends IService<Users> {

    /**
     * 用户注册
     *
     * @param username   用户账户
     * @param password  用户密码
     * @return 新用户 id
     */
    Integer userRegister(String username, String password, Long account, String email);


    /**
     * 获取加密后的密码
     *
     * @param password
     * @return
     */
    String getEncryptPassword(String password);

    /**
     * 用户登录
     *
     * @param username  用户账户
     * @param password 用户密码
     * @param request
     * @return 脱敏后的用户信息
     */
    LoginUserVO userLogin(String username, String password, HttpServletRequest request);

    /**
     * 用户注销
     *
     * @param request
     * @return
     */
    boolean userLogout(HttpServletRequest request);

    /**
     * 获取当前登录用户
     *
     * @param request
     * @return
     */
    Users getLoginUser(HttpServletRequest request);

    /**
     * 获得脱敏后的登录用户信息
     *
     * @param user
     * @return
     */
    LoginUserVO getLoginUserVO(Users user);

    /**
     * 获得脱敏后的用户信息
     *
     * @param user
     * @return
     */
    UserVO getUserVO(Users user);

    /**
     * 获得脱敏后的用户信息列表
     *
     * @param userList
     * @return 脱敏后的用户列表
     */
    List<UserVO> getUserVOList(List<Users> userList);

    /**
     * 获取查询条件
     * @param userQueryRequest
     * @return
     */
    QueryWrapper<Users> getQueryWrapper(UserQueryRequest userQueryRequest);

    
    
}
