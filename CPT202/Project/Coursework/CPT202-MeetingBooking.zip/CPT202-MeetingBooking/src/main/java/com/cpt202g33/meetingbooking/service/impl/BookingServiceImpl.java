package com.cpt202g33.meetingbooking.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cpt202g33.meetingbooking.mapper.BookingMapper;
import com.cpt202g33.meetingbooking.model.entity.Bookings;
import com.cpt202g33.meetingbooking.model.vo.BookingVO;
import com.cpt202g33.meetingbooking.service.BookingService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * 预订服务实现类
 */
@Service
public class BookingServiceImpl implements BookingService {
    
    @Resource
    private BookingMapper bookingMapper;
    
    /**
     * 根据用户ID获取预订记录
     * @param user_id 用户ID
     * @return 预订记录列表
     */
    @Override
    public List<BookingVO> getBookingsByUserId(Integer user_id) {
        QueryWrapper<Bookings> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", user_id);
        List<Bookings> bookings = bookingMapper.selectList(queryWrapper);
        
        List<BookingVO> bookingVOList = new ArrayList<>();
        
        for (Bookings booking : bookings) {
            BookingVO bookingVO = new BookingVO();
            BeanUtils.copyProperties(booking, bookingVO);
            bookingVO.setBooking_id(booking.getBooking_id());
            bookingVOList.add(bookingVO);
        }
        
        return bookingVOList;
    }
}