package com.cpt202g33.meetingbooking.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cpt202g33.meetingbooking.constant.UserConstant;
import com.cpt202g33.meetingbooking.exception.BusinessException;
import com.cpt202g33.meetingbooking.exception.ErrorCode;
import com.cpt202g33.meetingbooking.mapper.UsersMapper;
import com.cpt202g33.meetingbooking.model.dto.user.UserQueryRequest;
import com.cpt202g33.meetingbooking.model.entity.Users;
import com.cpt202g33.meetingbooking.model.enums.UsersRoleEnum;
import com.cpt202g33.meetingbooking.model.vo.user.LoginUserVO;
import com.cpt202g33.meetingbooking.model.vo.user.UserVO;
import com.cpt202g33.meetingbooking.service.UsersService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class UsersServiceImpl extends ServiceImpl<UsersMapper, Users>
        implements UsersService {

    @Resource
    UsersMapper usersMapper;

    /**
     * 用户注册
     *
     * @param username   用户账户
     * @param password  用户密码
     * @return
     */
    // 如果你想对该方法加权限校验可以直接写一个注解
    // @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    @Override
    public Integer userRegister(String username, String password, Long account, String email) {
        // 1. 校验参数
        if (StrUtil.hasBlank(username, password)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "参数为空");
        }
        if (username.length() < 4) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户账号过短");
        }
        if (password.length() < 8 ) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户密码过短");
        }
//        if (!password.equals(checkPassword)) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "两次输入的密码不一致");
//        }
        // 2. 检查用户账号是否和数据库中已有的重复
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        // 不允许有重复的用户名，用户账号或者邮箱存在重复
        queryWrapper
                .eq("username", username)
                .or()
                .eq("account", account)
                .or()
                .eq("email", email);
        long count = this.baseMapper.selectCount(queryWrapper);
        // 如果此时数据库中已经有了该对象的信息
        if (count > 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "账号重复");
        }
        // 3. 密码一定要加密
        String encryptPassword = getEncryptPassword(password);
        // 4. 插入数据到数据库中
        Users user = new Users();
        user.setUsername(username);
        user.setPassword(encryptPassword);
        user.setEmail(email);
        user.setAccount(account);
        user.setRole(UsersRoleEnum.ADMIN.getValue());
        //boolean saveResult = this.save(user);
        int result = usersMapper.insert(user);
        if (result == 0) {
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "注册失败，数据库错误");
        }
        // 返回对应的用户id
        return user.getUser_id();
    }

    /**
     * 用户登录，可以是 account 或者 email
     * @param userAccount  用户可以用 account 登录或者用 email 登录
     * @param password 用户密码
     * @param request
     * @return
     */
    @Override
    public LoginUserVO userLogin(String userAccount, String password, HttpServletRequest request) {
        // 1. 校验
        if (StrUtil.hasBlank(userAccount, password)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "参数为空");
        }
        if (userAccount.length() < 4) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户账号错误");
        }
        if (password.length() < 8) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户密码错误");
        }

        // 2. 对用户传递的密码进行加密
        String encryptPassword = getEncryptPassword(password);

        // 3. 查询数据库中的用户是否存在
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        // 这里的 QueryWrapper 就是查询条件，这里的使用场景需要 username 和 password 同时对应数据库中的信息
        queryWrapper.eq("account", userAccount)
                .or()
                .eq("email", userAccount);
        // 查找出对应着提供的 account 或者 email
        Users user = this.baseMapper.selectOne(queryWrapper);
        // 没有查到提供的 account 或者 email 的用户，则抛出异常
        if (user == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "账号或邮箱有误");
        }
        // 4. 验证密码（需加密比对）
        // 如果密码不相同，则抛出异常
        // 注意，这里不能直接说你的密码错了，可能用户只是猜测了一个账户。
        if (!encryptPassword.equals(user.getPassword())) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "账号或邮箱有误");
        }

        // 5. 保存用户的登录态
        // 检查现有会话
        // false表示不自动创建新Session
        HttpSession oldSession = request.getSession(false);
        if (oldSession != null) {
            // 使现有会话失效
            oldSession.invalidate();
        }
        
        // 创建新会话
        HttpSession session = request.getSession(true); // 确保创建新session
        session.setAttribute(UserConstant.USER_LOGIN_STATE, user);
        return this.getLoginUserVO(user);
    }

    /**
     * 用户注销
     * @param request
     * @return
     */
    @Override
    public boolean userLogout(HttpServletRequest request) {
        // 判断是否已经登录
        Object userObj = request.getSession().getAttribute(UserConstant.USER_LOGIN_STATE);
        if (userObj == null) {
            throw new BusinessException(ErrorCode.OPERATION_ERROR, "未登录");
        }
        // 移除登录态
        request.getSession().removeAttribute(UserConstant.USER_LOGIN_STATE);
        return true;
    }

    /**
     * 盐值 + md5 加密密码
     * @param password
     * @return
     */
    @Override
    public String getEncryptPassword(String password) {
        // 加盐，混淆密码
        final String SALT = "group33";
        return DigestUtils.md5DigestAsHex((SALT + password).getBytes());
    }

    /**
     * 获取当前登录用户
     * @param request
     * @return
     */
    @Override
    public Users getLoginUser(HttpServletRequest request) {
        // 判断是否已经登录，从请求中检查session获取对应的信息
        Object userObj = request.getSession().getAttribute(UserConstant.USER_LOGIN_STATE);
        // 将取出的内容转换为 Users 类
        Users currentUser = (Users) userObj;
        if (currentUser == null || currentUser.getUser_id() == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        // 从数据库中查询（追求性能的话可以注释，直接返回上述结果）
        Integer userId = currentUser.getUser_id();
        currentUser = this.getById(userId);
        if (currentUser == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        return currentUser;
    }

    /**
     * 获取脱敏类的用户信息
     *
     * @param user 用户
     * @return 脱敏后的用户信息
     */
    @Override
    public LoginUserVO getLoginUserVO(Users user) {
        if (user == null) {
            return null;
        }
        LoginUserVO loginUserVO = new LoginUserVO();
        // 将传入的 User 中的信息，复制到 LoginUserVO 对象中，这中间会自动匹配对应的属性，对应不上的属性就会设置为空
        // 这样就不需要再单独一个一个设置相应的信息了
        BeanUtil.copyProperties(user, loginUserVO);
        return loginUserVO;
    }

    /**
     * 获得脱敏后的用于用户列表的用户信息
     *
     * @param user
     * @return
     */
    @Override
    public UserVO getUserVO(Users user) {
        if (user == null) {
            return null;
        }
        UserVO userVO = new UserVO();
        BeanUtil.copyProperties(user, userVO);
        return userVO;
    }

    /**
     * 获取脱敏后的用户列表
     *
     * @param userList
     * @return
     */
    @Override
    public List<UserVO> getUserVOList(List<Users> userList) {
        if (CollUtil.isEmpty(userList)) {
            return new ArrayList<>();
        }
        return userList.stream()
                .map(this::getUserVO)
                .collect(Collectors.toList());
    }


    /**
     * 按页查询用户
     * @param userQueryRequest
     * @return
     */
    @Override
    public QueryWrapper<Users> getQueryWrapper(UserQueryRequest userQueryRequest) {
        if (userQueryRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "请求参数为空");
        }
        String username = userQueryRequest.getUsername();
        String email = userQueryRequest.getEmail();
        String account = userQueryRequest.getAccount();
        String role = userQueryRequest.getRole();
        String sort_field = userQueryRequest.getSort_field();
        String sort_order = userQueryRequest.getSort_order();
        QueryWrapper<Users> queryWrapper = new QueryWrapper<>();
        // like 模糊查询
        queryWrapper.like(StrUtil.isNotBlank(role), "role", role);
        queryWrapper.like(StrUtil.isNotBlank(account), "account", account);
        queryWrapper.like(StrUtil.isNotBlank(username), "username", username);
        queryWrapper.like(StrUtil.isNotBlank(email), "email", email);
        /**
         *  boolean condition, 排序条件必须非空
         *  boolean isAsc, 是不是按照升序
         *  R column 按照哪一列的值进行排序
         */
        queryWrapper.orderBy(StrUtil.isNotEmpty(sort_field), sort_order.equals("ascend"), sort_field);
        return queryWrapper;
    }
    


}
